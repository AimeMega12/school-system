/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

export type DashboardHeaderVariant =
  | 'navy'      // Executive / Director Overview
  | 'blue'      // Admissions / Students Register / Accountant Overview
  | 'emerald'   // Food Inventory / Stock / Animator Overview
  | 'purple'    // Academic Policy / Access Control
  | 'teal'      // Reports & Analytics / Supplier Relationship
  | 'amber'     // Audit Logs & Activity / Live Schedule
  | 'indigo';   // Admin Profile / Notification Settings

interface DashboardPageHeaderProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  badge?: React.ReactNode;
  variant?: DashboardHeaderVariant;
  children?: React.ReactNode; // Action buttons, filters, selectors, time cards
  className?: string;
}

export const DashboardPageHeader: React.FC<DashboardPageHeaderProps> = ({
  title,
  subtitle,
  badge,
  variant = 'navy',
  children,
  className = ''
}) => {
  // Coordinated palette matching Karenge Adventist Secondary School branding with high contrast in Light and Dark themes
  const variantStyles: Record<DashboardHeaderVariant, { container: string; underline: string }> = {
    navy: {
      container:
        'bg-slate-900 text-white border-slate-800 shadow-sm dark:bg-slate-900/90 dark:border-slate-800',
      underline: 'bg-emerald-400'
    },
    blue: {
      container:
        'bg-blue-50/90 text-slate-900 border-blue-200/80 shadow-xs dark:bg-blue-950/40 dark:text-white dark:border-blue-900/60',
      underline: 'bg-emerald-500'
    },
    emerald: {
      container:
        'bg-emerald-50/90 text-slate-900 border-emerald-200/80 shadow-xs dark:bg-emerald-950/40 dark:text-white dark:border-emerald-900/60',
      underline: 'bg-emerald-500'
    },
    purple: {
      container:
        'bg-purple-50/90 text-slate-900 border-purple-200/80 shadow-xs dark:bg-purple-950/40 dark:text-white dark:border-purple-900/60',
      underline: 'bg-emerald-500'
    },
    teal: {
      container:
        'bg-teal-50/90 text-slate-900 border-teal-200/80 shadow-xs dark:bg-teal-950/40 dark:text-white dark:border-teal-900/60',
      underline: 'bg-emerald-500'
    },
    amber: {
      container:
        'bg-amber-50/90 text-slate-900 border-amber-200/80 shadow-xs dark:bg-amber-950/40 dark:text-white dark:border-amber-900/60',
      underline: 'bg-emerald-500'
    },
    indigo: {
      container:
        'bg-indigo-50/90 text-slate-900 border-indigo-200/80 shadow-xs dark:bg-indigo-950/40 dark:text-white dark:border-indigo-900/60',
      underline: 'bg-emerald-500'
    }
  };

  const style = variantStyles[variant] || variantStyles.navy;
  const isNavy = variant === 'navy';

  return (
    <div
      className={`p-4 sm:p-5 lg:p-6 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${style.container} ${className}`}
    >
      <div className="min-w-0 flex-1">
        {badge && <div className="mb-2">{badge}</div>}
        <div className="relative inline-block max-w-full">
          <h1
            className={`text-xl sm:text-2xl font-extrabold tracking-tight truncate ${
              isNavy ? 'text-white' : 'text-slate-900 dark:text-white'
            }`}
          >
            {title}
          </h1>
          {/* Distinct, clearly visible underline beneath the page title */}
          <div className={`h-1 w-20 sm:w-24 rounded-full mt-2 shadow-xs ${style.underline}`} />
        </div>
        {subtitle && (
          <p
            className={`text-xs sm:text-sm mt-2 max-w-3xl leading-relaxed ${
              isNavy ? 'text-slate-300' : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            {subtitle}
          </p>
        )}
      </div>

      {children && (
        <div className="shrink-0 flex flex-wrap items-center gap-2.5">
          {children}
        </div>
      )}
    </div>
  );
};
