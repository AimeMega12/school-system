/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.tsx';
import { useLanguage } from '../../context/LanguageContext.tsx';
import {
  Lock,
  KeyRound,
  ShieldCheck,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  GraduationCap,
  Copy,
  Check,
  Mail,
  Smartphone
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { loginStep1, verify2FA, resend2FACode, pending2FA, isAuthenticated, user } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();

  // Step 1 fields
  const [identifier, setIdentifier] = useState('director');
  const [password, setPassword] = useState('Password123!');
  const [step1Error, setStep1Error] = useState('');

  // Step 2 fields
  const [emailOtpInput, setEmailOtpInput] = useState('');
  const [smsOtpInput, setSmsOtpInput] = useState('');
  const [step2Error, setStep2Error] = useState('');
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedSms, setCopiedSms] = useState(false);

  // If already authenticated, redirect
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === 'director') navigate('/dashboard/director');
      else if (user.role === 'accountant') navigate('/dashboard/accountant');
      else if (user.role === 'animator') navigate('/dashboard/animator');
      else navigate('/dashboard');
    }
  }, [isAuthenticated, user, navigate]);

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep1Error('');
    const result = loginStep1(identifier, password);
    if (!result.success) {
      setStep1Error(result.error || t('invalidCredentials'));
    }
  };

  const handleStep2Submit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep2Error('');

    if (!pending2FA) return;

    if (pending2FA.otpMode === 'email_only') {
      const res = verify2FA(emailOtpInput);
      if (!res.success) setStep2Error(res.error || t('invalid2FA'));
    } else if (pending2FA.otpMode === 'sms_only') {
      const res = verify2FA(smsOtpInput);
      if (!res.success) setStep2Error(res.error || t('invalid2FA'));
    } else {
      // dual email_and_sms
      const res = verify2FA(emailOtpInput, smsOtpInput);
      if (!res.success) setStep2Error(res.error || t('invalid2FA'));
    }
  };

  const handleAutofillEmail = () => {
    if (pending2FA?.expectedEmailCode) {
      setEmailOtpInput(pending2FA.expectedEmailCode);
      navigator.clipboard.writeText(pending2FA.expectedEmailCode);
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    }
  };

  const handleAutofillSms = () => {
    if (pending2FA?.expectedSmsCode) {
      setSmsOtpInput(pending2FA.expectedSmsCode);
      navigator.clipboard.writeText(pending2FA.expectedSmsCode);
      setCopiedSms(true);
      setTimeout(() => setCopiedSms(false), 2000);
    }
  };

  const autofillAccount = (u: string, p: string) => {
    setIdentifier(u);
    setPassword(p);
    setStep1Error('');
  };

  return (
    <div className="py-16 bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-slate-100 min-h-[85vh] flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 w-full">
        
        {/* Brand Lockup */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-blue-700 text-white flex items-center justify-center mx-auto mb-3 shadow-lg shadow-emerald-600/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('loginTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('loginSubtitle')}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl">
          
          {!pending2FA ? (
            /* STEP 1: CREDENTIALS */
            <form onSubmit={handleStep1Submit} className="space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300">
                <Lock className="w-4 h-4 text-emerald-600" />
                <span>{t('step1Title')}</span>
              </div>

              {step1Error && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{step1Error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('usernameOrEmail')} *
                </label>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. director, accountant, animator"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {t('password')} *
                  </label>
                  <button
                    type="button"
                    onClick={() => alert('Please contact the School Director (director@ibb.ac.rw) to issue password recovery credentials.')}
                    className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline"
                  >
                    {t('forgotPassword')}
                  </button>
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all"
              >
                <span>{t('loginBtn')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Demo Accounts Helper */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                  {t('clickToAutofill')}
                </span>
                <div className="space-y-1.5">
                  <button
                    type="button"
                    onClick={() => autofillAccount('director', 'Password123!')}
                    className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block text-xs">
                        Director (Super Admin)
                      </span>
                      <span className="text-[11px] text-slate-500">username: director</span>
                    </div>
                    <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                      Use
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => autofillAccount('accountant', 'Password123!')}
                    className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-blue-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block text-xs">
                        Accountant (Stock In)
                      </span>
                      <span className="text-[11px] text-slate-500">username: accountant</span>
                    </div>
                    <span className="text-[11px] font-mono text-blue-600 dark:text-blue-400 font-semibold">
                      Use
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => autofillAccount('animator', 'Password123!')}
                    className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-amber-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block text-xs">
                        Animator (Daily Stock Out)
                      </span>
                      <span className="text-[11px] text-slate-500">username: animator</span>
                    </div>
                    <span className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-semibold">
                      Use
                    </span>
                  </button>
                </div>
              </div>
            </form>
          ) : (
            /* STEP 2: MANDATORY CONFIGURED OTP */
            <form onSubmit={handleStep2Submit} className="space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>
                  {pending2FA.otpMode === 'email_and_sms'
                    ? 'Dual Two-Factor Verification'
                    : pending2FA.otpMode === 'sms_only'
                    ? 'SMS OTP Verification'
                    : 'Email OTP Verification'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300">
                <div className="font-bold mb-1">
                  Verifying: {pending2FA.user.fullName} ({pending2FA.user.role.toUpperCase()})
                </div>
                <p className="leading-relaxed">
                  {pending2FA.otpMode === 'email_only' && `Enter the 6-digit code sent to ${pending2FA.user.email}.`}
                  {pending2FA.otpMode === 'sms_only' && `Enter the 6-digit SMS code dispatched to Rwanda phone ${pending2FA.user.phone}.`}
                  {pending2FA.otpMode === 'email_and_sms' && `Dual Authentication active: Enter both the email code sent to ${pending2FA.user.email} and SMS code sent to ${pending2FA.user.phone}.`}
                </p>
              </div>

              {step2Error && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{step2Error}</span>
                </div>
              )}

              {/* Email OTP Field */}
              {(pending2FA.otpMode === 'email_only' || pending2FA.otpMode === 'email_and_sms') && (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-blue-500" />
                      <span>Email OTP Code *</span>
                    </label>
                    {pending2FA.expectedEmailCode && (
                      <button
                        type="button"
                        onClick={handleAutofillEmail}
                        className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedEmail ? 'Copied' : `Demo: ${pending2FA.expectedEmailCode}`}</span>
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={emailOtpInput}
                    onChange={(e) => setEmailOtpInput(e.target.value)}
                    placeholder="e.g. 123456"
                    className="w-full text-center text-lg font-mono tracking-widest px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              )}

              {/* SMS OTP Field */}
              {(pending2FA.otpMode === 'sms_only' || pending2FA.otpMode === 'email_and_sms') && (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Rwanda SMS OTP Code *</span>
                    </label>
                    {pending2FA.expectedSmsCode && (
                      <button
                        type="button"
                        onClick={handleAutofillSms}
                        className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedSms ? 'Copied' : `Demo: ${pending2FA.expectedSmsCode}`}</span>
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={smsOtpInput}
                    onChange={(e) => setSmsOtpInput(e.target.value)}
                    placeholder="e.g. 123456"
                    className="w-full text-center text-lg font-mono tracking-widest px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all"
              >
                <span>{t('verifyCodeBtn')}</span>
                <ShieldCheck className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between pt-2 text-xs">
                <button
                  type="button"
                  onClick={resend2FACode}
                  className="text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t('resendCode')}</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.location.reload()}
                  className="text-slate-500 hover:underline"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

        </div>

        {/* Security badge notice */}
        <div className="mt-6 text-center text-xs text-slate-400 flex items-center justify-center gap-1.5">
          <KeyRound className="w-3.5 h-3.5 text-emerald-500" />
          <span>Encrypted Session · bcrypt & TOTP 2FA Protocol</span>
        </div>

      </div>
    </div>
  );
};
