import express from 'express';
import { getDeliveryLogs, sendTestDispatch } from '../controllers/notificationController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = express.Router();

router.get('/delivery-logs', authenticateToken, requireRole(['director']), getDeliveryLogs);
router.post('/test-dispatch', authenticateToken, requireRole(['director']), sendTestDispatch);

export default router;
