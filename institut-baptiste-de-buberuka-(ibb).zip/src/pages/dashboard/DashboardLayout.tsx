/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.tsx';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { NotificationDropdown } from '../../components/common/NotificationDropdown.tsx';
import {
  GraduationCap,
  LayoutDashboard,
  Users,
  Package,
  Truck,
  FileBarChart,
  Clock,
  ShieldAlert,
  LogOut,
  Sun,
  Moon,
  Globe,
  Menu,
  X,
  ChevronRight,
  ChevronDown,
  ShieldCheck,
  Award,
  UserCheck,
  Home
} from 'lucide-react';

interface DirectorNavCategory {
  id: string;
  name: string;
  categoryIcon: React.ComponentType<{ className?: string }>;
  headerClass: string;
  iconClass: string;
  items: {
    label: string;
    path: string;
    icon: React.ComponentType<{ className?: string }>;
    subtitle?: string;
  }[];
}

const DIRECTOR_CATEGORIES: DirectorNavCategory[] = [
  {
    id: 'cat_overview',
    name: '1. DASHBOARD OVERVIEW',
    categoryIcon: LayoutDashboard,
    headerClass:
      'bg-slate-900 text-white border-slate-950 hover:bg-slate-800 dark:bg-slate-950 dark:text-blue-100 dark:border-slate-800 dark:hover:bg-slate-900',
    iconClass: 'text-blue-300',
    items: [
      {
        label: 'Director Executive Overview',
        path: '/dashboard/director',
        icon: LayoutDashboard,
        subtitle: 'Overview & key performance metrics'
      }
    ]
  },
  {
    id: 'cat_academics',
    name: '2. STUDENTS & ACADEMIC MANAGEMENT',
    categoryIcon: GraduationCap,
    headerClass:
      'bg-blue-50 text-blue-950 border-blue-200/90 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-100 dark:border-blue-800/80 dark:hover:bg-blue-900/60',
    iconClass: 'text-blue-600 dark:text-blue-400',
    items: [
      {
        label: 'Student Admissions Management',
        path: '/dashboard/admissions',
        icon: Users,
        subtitle: 'Admissions intake & verification'
      },
      {
        label: 'Approved Students Register',
        path: '/dashboard/approved-students',
        icon: GraduationCap,
        subtitle: 'Official student registry'
      },
      {
        label: 'Academic Grading & Admission Settings',
        path: '/dashboard/academic-policy',
        icon: Award,
        subtitle: 'Grading policies & level cutoffs'
      }
    ]
  },
  {
    id: 'cat_inventory',
    name: '3. INVENTORY & STOCK MANAGEMENT',
    categoryIcon: Package,
    headerClass:
      'bg-emerald-50 text-emerald-950 border-emerald-200/90 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:text-emerald-100 dark:border-emerald-800/80 dark:hover:bg-emerald-900/60',
    iconClass: 'text-emerald-600 dark:text-emerald-400',
    items: [
      {
        label: 'Food Inventory Management',
        path: '/dashboard/stock',
        icon: Package,
        subtitle: 'Food commodities & stock balance'
      },
      {
        label: 'Stock Working Hours & Scheduling',
        path: '/dashboard/schedule',
        icon: Clock,
        subtitle: 'Stock window hours & overrides'
      },
      {
        label: 'Supplier Relationship Management',
        path: '/dashboard/suppliers',
        icon: Truck,
        subtitle: 'Vendors, TINs & delivery history'
      }
    ]
  },
  {
    id: 'cat_staff',
    name: '4. STAFF & ACCESS CONTROL',
    categoryIcon: ShieldCheck,
    headerClass:
      'bg-purple-50 text-purple-950 border-purple-200/90 hover:bg-purple-100 dark:bg-purple-950/60 dark:text-purple-100 dark:border-purple-800/80 dark:hover:bg-purple-900/60',
    iconClass: 'text-purple-600 dark:text-purple-400',
    items: [
      {
        label: 'Staff Access Control',
        path: '/dashboard/access-control',
        icon: ShieldCheck,
        subtitle: 'Staff accounts & role permissions'
      }
    ]
  },
  {
    id: 'cat_reports',
    name: '5. REPORTS & ANALYTICS',
    categoryIcon: FileBarChart,
    headerClass:
      'bg-teal-50 text-teal-950 border-teal-200/90 hover:bg-teal-100 dark:bg-teal-950/60 dark:text-teal-100 dark:border-teal-800/80 dark:hover:bg-teal-900/60',
    iconClass: 'text-teal-600 dark:text-teal-400',
    items: [
      {
        label: 'Reports & Analytics',
        path: '/dashboard/reports',
        icon: FileBarChart,
        subtitle: 'Financial, student & inventory ledgers'
      }
    ]
  },
  {
    id: 'cat_audit',
    name: '6. SYSTEM AUDIT & ACTIVITY',
    categoryIcon: ShieldAlert,
    headerClass:
      'bg-amber-50 text-amber-950 border-amber-200/90 hover:bg-amber-100 dark:bg-amber-950/60 dark:text-amber-100 dark:border-amber-800/80 dark:hover:bg-amber-900/60',
    iconClass: 'text-amber-600 dark:text-amber-400',
    items: [
      {
        label: 'System Audit Logs',
        path: '/dashboard/audit',
        icon: ShieldAlert,
        subtitle: 'Immutable system security trail'
      }
    ]
  },
  {
    id: 'cat_profile',
    name: '7. ACCOUNT & PROFILE',
    categoryIcon: UserCheck,
    headerClass:
      'bg-indigo-50 text-indigo-950 border-indigo-200/90 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-100 dark:border-indigo-800/80 dark:hover:bg-indigo-900/60',
    iconClass: 'text-indigo-600 dark:text-indigo-400',
    items: [
      {
        label: 'Director Administrative Profile',
        path: '/dashboard/profile',
        icon: UserCheck,
        subtitle: 'Profile & strong password credentials'
      }
    ]
  }
];

export const DashboardLayout: React.FC = () => {
  const { user, logout, isAuthenticated, hasPermission } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Collapsible categories state for Director sidebar
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  // Automatically expand category containing the active page
  useEffect(() => {
    if (user?.role === 'director') {
      const activeCat = DIRECTOR_CATEGORIES.find((cat) =>
        cat.items.some((item) => item.path === location.pathname)
      );
      if (activeCat && collapsedCategories[activeCat.id]) {
        setCollapsedCategories((prev) => ({
          ...prev,
          [activeCat.id]: false
        }));
      }
    }
  }, [location.pathname, user?.role]);

  // If not logged in, redirect to login declaratively
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path: string) => location.pathname === path;

  const toggleCategoryCollapse = (catId: string) => {
    setCollapsedCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId]
    }));
  };

  // Nav items for Accountant and Animator (preserved as original)
  const getStandardNavItems = () => {
    const items = [];
    if (user.role === 'accountant') {
      items.push({
        label: 'Accountant Overview',
        path: '/dashboard/accountant',
        icon: LayoutDashboard
      });
      if (hasPermission('stock_view') || hasPermission('stock_in')) {
        items.push({
          label: 'Food Stock Management',
          path: '/dashboard/stock',
          icon: Package
        });
      }
      if (hasPermission('suppliers')) {
        items.push({
          label: 'Supplier Relationship Management',
          path: '/dashboard/suppliers',
          icon: Truck
        });
      }
      if (hasPermission('reports_financial') || hasPermission('reports_stock')) {
        items.push({
          label: 'Reports & Analytics',
          path: '/dashboard/reports',
          icon: FileBarChart
        });
      }
      items.push({
        label: 'Account & Profile',
        path: '/dashboard/profile',
        icon: UserCheck
      });
    } else if (user.role === 'animator') {
      items.push({
        label: 'Animator Overview',
        path: '/dashboard/animator',
        icon: LayoutDashboard
      });
      if (hasPermission('stock_view') || hasPermission('stock_out')) {
        items.push({
          label: 'Daily Stock Out & Meals',
          path: '/dashboard/stock',
          icon: Package
        });
      }
      if (hasPermission('suppliers')) {
        items.push({
          label: 'Suppliers Directory (View Only)',
          path: '/dashboard/suppliers',
          icon: Truck
        });
      }
      if (hasPermission('reports_stock')) {
        items.push({
          label: 'Stock Out Reports',
          path: '/dashboard/reports',
          icon: FileBarChart
        });
      }
      items.push({
        label: 'Account & Profile',
        path: '/dashboard/profile',
        icon: UserCheck
      });
    }
    return items;
  };

  const standardNavItems = getStandardNavItems();

  const getRoleBadgeColor = () => {
    switch (user.role) {
      case 'director':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'accountant':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800';
      case 'animator':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  // Render navigation links: 7 categories for Director, flat list for Accountant/Animator
  const renderNavContent = (isMobile = false) => {
    if (user.role === 'director') {
      return (
        <div className="space-y-4">
          {DIRECTOR_CATEGORIES.map((cat) => {
            const hasActiveChild = cat.items.some((item) => isActive(item.path));
            const isCollapsed = !hasActiveChild && !!collapsedCategories[cat.id];

            return (
              <div key={cat.id} className="space-y-1">
                {/* Category Header with Distinct Background & Icon */}
                <button
                  type="button"
                  onClick={() => toggleCategoryCollapse(cat.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl border text-[10px] sm:text-[10.5px] font-extrabold uppercase tracking-wide transition-all shadow-xs cursor-pointer select-none ${cat.headerClass}`}
                >
                  <div className="flex items-center gap-2 truncate">
                    {React.createElement(cat.categoryIcon, {
                      className: `w-3.5 h-3.5 shrink-0 ${cat.iconClass}`
                    })}
                    <span className="truncate">{cat.name}</span>
                  </div>
                  <span className="shrink-0 ml-1.5 opacity-80">
                    {isCollapsed ? (
                      <ChevronRight className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </span>
                </button>

                {/* Category Items */}
                {!isCollapsed && (
                  <div className="space-y-0.5 pl-1">
                    {cat.items.map((item) => {
                      const Icon = item.icon;
                      const active = isActive(item.path);

                      return (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={() => {
                            if (isMobile) setSidebarOpen(false);
                          }}
                          className={`group flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                            active
                              ? 'bg-emerald-600 text-white font-bold shadow-sm shadow-emerald-600/30'
                              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                          }`}
                        >
                          <Icon
                            className={`w-4 h-4 shrink-0 transition-colors ${
                              active
                                ? 'text-white'
                                : 'text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400'
                            }`}
                          />
                          <span className="truncate leading-tight">{item.label}</span>
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      );
    }

    // Standard list for Accountant and Animator
    return (
      <div className="space-y-1">
        {standardNavItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => {
                if (isMobile) setSidebarOpen(false);
              }}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                active
                  ? 'bg-emerald-600 text-white font-bold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-white' : 'text-slate-400'}`} />
              <span className="truncate">{item.label}</span>
            </Link>
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      {/* Sidebar Desktop (Width: 280px for clear 7-category readability) */}
      <aside className="hidden lg:flex lg:flex-col w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0 select-none">
        {/* Brand */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] flex items-center justify-center text-white shadow-md">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm tracking-tight text-slate-900 dark:text-white leading-none">
              KARENGE ADVENTIST
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-1">
              Secondary School Portal
            </div>
          </div>
        </div>

        {/* User Profile Card */}
        <Link
          to="/dashboard/profile"
          className="p-3 mx-3 my-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50/50 dark:bg-slate-800/60 dark:hover:bg-slate-800 transition-colors border border-slate-100 dark:border-slate-800 flex items-center gap-3"
        >
          {user.avatarUrl ? (
            <img
              src={user.avatarUrl}
              alt={user.fullName}
              className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
              {user.fullName.charAt(0)}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
              {user.fullName}
            </div>
            <div className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-md border mt-0.5 ${getRoleBadgeColor()}`}>
              {user.role === 'director' ? 'DIRECTOR (SUPER ADMIN)' : user.role.toUpperCase()}
            </div>
          </div>
        </Link>

        {/* Navigation Categories Container */}
        <nav className="flex-1 px-3 py-2 overflow-y-auto">
          {renderNavContent(false)}
        </nav>

        {/* Bottom Utility */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 space-y-1">
          <Link
            to="/"
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:text-emerald-700 dark:text-slate-200 dark:hover:text-emerald-400 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/40 border border-slate-200/80 dark:border-slate-700/80 transition-all cursor-pointer min-h-[40px]"
            title="Navigate to Karenge Adventist Secondary School public homepage"
          >
            <Home className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{language === 'rw' ? 'Ahabanza' : 'Home'}</span>
          </Link>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Layout Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="Open sidebar menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500">
              <span className="font-medium">Karenge Adventist</span>
              <ChevronRight className="w-3.5 h-3.5" />
              <span className="font-semibold text-slate-900 dark:text-white capitalize">
                {location.pathname.split('/')[2] || 'Portal'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Real-time Notifications */}
            <NotificationDropdown />

            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold transition-colors cursor-pointer"
              title="Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'en' ? 'RW' : 'EN'}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
              title="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-600" />}
            </button>
          </div>
        </header>

        {/* Mobile Sidebar Modal */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
              onClick={() => setSidebarOpen(false)}
            />
            <div className="relative w-80 max-w-[85vw] bg-white dark:bg-slate-900 h-full p-5 flex flex-col z-10 shadow-2xl">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] flex items-center justify-center text-white shadow-sm">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <span className="font-extrabold text-sm text-slate-900 dark:text-white">KARENGE ADVENTIST</span>
                </div>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User snippet in mobile drawer */}
              <Link
                to="/dashboard/profile"
                onClick={() => setSidebarOpen(false)}
                className="mt-3 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center gap-2.5"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                  {user.fullName.charAt(0)}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {user.fullName}
                  </div>
                  <div className={`inline-block text-[9px] font-bold px-1.5 py-0.5 rounded border ${getRoleBadgeColor()}`}>
                    {user.role === 'director' ? 'DIRECTOR' : user.role.toUpperCase()}
                  </div>
                </div>
              </Link>

              <nav className="flex-1 py-4 overflow-y-auto">
                {renderNavContent(true)}
              </nav>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1">
                <Link
                  to="/"
                  onClick={() => setSidebarOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-700 hover:text-emerald-700 dark:text-slate-200 dark:hover:text-emerald-400 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/40 border border-slate-200/80 dark:border-slate-700/80 transition-all cursor-pointer min-h-[40px]"
                  title="Navigate to Karenge Adventist Secondary School public homepage"
                >
                  <Home className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>{language === 'rw' ? 'Ahabanza' : 'Home'}</span>
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
