/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'director' | 'accountant' | 'animator';

export type PermissionModule =
  | 'stock_view'
  | 'stock_in'
  | 'stock_out'
  | 'stock_correction'
  | 'suppliers'
  | 'admissions_view'
  | 'admissions_approve'
  | 'academic_rules'
  | 'staff_management'
  | 'reports_financial'
  | 'reports_stock'
  | 'audit_logs'
  | 'system_settings';

export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'approve' | 'export' | 'manage';

export interface UserPermissionConfig {
  moduleId: PermissionModule;
  moduleName: string;
  allowedActions: PermissionAction[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: UserRole;
  phone: string;
  avatarUrl?: string;
  twoFactorEnabled: boolean;
  twoFactorSecret?: string;
  status: 'active' | 'inactive';
  permissions: PermissionModule[]; // Granular active permissions
  mustChangePassword?: boolean;
  passwordHash?: string;
  createdAt: string;
  lastLoginAt?: string;
}

export type ApplicationStatus =
  | 'pending'
  | 'under_review'
  | 'eligible'
  | 'automatically_rejected'
  | 'approved'
  | 'rejected';

export type DepartmentType = 'software_development' | 'automobile_technology';
export type AcademicLevel = 'L3' | 'L4' | 'L5';

export interface StudentApplication {
  id: string;
  trackingNumber: string;
  // Personal Info
  fullName: string;
  fatherName: string;
  motherName: string;
  dateOfBirth: string;
  gender: 'male' | 'female';
  phone: string;
  email: string;
  residentialAddress: string;
  district: string;
  sector: string;
  // Academic Info
  applyingLevel: AcademicLevel;
  department: DepartmentType;
  previousSchool: string;
  previousAcademicLevel: string; // e.g. "Senior 3", "Level 3", "Level 4"
  academicScorePercentage: number; // e.g. 74.5%
  s3AggregateScore?: number;
  // Documents
  resultSlipFileName: string;
  resultSlipUrl: string;
  passportPhotoFileName: string;
  passportPhotoUrl: string;
  // Status and Review
  status: ApplicationStatus;
  autoRejectionReason?: string;
  isEligibleForBoarding?: boolean;
  hasDirectorOverride?: boolean;
  directorOverrideReason?: string;
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  reviewNotes?: string;
  rejectionReason?: string;
  academicYear: string;
}

export interface ApprovedStudent {
  id: string;
  applicationId: string;
  studentName: string;
  applicationNumber: string;
  admissionLevel: AcademicLevel;
  department: DepartmentType;
  academicScore: number;
  approvalDate: string;
  approvedBy: string;
  boardingStatus: 'day_scholar' | 'boarding_scholar';
  academicYear: string;
  status: 'enrolled' | 'pending_registration';
}

export interface AcademicGradingPolicy {
  id: string;
  academicYear: string; // e.g. "2026/2027"
  minimumAdmissionPercentage: number; // e.g. 50%
  minimumPassingPercentage: number; // e.g. 50%
  boardingEligibilityPercentage: number; // e.g. 80%
  effectiveDate: string;
  rulesPerLevel: {
    level: AcademicLevel;
    minScore: number;
    description: string;
  }[];
  gradeRanges: {
    grade: string;
    labelEn: string;
    labelRw: string;
    minPercentage: number;
    maxPercentage: number;
    standing: 'distinction' | 'credit' | 'pass' | 'fail_repeat';
  }[];
  promotionRequirements: string;
  repeatingRequirements: string;
  updatedAt: string;
  updatedBy: string;
}

export type OTPVerificationMode = 'email_only' | 'sms_only' | 'email_and_sms';
export type OTPAuthMode = OTPVerificationMode;

export interface OTPSettings {
  mode: OTPVerificationMode;
  codeExpiryMinutes: number;
  maxAttempts: number;
  resendCooldownSeconds: number;
  smsProviderConfigured: boolean;
  smsProviderName: string;
  emailSmtpConfigured: boolean;
  whatsAppConfigured: boolean;
  updatedAt: string;
}

export interface NotificationChannelSettings {
  inAppEnabled: boolean;
  emailEnabled: boolean;
  smsEnabled: boolean;
  whatsAppEnabled: boolean;
  smsSenderId: string;
  whatsAppBusinessNumber: string;
  smtpHost: string;
  smtpPort: number;
  smtpUser: string;
  notificationRecipients: {
    role: UserRole;
    phone: string;
    email: string;
  }[];
}

export type DeliveryStatus = 'pending' | 'sent' | 'delivered' | 'failed';

export interface NotificationDeliveryLog {
  id: string;
  channel: 'email' | 'sms' | 'whatsapp' | 'in_app';
  recipient: string;
  subject: string;
  content: string;
  status: DeliveryStatus;
  providerResponse?: string;
  timestamp: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  nameRw: string;
  nameEn: string;
  category: 'cereal' | 'flour' | 'oil' | 'vegetable' | 'tuber' | 'sweetener' | 'spice' | 'other';
  unit: 'Kg' | 'Litres' | 'Pieces' | 'Bags' | 'Cartons';
  minThreshold: number;
  targetCapacity: number;
  unitCostRwf: number;
  currentStock: number;
  lastRestockedAt?: string;
  shelfLifeDays?: number;
}

export type TransactionType = 'stock_in' | 'stock_out' | 'correction';

export interface StockTransaction {
  id: string;
  transactionNumber: string;
  productId: string;
  productName: string;
  type: TransactionType;
  quantity: number;
  unit: string;
  unitPriceRwf?: number;
  totalPriceRwf?: number;
  supplierId?: string;
  supplierName?: string;
  deliveryDate?: string;
  expirationDate?: string;
  mealCategory?: 'breakfast' | 'lunch' | 'dinner' | 'weekend_meal' | 'special_event';
  purposeNotes?: string;
  performedByUserId: string;
  performedByUserName: string;
  performedByRole: UserRole;
  isDelegatedStockIn?: boolean;
  isEmergencyOverride?: boolean;
  overrideReason?: string;
  correctionOriginalTxId?: string;
  correctionReason?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  tinNumber: string;
  suppliedProducts: string[];
  rating: number;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface StockSchedule {
  id: string;
  morningStart: string;
  morningEnd: string;
  eveningStart: string;
  eveningEnd: string;
  timezone: string;
  enforceHours: boolean;
  emergencyOverrideActive: boolean;
  overrideExpiry?: string;
  overrideReason?: string;
  overrideSetBy?: string;
  updatedAt: string;
}

export interface StockPermissionDelegation {
  id: string;
  grantedToUserId: string;
  grantedToUserName: string;
  grantedByUserId: string;
  grantedByUserName: string;
  permission: 'stock_in';
  startsAt: string;
  expiresAt: string;
  status: 'active' | 'revoked' | 'expired';
  reason: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  titleRw: string;
  message: string;
  messageRw: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  category: 'stock_in' | 'stock_out' | 'low_stock' | 'expiration' | 'admission' | 'permission' | 'override' | 'auth';
  targetRoles: UserRole[];
  readBy: string[];
  relatedId?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  category: 'auth' | 'admission' | 'stock_in' | 'stock_out' | 'stock_schedule' | 'permission' | 'system' | 'supplier' | 'academic_rules';
  userId: string;
  userName: string;
  userRole: UserRole;
  details: string;
  ipAddress?: string;
  timestamp: string;
}
