/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { StudentApplication, ApplicationStatus } from '../../types/index.ts';
import {
  Search,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  Printer,
  Award,
  AlertCircle,
  Calendar,
  Building,
  UserCheck,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';

export const TrackApplicationPage: React.FC = () => {
  const { t, language } = useLanguage();
  const [searchParams] = useSearchParams();

  const [trackingInput, setTrackingInput] = useState(searchParams.get('tracking') || '');
  const [application, setApplication] = useState<StudentApplication | null>(null);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    const urlTracking = searchParams.get('tracking');
    if (urlTracking) {
      setTrackingInput(urlTracking);
      handleSearchTracking(urlTracking);
    }
  }, [searchParams]);

  const handleSearchTracking = (query: string) => {
    const trimmed = query.trim().toUpperCase();
    if (!trimmed) return;

    const all = StorageService.getApplications();
    const match = all.find(
      (a) =>
        a.trackingNumber.toUpperCase() === trimmed ||
        a.phone.replace(/\s+/g, '') === trimmed.replace(/\s+/g, '')
    );

    setApplication(match || null);
    setSearched(true);
  };

  const getStatusBadge = (status: ApplicationStatus) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t('statusApproved')}</span>
          </span>
        );
      case 'automatically_rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Auto-Rejected (Below Threshold)</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <XCircle className="w-3.5 h-3.5" />
            <span>{t('statusRejected')}</span>
          </span>
        );
      case 'eligible':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Eligible for Director Review</span>
          </span>
        );
      case 'under_review':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <Clock className="w-3.5 h-3.5" />
            <span>{t('statusUnderReview')}</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700">
            <Clock className="w-3.5 h-3.5" />
            <span>{t('statusPending')}</span>
          </span>
        );
    }
  };

  return (
    <div className="py-12 bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-slate-100 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            Official Online Verification
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mt-1 mb-3 text-slate-900 dark:text-white">
            {t('trackTitle')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            {t('trackSubtitle')}
          </p>
        </div>

        {/* Search Bar */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm mb-8">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearchTracking(trackingInput);
            }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={trackingInput}
                onChange={(e) => setTrackingInput(e.target.value)}
                placeholder="Enter tracking number (e.g. IBB-2026-01928) or phone number..."
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono uppercase text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tracking-wider"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" />
              <span>{t('checkStatusBtn')}</span>
            </button>
          </form>

          {/* Quick Demo Autofill Suggestions */}
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
            <span>Demo Tracking Numbers:</span>
            <button
              type="button"
              onClick={() => {
                setTrackingInput('IBB-2026-01928');
                handleSearchTracking('IBB-2026-01928');
              }}
              className="px-2.5 py-1 rounded bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-mono hover:underline"
            >
              IBB-2026-01928 (L3 Approved)
            </button>
            <button
              type="button"
              onClick={() => {
                setTrackingInput('IBB-2026-05612');
                handleSearchTracking('IBB-2026-05612');
              }}
              className="px-2.5 py-1 rounded bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-mono hover:underline"
            >
              IBB-2026-05612 (L5 Approved)
            </button>
            <button
              type="button"
              onClick={() => {
                setTrackingInput('IBB-2026-08341');
                handleSearchTracking('IBB-2026-08341');
              }}
              className="px-2.5 py-1 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-mono hover:underline"
            >
              IBB-2026-08341 (L4 In Review)
            </button>
            <button
              type="button"
              onClick={() => {
                setTrackingInput('IBB-2026-09102');
                handleSearchTracking('IBB-2026-09102');
              }}
              className="px-2.5 py-1 rounded bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-mono hover:underline"
            >
              IBB-2026-09102 (Auto-Rejected)
            </button>
          </div>
        </div>

        {/* Results Area */}
        {searched && (
          <>
            {application ? (
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
                
                {/* Status Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-slate-500 block mb-1">
                      Tracking Identification
                    </span>
                    <span className="font-mono text-xl font-extrabold text-slate-900 dark:text-white">
                      {application.trackingNumber}
                    </span>
                  </div>
                  <div>{getStatusBadge(application.status)}</div>
                </div>

                {/* Candidate Overview */}
                <div className="py-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-xs">
                  <div>
                    <span className="text-slate-500 block mb-1">Applicant Name</span>
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {application.fullName}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Admitted Entry Level</span>
                    <span className="inline-flex items-center gap-1 font-mono font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                      {application.applyingLevel} · {application.applyingLevel === 'L3' ? 'Foundation' : application.applyingLevel === 'L4' ? 'Intermediate' : 'Advanced'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Specialization</span>
                    <span className="font-bold text-slate-900 dark:text-white">
                      {application.department === 'software_development'
                        ? 'Software Development'
                        : 'Automobile Technology'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Verified Score</span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white text-sm tabular-nums">
                      {application.academicScorePercentage}%
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Previous School</span>
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      {application.previousSchool} ({application.previousAcademicLevel || 'Senior 3'})
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Submitted On</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">
                      {new Date(application.submittedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Parent Contact</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">
                      {application.phone}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block mb-1">Academic Year</span>
                    <span className="font-mono text-slate-700 dark:text-slate-300">
                      {application.academicYear || '2026/2027'}
                    </span>
                  </div>
                </div>

                {/* Auto Rejection Alert (if automatically rejected) */}
                {application.status === 'automatically_rejected' && (
                  <div className="mb-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-300 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-rose-600" />
                      <span>Automatic Rejection Policy Notice</span>
                    </div>
                    <p className="leading-relaxed">
                      {application.autoRejectionReason ||
                        `Candidate academic score (${application.academicScorePercentage}%) does not satisfy the school minimum intake threshold. Application is preserved in archive.`}
                    </p>
                    <p className="text-[11px] opacity-80 pt-1">
                      Note: The School Director reserves the constitutional authority to review special waiver applications upon formal in-person appeal.
                    </p>
                  </div>
                )}

                {/* Director's Review Notes (if available) */}
                {application.reviewNotes && (
                  <div className="mb-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs">
                    <div className="font-bold text-slate-900 dark:text-white mb-1 flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4 text-emerald-500" />
                      <span>{t('directorReviewNotes')}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 leading-relaxed italic">
                      &ldquo;{application.reviewNotes}&rdquo;
                    </p>
                    {application.reviewedBy && (
                      <span className="text-[11px] text-slate-500 block mt-2 font-medium">
                        — Reviewed by: {application.reviewedBy}
                      </span>
                    )}
                  </div>
                )}

                {/* Printable Acceptance Certificate (if approved) */}
                {application.status === 'approved' && (
                  <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 mt-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <Award className="w-8 h-8 text-emerald-600 dark:text-emerald-400 shrink-0" />
                        <div>
                          <h4 className="text-sm font-bold text-emerald-950 dark:text-emerald-200">
                            Official Admission Acceptance Confirmed ({application.applyingLevel})
                          </h4>
                          <p className="text-xs text-emerald-800 dark:text-emerald-400">
                            Academic Year {application.academicYear || '2026/2027'} · {
                              application.isEligibleForBoarding ? 'Admitted as Boarding Scholar' : 'Admitted as Day Scholar'
                            } · Reporting date: September 2026.
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => window.print()}
                        className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-sm transition-all whitespace-nowrap"
                      >
                        <Printer className="w-4 h-4" />
                        <span>{t('downloadAcceptanceLetter')}</span>
                      </button>
                    </div>
                  </div>
                )}

              </div>
            ) : (
              <div className="p-8 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
                <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
                  No Record Found
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mb-6">
                  {t('noApplicationFound')}
                </p>
                <Link
                  to="/apply"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all"
                >
                  <span>{t('heroCtaApply')}</span>
                </Link>
              </div>
            )}
          </>
        )}

      </div>
    </div>
  );
};
