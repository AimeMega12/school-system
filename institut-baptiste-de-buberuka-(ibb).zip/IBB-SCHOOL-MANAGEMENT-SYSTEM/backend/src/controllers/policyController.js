/**
 * Academic Grading & Admission Policy Controller
 */
import { logActivity } from '../services/auditService.js';

let activePolicy = {
  id: 'policy_2026_v1',
  academicYear: '2026/2027',
  minimumAdmissionPercentage: 50.0,
  minimumPassingPercentage: 50.0,
  boardingEligibilityPercentage: 80.0,
  effectiveDate: '2026-01-01',
  rulesPerLevel: [
    { level: 'L3', minScore: 50.0, description: 'Completion of Senior 3 with minimum 50% score.' },
    { level: 'L4', minScore: 55.0, description: 'Completion of Level 3 TVET with minimum 55% verified marks.' },
    { level: 'L5', minScore: 60.0, description: 'Completion of Level 4 TVET with minimum 60% technical competence.' }
  ],
  gradeRanges: [
    { grade: 'Distinction (A)', labelEn: 'Distinction / Boarding Priority', minPercentage: 80.0, maxPercentage: 100.0, standing: 'distinction' },
    { grade: 'Credit (B)', labelEn: 'High Technical Credit', minPercentage: 65.0, maxPercentage: 79.99, standing: 'credit' },
    { grade: 'Pass (C)', labelEn: 'Technical Pass', minPercentage: 50.0, maxPercentage: 64.99, standing: 'pass' },
    { grade: 'Fail (F)', labelEn: 'Fail / Repeat Required', minPercentage: 0.0, maxPercentage: 49.99, standing: 'fail_repeat' }
  ],
  promotionRequirements: 'Minimum 50% annual technical cumulative average.',
  repeatingRequirements: 'Scores between 40% and 49.9% may repeat once.'
};

export const getPolicy = (req, res) => {
  res.json({ success: true, policy: activePolicy });
};

export const updatePolicy = async (req, res) => {
  const updatedData = req.body;
  activePolicy = {
    ...activePolicy,
    ...updatedData,
    effectiveDate: new Date().toISOString().split('T')[0]
  };

  await logActivity({
    action: 'ACADEMIC_POLICY_UPDATED',
    category: 'academic_rules',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Director updated academic policy: Min Admission=${activePolicy.minimumAdmissionPercentage}%, Boarding=${activePolicy.boardingEligibilityPercentage}%`,
    ipAddress: req.ip
  });

  res.json({ success: true, policy: activePolicy });
};

export default { getPolicy, updatePolicy };
