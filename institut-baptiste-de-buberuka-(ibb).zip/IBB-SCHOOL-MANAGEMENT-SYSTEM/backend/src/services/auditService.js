/**
 * Immutable Activity Audit Logging Service
 */
import { query } from '../config/database.js';

export const logActivity = async ({ action, category, userId, userName, userRole, details, ipAddress = '127.0.0.1' }) => {
  const timestamp = new Date().toISOString();
  console.log(`🔒 [AUDIT ${timestamp}] [${category.toUpperCase()}] ${action} by ${userName} (${userRole}): ${details}`);

  try {
    const id = `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    await query(
      `INSERT INTO activity_audit_logs (id, action, category, user_id, user_name, user_role, details, ip_address, timestamp)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [id, action, category, userId, userName, userRole, details, ipAddress]
    );
  } catch (err) {
    // Non-blocking in fallback mode
  }
};

export default { logActivity };
