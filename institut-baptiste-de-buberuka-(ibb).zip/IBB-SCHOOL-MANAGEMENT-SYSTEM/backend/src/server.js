/**
 * ==============================================================================
 * INSTITUT BAPTISTE DE BUBERUKA (IBB) - RWANDA
 * Main Express.js REST API Server & Real-time Socket.IO Gateway
 * ==============================================================================
 */
import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';

// Load Environment Variables
dotenv.config();

// Route Handlers
import authRoutes from './routes/authRoutes.js';
import applicationRoutes from './routes/applicationRoutes.js';
import policyRoutes from './routes/policyRoutes.js';
import studentRoutes from './routes/studentRoutes.js';
import stockRoutes from './routes/stockRoutes.js';
import supplierRoutes from './routes/supplierRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import reportRoutes from './routes/reportRoutes.js';

const app = express();
const server = http.createServer(app);

// Initialize Socket.IO Real-time Engine
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE']
  }
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static Uploads Folder
const uploadsPath = path.resolve('uploads');
app.use('/uploads', express.static(uploadsPath));

// Socket.IO Room Channels
io.on('connection', (socket) => {
  console.log(`🔌 [Socket.IO] Client connected: ${socket.id}`);

  socket.on('join_role_room', (role) => {
    socket.join(`role_${role}`);
    console.log(`📡 [Socket.IO] Client ${socket.id} joined room role_${role}`);
  });

  socket.on('disconnect', () => {
    console.log(`🔌 [Socket.IO] Client disconnected: ${socket.id}`);
  });
});

// Attach io to request
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    school: 'Institut Baptiste de Buberuka (IBB)',
    location: 'Buberuka, Burera District, Northern Province, Rwanda',
    serverTime: new Date().toISOString(),
    timezone: 'Africa/Kigali (CAT / UTC+2)'
  });
});

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/applications', applicationRoutes);
app.use('/api/policies', policyRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/stock', stockRoutes);
app.use('/api/suppliers', supplierRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/reports', reportRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Endpoint ${req.originalUrl} not found on IBB API Gateway.` });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal Server Error on IBB API Gateway',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`
==============================================================================
  INSTITUT BAPTISTE DE BUBERUKA (IBB) - RWANDA
  Backend REST API Server running on port ${PORT}
  Environment: ${process.env.NODE_ENV || 'development'}
  Health Check: http://localhost:${PORT}/api/health
==============================================================================
  `);
});
