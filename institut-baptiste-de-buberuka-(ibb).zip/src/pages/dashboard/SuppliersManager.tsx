/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { Supplier, Product } from '../../types/index.ts';
import {
  Truck,
  Plus,
  Phone,
  Mail,
  MapPin,
  Star,
  Search,
  CheckCircle2,
  AlertCircle,
  X,
  Trash2,
  Edit2,
  ShieldAlert,
  FileText
} from 'lucide-react';

export const SuppliersManager: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => StorageService.getSuppliers());
  const [products] = useState<Product[]>(() => StorageService.getProducts());
  const transactions = StorageService.getTransactions();

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [supplierToDelete, setSupplierToDelete] = useState<Supplier | null>(null);

  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Form State (for both Add and Edit)
  const [name, setName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [tinNumber, setTinNumber] = useState('');
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>(['prod_umuceri']);
  const [rating, setRating] = useState<number>(5);

  const reloadData = () => {
    setSuppliers(StorageService.getSuppliers());
  };

  // Role authorization helpers
  const canManageSuppliers = user?.role === 'accountant' || user?.role === 'director';

  const openAddModal = () => {
    setName('');
    setContactPerson('');
    setPhone('');
    setEmail('');
    setAddress('');
    setTinNumber('');
    setSelectedProductIds(['prod_umuceri']);
    setRating(5);
    setIsAddModalOpen(true);
  };

  const openEditModal = (sup: Supplier) => {
    if (!canManageSuppliers) return;
    setEditingSupplier(sup);
    setName(sup.name);
    setContactPerson(sup.contactPerson);
    setPhone(sup.phone);
    setEmail(sup.email || '');
    setAddress(sup.address);
    setTinNumber(sup.tinNumber || '');
    setSelectedProductIds(sup.suppliedProducts || []);
    setRating(sup.rating || 5);
  };

  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageSuppliers || !user) {
      setFeedback({
        type: 'error',
        message: 'HTTP 403 Forbidden: Only Accountant and Director can manage suppliers.'
      });
      return;
    }

    if (!name.trim() || !phone.trim()) {
      setFeedback({ type: 'error', message: 'Supplier name and telephone are required.' });
      return;
    }

    if (editingSupplier) {
      // Edit existing supplier
      const updated: Supplier = {
        ...editingSupplier,
        name: name.trim(),
        contactPerson: contactPerson.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address.trim(),
        tinNumber: tinNumber.trim(),
        suppliedProducts: selectedProductIds,
        rating
      };

      const res = StorageService.updateSupplier(updated, user);
      if (!res.success) {
        setFeedback({ type: 'error', message: res.error || 'Failed to update supplier.' });
        return;
      }

      setEditingSupplier(null);
      setFeedback({ type: 'success', message: `Updated supplier details for: ${updated.name}` });
    } else {
      // Add new supplier
      const newSupplier: Supplier = {
        id: `sup_${Date.now()}`,
        name: name.trim(),
        contactPerson: contactPerson.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address.trim(),
        tinNumber: tinNumber.trim(),
        suppliedProducts: selectedProductIds,
        rating,
        status: 'active',
        createdAt: new Date().toISOString()
      };

      StorageService.addSupplier(newSupplier);
      StorageService.addAuditLog({
        action: 'SUPPLIER_REGISTERED',
        category: 'supplier',
        userId: user.id,
        userName: user.fullName,
        userRole: user.role,
        details: `${user.role.toUpperCase()} registered new food vendor: ${newSupplier.name} (TIN: ${newSupplier.tinNumber})`,
        ipAddress: '197.243.34.82'
      });

      setIsAddModalOpen(false);
      setFeedback({ type: 'success', message: `Registered supplier: ${newSupplier.name}` });
    }

    reloadData();
    setTimeout(() => setFeedback(null), 5000);
  };

  const confirmDeleteSupplier = () => {
    if (!supplierToDelete || !user) return;

    if (!canManageSuppliers) {
      setFeedback({
        type: 'error',
        message: 'HTTP 403 Forbidden: Unauthorized deletion attempt. Only Accountant and Director can delete suppliers.'
      });
      setSupplierToDelete(null);
      return;
    }

    const res = StorageService.deleteSupplier(supplierToDelete.id, user);

    if (!res.success) {
      setFeedback({
        type: 'error',
        message: res.error || 'Failed to delete supplier.'
      });
    } else {
      setFeedback({
        type: 'success',
        message: `Supplier "${supplierToDelete.name}" was safely deleted from the active registry.`
      });
      reloadData();
    }

    setSupplierToDelete(null);
    setTimeout(() => setFeedback(null), 6000);
  };

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.contactPerson.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.tinNumber && s.tinNumber.includes(searchQuery))
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <DashboardPageHeader
        title="Supplier Relationship Management"
        subtitle="Registered food commodity vendors, institutional supply partners, and delivery history."
        variant="teal"
      >
        {canManageSuppliers && (
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20 cursor-pointer transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Supplier</span>
          </button>
        )}
      </DashboardPageHeader>

      {/* Role permission info banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
          <Truck className="w-4 h-4 text-emerald-600" />
          <span>
            <strong className="text-slate-800 dark:text-white">Active Permissions:</strong>{' '}
            {user?.role === 'accountant' && (
              <span className="text-blue-600 dark:text-blue-400 font-semibold">
                Accountant (Full Regular Supplier Management &amp; Deletion Authorized)
              </span>
            )}
            {user?.role === 'director' && (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                Director (Super Admin Oversight &amp; Audit Authority)
              </span>
            )}
            {user?.role === 'animator' && (
              <span className="text-amber-600 dark:text-amber-400 font-semibold">
                Animator (Read-Only Directory View)
              </span>
            )}
          </span>
        </div>
        <span className="text-[11px] text-slate-400">
          Protected by Backend RBAC &amp; Stock Consignment Integrity
        </span>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-start gap-2.5 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
          )}
          <span className="leading-relaxed">{feedback.message}</span>
        </div>
      )}

      {/* Search */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search vendor name, contact person, or TIN..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <span className="text-xs text-slate-500 font-medium hidden sm:block">
          {filteredSuppliers.length} vendors listed
        </span>
      </div>

      {/* Supplier Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSuppliers.map((sup) => {
          // Count past deliveries
          const linkedStockInTxs = transactions.filter(
            (t) => t.type === 'stock_in' && t.supplierId === sup.id
          );
          const deliveryCount = linkedStockInTxs.length;

          return (
            <div
              key={sup.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm flex flex-col justify-between hover:border-emerald-500/50 transition-colors"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-amber-500 text-xs font-bold">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{sup.rating}.0</span>
                    </div>

                    {/* Action Buttons: Accountant and Director only */}
                    {canManageSuppliers && (
                      <div className="flex items-center gap-1 ml-2">
                        <button
                          type="button"
                          onClick={() => openEditModal(sup)}
                          title="Edit supplier"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setSupplierToDelete(sup)}
                          title="Delete supplier"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                  {sup.name}
                </h3>
                <span className="text-[11px] font-mono text-slate-400 block mb-4">
                  TIN: {sup.tinNumber || '102948172'}
                </span>

                <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 mb-5">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">Contact:</span>
                    <span>{sup.contactPerson}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono">{sup.phone}</span>
                  </div>
                  {sup.email && (
                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{sup.email}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{sup.address}</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-500">
                  {deliveryCount} consignment{deliveryCount !== 1 ? 's' : ''} recorded
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-md">
                  Vetted Partner
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Add or Edit Supplier */}
      {(isAddModalOpen || editingSupplier) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingSupplier ? 'Edit Supplier Information' : 'Add New Food Supplier'}
              </h3>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingSupplier(null);
                }}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSupplier} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">Company / Cooperative Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Koperative Abahuje Burera"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Representative Person *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mugisha Patrick"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Telephone (+250) *</label>
                  <input
                    type="tel"
                    required
                    placeholder="+250 788 000 000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Email Address</label>
                  <input
                    type="email"
                    placeholder="supplier@supply.rw"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Rwanda Revenue TIN</label>
                  <input
                    type="text"
                    placeholder="100000000"
                    value={tinNumber}
                    onChange={(e) => setTinNumber(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Office / Depot Physical Address</label>
                <input
                  type="text"
                  placeholder="Musanze Commercial Center or Burera"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingSupplier(null);
                  }}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  {editingSupplier ? 'Update Supplier' : 'Save Supplier'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Dialog: Delete Supplier */}
      {supplierToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full p-6 text-xs space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/60 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Confirm Supplier Deletion
                </h3>
                <p className="text-[11px] text-slate-400">Accountant &amp; Director Authorization</p>
              </div>
            </div>

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              Are you sure you want to permanently delete supplier{' '}
              <strong className="text-slate-900 dark:text-white font-bold">
                "{supplierToDelete.name}"
              </strong>{' '}
              (TIN: {supplierToDelete.tinNumber || 'N/A'})?
            </p>

            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 space-y-1 text-[11px]">
              <div className="font-semibold flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                <span>Financial Audit Protection:</span>
              </div>
              <p>
                If this vendor has historical Stock In delivery records, deletion will be blocked by the system to preserve official accounting and audit ledgers.
              </p>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSupplierToDelete(null)}
                className="px-4 py-2 rounded-xl font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteSupplier}
                className="px-5 py-2 rounded-xl font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-md shadow-rose-600/20 cursor-pointer"
              >
                Yes, Delete Supplier
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
