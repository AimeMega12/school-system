import express from 'express';
import { getPolicy, updatePolicy } from '../controllers/policyController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = express.Router();

router.get('/', getPolicy); // Public or authenticated
router.put('/', authenticateToken, requireRole(['director']), updatePolicy);

export default router;
