/**
 * Notifications & Gateway Delivery Logs Controller
 */
import { sendSMS } from '../services/smsService.js';
import { sendEmail } from '../services/emailService.js';
import { sendWhatsApp } from '../services/whatsappService.js';

let deliveryLogs = [
  { id: 'deliv_01', channel: 'sms', recipient: '+250 788 456 789', subject: 'IBB Admission Approved', content: 'Dear Uwase Claudine, Congratulations! Your admission to IBB Rwanda for Software Development L3 has been APPROVED by the School Director.', status: 'delivered', providerResponse: 'DELIVERED_RWA_GATEWAY_OK', timestamp: '2026-10-27T16:05:00Z' },
  { id: 'deliv_02', channel: 'email', recipient: 'director@ibb.ac.rw', subject: 'Emergency Stock Alert: Irish Potatoes (Ibirayi)', content: 'Current stock of Irish Potatoes is 140 Kg, which is below the minimum threshold of 500 Kg.', status: 'delivered', providerResponse: 'SMTP_250_ACCEPTED', timestamp: '2026-10-31T06:00:00Z' },
  { id: 'deliv_03', channel: 'sms', recipient: '+250 788 661 229', subject: 'IBB Admission Policy Notice', content: 'IBB Rwanda: Dear Kagabo Thierry, your application could not be accepted as your score (42.0%) does not meet the minimum threshold of 50.0%.', status: 'delivered', providerResponse: 'SMS_GATEWAY_DELIVERED', timestamp: '2026-10-29T10:02:00Z' }
];

export const getDeliveryLogs = (req, res) => {
  const { channel } = req.query;
  let list = [...deliveryLogs];
  if (channel && channel !== 'all') {
    list = list.filter(l => l.channel === channel);
  }
  res.json({ success: true, count: list.length, logs: list });
};

export const sendTestDispatch = async (req, res) => {
  const { channel, recipient, message } = req.body;
  const testMsg = message || `[IBB Rwanda Gateway Test] Verification handshake ping at ${new Date().toLocaleTimeString()}.`;

  let result = null;
  if (channel === 'sms') {
    result = await sendSMS({ to: recipient, message: testMsg });
  } else if (channel === 'whatsapp') {
    result = await sendWhatsApp({ to: recipient, message: testMsg });
  } else {
    result = await sendEmail({ to: recipient, subject: 'IBB Gateway Test Ping', text: testMsg });
  }

  const logEntry = {
    id: `deliv_test_${Date.now()}`,
    channel,
    recipient,
    subject: 'IBB Gateway Test Ping',
    content: testMsg,
    status: 'delivered',
    providerResponse: 'GATEWAY_HANDSHAKE_200_OK',
    timestamp: new Date().toISOString()
  };

  deliveryLogs.unshift(logEntry);
  res.json({ success: true, log: logEntry });
};

export default { getDeliveryLogs, sendTestDispatch };
