/**
 * Approved Students Controller
 */

let approvedStudents = [
  {
    id: 'appr_01',
    applicationId: 'app_03',
    studentName: 'Uwase Claudine',
    applicationNumber: 'IBB-2026-01928',
    admissionLevel: 'L3',
    department: 'software_development',
    academicScore: 86.0,
    approvalDate: '2026-10-27T16:00:00Z',
    approvedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    boardingStatus: 'boarding_scholar',
    academicYear: '2026/2027',
    status: 'enrolled'
  },
  {
    id: 'appr_02',
    applicationId: 'app_04',
    studentName: 'Manzi Kevin',
    applicationNumber: 'IBB-2026-05612',
    admissionLevel: 'L5',
    department: 'automobile_technology',
    academicScore: 82.5,
    approvalDate: '2026-10-26T15:20:00Z',
    approvedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    boardingStatus: 'boarding_scholar',
    academicYear: '2026/2027',
    status: 'enrolled'
  }
];

export const getApprovedStudents = (req, res) => {
  const { level, department, boarding, search } = req.query;
  let list = [...approvedStudents];

  if (level && level !== 'all') {
    list = list.filter(s => s.admissionLevel === level);
  }
  if (department && department !== 'all') {
    list = list.filter(s => s.department === department);
  }
  if (boarding && boarding !== 'all') {
    list = list.filter(s => s.boardingStatus === boarding);
  }
  if (search) {
    const s = search.toLowerCase();
    list = list.filter(item =>
      item.studentName.toLowerCase().includes(s) ||
      item.applicationNumber.toLowerCase().includes(s)
    );
  }

  res.json({ success: true, count: list.length, students: list });
};

export const exportApprovedStudents = (req, res) => {
  const headers = ['ID,Student Name,Tracking Number,Level,Department,Academic Score (%),Boarding Status,Approval Date,Approved By'];
  const rows = approvedStudents.map(s =>
    `${s.id},"${s.studentName}",${s.applicationNumber},${s.admissionLevel},${s.department},${s.academicScore},${s.boardingStatus},${s.approvalDate},"${s.approvedBy}"`
  );

  const csv = [headers, ...rows].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="IBB_Approved_Students_Register.csv"');
  res.send(csv);
};

export default { getApprovedStudents, exportApprovedStudents };
