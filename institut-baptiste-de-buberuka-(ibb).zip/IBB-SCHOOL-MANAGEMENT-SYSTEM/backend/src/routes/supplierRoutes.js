import express from 'express';
import {
  getSuppliers,
  createSupplier,
  updateSupplier,
  deleteSupplier
} from '../controllers/supplierController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requirePermission } from '../middleware/rbac.js';

const router = express.Router();

router.get('/', authenticateToken, requirePermission('suppliers'), getSuppliers);
router.post('/', authenticateToken, requirePermission('suppliers'), createSupplier);
router.put('/:id', authenticateToken, requirePermission('suppliers'), updateSupplier);
router.delete('/:id', authenticateToken, requirePermission('suppliers'), deleteSupplier);

export default router;
