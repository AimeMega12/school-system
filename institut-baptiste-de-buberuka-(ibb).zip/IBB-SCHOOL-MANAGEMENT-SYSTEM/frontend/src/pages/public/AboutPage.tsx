/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { Link } from 'react-router-dom';
import { CheckCircle2, Award, HeartHandshake, Compass, BookOpen } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="py-12 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-12">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            {language === 'rw' ? 'Ibyerekeye Ikigo' : 'Institutional Profile'}
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-2 mb-4 text-slate-900 dark:text-white">
            Institut Baptiste de Buberuka (IBB)
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
            {language === 'rw'
              ? 'Ishuri ryisumbuye ry’ubumenyingiro n’ikoranabuhanga riri mu misozi y’Amajyaruguru mu Karere ka Burera, ryashinzwe ku bufatanye bw’Itorero ry’Ababatisita mu Rwanda (UEBR) na Leta y’u Rwanda.'
              : 'An accredited technical and vocational secondary institution nestled in the scenic northern hills of Burera District, established through the partnership of the Union of Baptist Churches in Rwanda (UEBR) and the Government of Rwanda.'}
          </p>
        </div>

        {/* Campus Hero Image */}
        <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200 dark:border-slate-800 mb-16">
          <img
            src="/src/assets/images/ibb_campus_hero_1793449104422.jpg"
            alt="IBB Campus overview"
            referrerPolicy="no-referrer"
            className="w-full h-80 sm:h-96 object-cover"
          />
        </div>

        {/* Mission, Vision & Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Icyerekezo Cyacu' : 'Our Vision'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {language === 'rw'
                ? 'Kuba ikigo cy’indashyikirwa mu karere k’ibiyaga bigari gihugura abanyeshuri bafite ubuhanga buhanitse mu ikoranabuhanga n’ubumenyi ngiro bufitiye igihugu umumaro.'
                : 'To be a center of excellence in the Great Lakes region producing morally grounded, technically competent technicians driving Rwanda’s socio-economic transformation.'}
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-4">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Intego Yacu' : 'Our Mission'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {language === 'rw'
                ? 'Gutanga ubumenyi n’imyitozo ngiro yujuje ubuziranenge mu gukora porogaramu n’ubukanishi bw’ibinyabiziga, turera urubyiruko rufite ikinyabupfura n’umutimanama wa Gikristo.'
                : 'To deliver quality competency-based training in Software Development and Automobile Technology, nurturing Christian ethics, discipline, and practical innovation.'}
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Indangagaciro' : 'Core Values'}
            </h3>
            <ul className="space-y-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>{language === 'rw' ? 'Ubunyangamugayo (Integrity)' : 'Christian Integrity'}</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>{language === 'rw' ? 'Ireme ry’Umwuga (Excellence)' : 'Technical Mastery'}</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>{language === 'rw' ? 'Ikinyabupfura (Discipline)' : 'Strict Discipline'}</span>
              </li>
              <li className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                <span>{language === 'rw' ? 'Guhanga Udushya (Innovation)' : 'Applied Innovation'}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Message from School Leadership */}
        <div className="p-8 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 text-white border border-slate-800 mb-16">
          <div className="flex flex-col sm:flex-row gap-6 items-start">
            <div className="w-16 h-16 rounded-2xl bg-emerald-600 flex items-center justify-center text-white text-2xl font-black shrink-0">
              DIR
            </div>
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                {language === 'rw' ? 'Ubutumwa bw’Umuyobozi Mukuru' : 'Message from the School Director'}
              </span>
              <h3 className="text-xl font-bold mt-1 mb-3 text-white">
                Rev. Dr. Emmanuel Nshimyumuremyi
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed italic mb-4">
                &ldquo;At Institut Baptiste de Buberuka, we believe technical training without character creates capability without direction. Here in Burera, we are equipping young men and women with real coding algorithms and precision automotive diagnostics while shaping them into servants of integrity for the Republic of Rwanda.&rdquo;
              </p>
              <div className="text-xs text-slate-400">
                School Director & Legal Representative · Institut Baptiste de Buberuka
              </div>
            </div>
          </div>
        </div>

        {/* Apply Callout */}
        <div className="text-center pt-6">
          <Link
            to="/apply"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all"
          >
            <span>{t('heroCtaApply')}</span>
          </Link>
        </div>

      </div>
    </div>
  );
};
