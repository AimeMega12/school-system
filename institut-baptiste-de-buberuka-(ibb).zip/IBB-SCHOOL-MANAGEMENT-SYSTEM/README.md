# INSTITUT BAPTISTE DE BUBERUKA (IBB) — RWANDA
## Complete Integrated Full-Stack Bilingual School Management System

**Institut Baptiste de Buberuka (IBB)** is a Ministry of Education (MINEDUC) and Rwanda TVET Board (RTB) accredited technical secondary institution in Buberuka, Burera District, Northern Province, Rwanda.

This archive contains the **COMPLETE FULL-STACK PRODUCTION CODEBASE** including:
1. **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide React, Recharts analytics, Motion.
2. **Backend**: Node.js, Express.js REST API, Socket.IO real-time notification engine, JWT auth, bcrypt, Multer, Nodemailer.
3. **Database**: Complete MySQL 8.0+ relational schema (`database/schema.sql`) and comprehensive seed dataset (`database/seed.sql`).
4. **All Functional Modules**:
   - Bilingual public school portal (English & Kinyarwanda) and Light/Dark themes.
   - Student Admissions from **Level 3 (L3) to Level 5 (L5)** in Software Development & Automobile Technology.
   - Director-configurable RTB Academic Grading & Admission policies with automated rejection under threshold.
   - Approved Students Registry with CSV/Excel export.
   - Granular Staff Access Control (Director sovereign control over Accountant & Animator module permissions).
   - Configurable Two-Factor Authentication (OTP via Email Only, SMS Only, or Dual Email + SMS).
   - Intelligent Food Inventory Management with automated meal distribution schedule (06:00-08:00 & 17:00-19:00 Africa/Kigali) and Director emergency overrides.
   - Multi-channel delivery logs (SMS +250, WhatsApp Cloud API, Email SMTP).

---

## 🚀 Quick Start (Automated)

### Option A: Standard Node.js Setup
```bash
# 1. Run automated setup to install all dependencies
chmod +x scripts/setup.sh scripts/start.sh
./scripts/setup.sh

# 2. Launch both backend and frontend servers
./scripts/start.sh
```

- **Frontend Application**: `http://localhost:3000`
- **Backend REST API**: `http://localhost:5000`
- **API Health Check**: `http://localhost:5000/api/health`

---

### Option B: Docker Compose (Single Command)
```bash
docker-compose up --build
```
This automatically boots:
- MySQL Database with `schema.sql` and `seed.sql` on port `3306`.
- Express REST API on port `5000`.

---

## 🔑 Authorized Staff Accounts (Demo Mode)

| Role | Username | Password | Full Name | Primary Jurisdiction |
|---|---|---|---|---|
| **Director** (Super Admin) | `director` | `Password123!` | Rev. Dr. Emmanuel Nshimyumuremyi | Full authority, admissions, grading policies, permissions, OTP config |
| **Accountant** | `accountant` | `Password123!` | Clarisse Mukakarisa, CPA | Food stock in, supplier oversight, financial valuation, temporary delegation |
| **Animator** | `animator` | `Password123!` | Jean-Claude Habimana | Daily meal distribution (06:00-08:00 & 17:00-19:00), food balances |

*Note: Demo OTP auto-fill buttons are provided on the login screen for instant verification testing.*

---

## 📁 Project Directory Structure

```
IBB-SCHOOL-MANAGEMENT-SYSTEM/
├── backend/
│   ├── src/
│   │   ├── config/database.js          # MySQL connection pool with fallback
│   │   ├── controllers/                # Business logic for all modules
│   │   │   ├── authController.js       # JWT & 2FA OTP verification
│   │   │   ├── applicationController.js# L3-L5 admissions & decision engine
│   │   │   ├── policyController.js     # RTB academic grading policies
│   │   │   ├── studentController.js    # Approved students register
│   │   │   ├── stockController.js      # Food inventory & schedule
│   │   │   ├── supplierController.js   # Vendor directory
│   │   │   ├── notificationController.js# Multi-channel delivery logs
│   │   │   └── reportController.js     # Financial valuation & audits
│   │   ├── middleware/
│   │   │   ├── auth.js                 # JWT bearer token verification
│   │   │   ├── rbac.js                 # Role & granular permissions check
│   │   │   ├── workingHours.js         # 06:00-08:00 & 17:00-19:00 Rwanda hours
│   │   │   └── upload.js               # Multer document attachment upload
│   │   ├── routes/                     # REST API routing endpoints
│   │   ├── services/                   # SMS, Email, WhatsApp & Audit services
│   │   └── server.js                   # Main Express & Socket.IO server
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/                            # Complete React 19 application
│   │   ├── components/                 # Navigation, footer, modals, dropdowns
│   │   ├── context/                    # Auth, Theme, Language, Notifications
│   │   ├── pages/
│   │   │   ├── public/                 # Home, About, Programs, Admissions, ApplyNow, Track
│   │   │   └── dashboard/              # Director, Accountant, Animator, Policy, Stock, etc.
│   │   ├── services/storage.ts         # Persistent data layer with initial seeds
│   │   ├── translations/index.ts       # Full English & Kinyarwanda translations
│   │   └── types/index.ts              # TypeScript domain types
│   ├── package.json
│   ├── vite.config.ts
│   └── tsconfig.json
├── database/
│   ├── schema.sql                      # Complete MySQL 8.0 relational DDL
│   └── seed.sql                        # Comprehensive seed data script
├── scripts/
│   ├── setup.sh                        # Automated dependency installation
│   └── start.sh                        # Dual concurrent server launcher
├── docker-compose.yml
└── package.json                        # Root project orchestrator
```

---

## 📡 REST API Reference

| Method | Endpoint | Access Level | Description |
|---|---|---|---|
| `POST` | `/api/auth/login-step1` | Public | Verify credentials and initiate configured OTP |
| `POST` | `/api/auth/verify-otp` | Public | Validate OTP and issue JWT session token |
| `POST` | `/api/applications/apply` | Public | Submit new student application (L3, L4, L5) |
| `GET` | `/api/applications/track/:tracking` | Public | Query evaluation status by tracking number |
| `GET` | `/api/policies` | Public | Retrieve active academic grading policy |
| `PUT` | `/api/policies` | Director Only | Update admission & pass cut-offs and grade scales |
| `PUT` | `/api/applications/:id/approve`| Director Only | Approve admission and enroll student |
| `PUT` | `/api/applications/:id/waiver` | Director Only | Issue exceptional waiver for auto-rejected applicant |
| `GET` | `/api/students` | Director/Accountant | Query approved students register |
| `GET` | `/api/students/export/csv` | Director/Accountant | Download register in CSV format |
| `GET` | `/api/stock/products` | Authorized Staff | Query current inventory balances and thresholds |
| `POST` | `/api/stock/in` | Stock In Perm | Record incoming commodity shipment |
| `POST` | `/api/stock/out` | Stock Out Perm | Record meal distribution (within working hours) |
| `POST` | `/api/stock/override` | Director Only | Enable/disable emergency distribution override |
| `GET` | `/api/reports/stats` | Staff | Executive inventory and admission KPIs |
| `GET` | `/api/reports/audit-logs` | Director Only | Immutable security and activity audit trail |

---

## ⚖️ License
Licensed under the Apache License, Version 2.0.
Produced for **INSTITUT BAPTISTE DE BUBERUKA (IBB), RWANDA**.
