/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { AcademicGradingPolicy } from '../../types/index.ts';
import {
  Award,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Save,
  Clock,
  Layers,
  GraduationCap,
  History,
  Info
} from 'lucide-react';

export const AcademicPolicyManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  const [policy, setPolicy] = useState<AcademicGradingPolicy>(() =>
    StorageService.getAcademicPolicy()
  );
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Field handlers
  const handleSavePolicy = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedPolicy: AcademicGradingPolicy = {
      ...policy,
      effectiveDate: new Date().toISOString().split('T')[0]
    };

    StorageService.saveAcademicPolicy(updatedPolicy);
    setPolicy(updatedPolicy);

    // Audit log
    StorageService.addAuditLog({
      action: 'ACADEMIC_POLICY_UPDATED',
      category: 'system',
      userId: user?.id || 'dir_01',
      userName: user?.fullName || 'School Director',
      userRole: 'director',
      details: `Academic grading & admission policy updated for ${updatedPolicy.academicYear}: Min Admission=${updatedPolicy.minimumAdmissionPercentage}%, Boarding=${updatedPolicy.boardingEligibilityPercentage}%`,
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: 'Academic Policy Updated',
      titleRw: 'Amategeko y’Amanota Yavuguruwe',
      message: `Director updated admission minimum threshold to ${updatedPolicy.minimumAdmissionPercentage}% and boarding threshold to ${updatedPolicy.boardingEligibilityPercentage}%.`,
      messageRw: `Umuyobozi yavuguruye amanota fatizo yo kwinjira (${updatedPolicy.minimumAdmissionPercentage}%) n'ayicumbi (${updatedPolicy.boardingEligibilityPercentage}%).`,
      type: 'success',
      category: 'admission',
      targetRoles: ['director', 'accountant', 'animator']
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  if (user?.role !== 'director') {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Access Restricted</h3>
        <p className="text-xs text-slate-500">Only the School Director can configure academic grading and admission eligibility policies.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <DashboardPageHeader
        title={t('academicPolicyTitle')}
        subtitle={t('academicPolicySub')}
        badge={
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-400/20">
            Rwanda TVET Board (RTB) Accredited Standards
          </span>
        }
        variant="purple"
      >
        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-white/90 dark:bg-slate-900/90 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-mono font-bold">
            Year: {policy.academicYear}
          </span>
        </div>
      </DashboardPageHeader>

      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-semibold">
            Academic Grading & Admission eligibility policy saved and enforced across all online admissions.
          </span>
        </div>
      )}

      {/* Main Configuration Form */}
      <form onSubmit={handleSavePolicy} className="space-y-8">
        
        {/* Core Percentage Thresholds */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
            <Award className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Core Admission & Academic Cut-Off Thresholds
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('minAdmissionScoreLabel')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.5"
                  min="30"
                  max="100"
                  required
                  value={policy.minimumAdmissionPercentage}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      minimumAdmissionPercentage: Number(e.target.value)
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">%</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">
                Applicants scoring below this percentage are automatically flagged as rejected.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('minPassScoreLabel')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.5"
                  min="30"
                  max="100"
                  required
                  value={policy.minimumPassingPercentage}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      minimumPassingPercentage: Number(e.target.value)
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">%</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">
                Minimum overall term pass grade required to avoid retake module examination.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('boardingMinScoreLabel')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.5"
                  min="50"
                  max="100"
                  required
                  value={policy.boardingEligibilityPercentage}
                  onChange={(e) =>
                    setPolicy({
                      ...policy,
                      boardingEligibilityPercentage: Number(e.target.value)
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">%</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1.5">
                Students reaching this threshold qualify for priority campus dormitory residency.
              </p>
            </div>
          </div>
        </div>

        {/* Level Specific Criteria (L3, L4, L5) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
            <Layers className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Entry Level Special Requirements (L3, L4, L5)
            </h3>
          </div>

          <div className="space-y-4">
            {policy.rulesPerLevel.map((lvlRule, idx) => (
              <div
                key={lvlRule.level}
                className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-mono font-black text-sm">
                    {lvlRule.level}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {lvlRule.level === 'L3' && 'Level 3 · Foundation TVET'}
                      {lvlRule.level === 'L4' && 'Level 4 · Intermediate TVET'}
                      {lvlRule.level === 'L5' && 'Level 5 · Advanced Technician Diploma'}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {lvlRule.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <label className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                    Level Cut-off:
                  </label>
                  <div className="relative w-28">
                    <input
                      type="number"
                      step="0.5"
                      min="30"
                      max="100"
                      value={lvlRule.minScore}
                      onChange={(e) => {
                        const updatedRules = [...policy.rulesPerLevel];
                        updatedRules[idx].minScore = Number(e.target.value);
                        setPolicy({ ...policy, rulesPerLevel: updatedRules });
                      }}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                    />
                    <span className="absolute right-2.5 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Grade Scales */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t('gradeRangesTitle')}
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {policy.gradeRanges.map((g) => (
              <div
                key={g.grade}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                    {g.grade}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    g.standing === 'distinction'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                      : g.standing === 'credit'
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                      : g.standing === 'pass'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                      : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                  }`}>
                    {g.standing}
                  </span>
                </div>
                <div className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 mb-1">
                  {g.minPercentage}% – {g.maxPercentage}%
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-400">
                  {language === 'rw' ? g.labelRw : g.labelEn}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Promotion and Repeating Rules */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800">
            <Info className="w-5 h-5 text-slate-500" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Institutional Progression & Repeating Rules
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-2">
                {t('promotionRulesLabel')}
              </span>
              <ul className="space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
                <li>Attainment of at least {policy.minimumPassingPercentage}% cumulative annual technical score.</li>
                <li>Pass mark in both core workshop practicals and software coding projects.</li>
                <li>Clean disciplinary record attested by the School Animator.</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
              <span className="font-bold text-slate-900 dark:text-white block mb-2">
                {t('repeatingRulesLabel')}
              </span>
              <ul className="space-y-1.5 text-slate-600 dark:text-slate-400 list-disc list-inside">
                <li>Students scoring between 40.0% and 49.9% are permitted to repeat the academic level once.</li>
                <li>Scores below 40.0% in technical modules require academic board dismissal or re-orientation.</li>
                <li>Maximum of one repeating academic year allowed per TVET cycle (L3 to L5).</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-4">
          <span className="text-xs text-slate-500 italic">
            {t('policyHistoricalNotice')}
          </span>

          <button
            type="submit"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{t('savePolicyBtn')}</span>
          </button>
        </div>

      </form>
    </div>
  );
};
