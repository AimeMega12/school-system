/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  Sun,
  Moon,
  Globe,
  Lock,
  LayoutDashboard,
  Menu,
  X,
  GraduationCap,
  Home,
  Info,
  BookOpen,
  FileCheck,
  Search,
  Mail,
  Sparkles,
  ChevronRight,
  Shield
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { t, language, toggleLanguage, setLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  // Handle ESC key to close mobile menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [mobileMenuOpen]);

  // Lock body scrolling when mobile menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  // Auto-close menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const getDashboardRoute = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'director':
        return '/dashboard/director';
      case 'accountant':
        return '/dashboard/accountant';
      case 'animator':
        return '/dashboard/animator';
      default:
        return '/dashboard';
    }
  };

  // Nav link definitions
  const mainNavItems = [
    { name: t('navHome'), path: '/', icon: Home },
    { name: t('navAbout'), path: '/about', icon: Info },
    { name: t('navPrograms'), path: '/programs', icon: BookOpen },
    { name: t('navAdmissions'), path: '/admissions', icon: FileCheck },
    { name: t('navTrackApp'), path: '/track', icon: Search },
    { name: t('navContact'), path: '/contact', icon: Mail },
  ];

  return (
    <>
      {/* MAIN TOP HEADER BAR (Z-index 40 on desktop, keeps clean stacking context) */}
      <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#071A33]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-18 sm:h-20 gap-3 sm:gap-6">
            
            {/* BRAND WORDMARK (Visible on all screen sizes) */}
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2.5 sm:gap-3 shrink-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg p-1"
              aria-label="Karenge Adventist Secondary School Home"
            >
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] flex items-center justify-center text-white shadow-md shadow-blue-700/20 group-hover:scale-105 transition-transform shrink-0">
                <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <div className="flex flex-col">
                <span className="font-extrabold text-base sm:text-lg lg:text-xl tracking-tight text-slate-900 dark:text-white leading-none flex items-center gap-1.5">
                  KARENGE <span className="text-emerald-600 dark:text-emerald-400">ADVENTIST</span>
                </span>
                <span className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium tracking-normal mt-0.5 truncate max-w-[170px] sm:max-w-none">
                  Secondary School
                </span>
              </div>
            </Link>

            {/* DESKTOP NAVIGATION LINKS (Visible on lg screens >= 1024px) */}
            <nav className="hidden lg:flex items-center gap-5 xl:gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
              {mainNavItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`whitespace-nowrap transition-colors hover:text-emerald-600 dark:hover:text-emerald-400 py-1.5 relative ${
                    isActive(item.path)
                      ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                      : ''
                  }`}
                >
                  {item.name}
                  {isActive(item.path) && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600 dark:bg-emerald-400 rounded-full" />
                  )}
                </Link>
              ))}
            </nav>

            {/* DESKTOP CONTROLS & ACTIONS (Visible on lg screens >= 1024px) */}
            {/* DESKTOP CONTROLS & ACTIONS (Visible on lg screens >= 1024px) */}
            <div className="hidden lg:flex items-center gap-2.5 xl:gap-3 shrink-0">
              {/* Language Switcher (Clear Segmented EN | RW) */}
              <div
                role="group"
                aria-label="Language selection"
                className="flex items-center p-0.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold"
              >
                <button
                  type="button"
                  onClick={() => setLanguage('en')}
                  className={`px-2.5 py-1.5 rounded-lg transition-all min-h-[34px] cursor-pointer flex items-center justify-center font-bold ${
                    language === 'en'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  aria-label="Set language to English"
                  aria-pressed={language === 'en'}
                >
                  EN
                </button>
                <button
                  type="button"
                  onClick={() => setLanguage('rw')}
                  className={`px-2.5 py-1.5 rounded-lg transition-all min-h-[34px] cursor-pointer flex items-center justify-center font-bold ${
                    language === 'rw'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                  aria-label="Set language to Kinyarwanda"
                  aria-pressed={language === 'rw'}
                >
                  RW
                </button>
              </div>

              {/* Theme Toggle */}
              <button
                type="button"
                onClick={toggleTheme}
                title={theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
                aria-label="Toggle theme"
                className="p-2 rounded-xl text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 cursor-pointer min-h-[38px] min-w-[38px] flex items-center justify-center active:scale-95"
              >
                {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
              </button>

              {/* Authenticated Dashboard Link OR Staff Login */}
              {user ? (
                <Link
                  to={getDashboardRoute()}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/60 active:scale-[0.98] transition-all whitespace-nowrap min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                >
                  <LayoutDashboard className="w-3.5 h-3.5" />
                  <span>{t('navDashboard')}</span>
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 active:scale-[0.98] rounded-xl transition-all whitespace-nowrap border border-slate-200 dark:border-slate-700 min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                >
                  <Lock className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>{t('navStaffLogin')}</span>
                </Link>
              )}

              {/* Primary Action Button: Apply Now */}
              <Link
                to="/apply"
                className="inline-flex items-center justify-center gap-1.5 px-4.5 py-2 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-[0.98] rounded-xl shadow-sm shadow-emerald-600/30 transition-all whitespace-nowrap min-h-[38px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('navApplyNow')}</span>
              </Link>
            </div>

            {/* MOBILE HEADER (CLOSED): DISPLAYS ONLY THE HAMBURGER ICON ON THE RIGHT (< 1024px) */}
            <div className="flex lg:hidden items-center shrink-0">
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="p-2.5 rounded-xl text-slate-800 dark:text-slate-100 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer flex items-center justify-center min-w-[44px] min-h-[44px]"
                aria-label="Open mobile navigation menu"
                aria-expanded={mobileMenuOpen}
              >
                <Menu className="w-6 h-6 text-slate-800 dark:text-white" />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* MOBILE NAVIGATION MODAL / DRAWER (Z-INDEX 100+: ALWAYS ABOVE HERO SECTION & ALL CONTENT) */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-[100] flex justify-end">
          {/* Backdrop with click-to-close */}
          <div
            onClick={() => setMobileMenuOpen(false)}
            className="fixed inset-0 bg-slate-950/75 backdrop-blur-sm transition-opacity"
            aria-hidden="true"
          />

          {/* Menu Drawer Container - Full Height, Vertically Scrollable, Strict Z-Index */}
          <div className="relative z-10 w-full sm:max-w-sm h-full bg-white dark:bg-[#071A33] border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col min-h-0 overflow-hidden">
            
            {/* 1. MENU HEADER (Logo + School Name + Close Button) */}
            <div className="px-4 sm:px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B1930] flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] flex items-center justify-center text-white shadow-sm shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-extrabold text-sm text-slate-900 dark:text-white leading-tight">
                    KARENGE <span className="text-emerald-600 dark:text-emerald-400">ADVENTIST</span>
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium truncate max-w-[190px]">
                    Secondary School
                  </div>
                </div>
              </div>

              {/* Close Button (X) */}
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                aria-label="Close navigation menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* 2. ALL 8 NAVIGATION LINKS (PLACED CLEARLY & VERTICALLY BETWEEN HEADER AND CONTROLS) */}
            <div className="flex-1 min-h-0 overflow-y-auto px-4 py-3 space-y-1.5">
              <div className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase px-2 py-0.5">
                School Navigation
              </div>

              {/* 1. Home */}
              <Link
                to="/"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <Home className="w-4 h-4" />
                  </div>
                  <span>{t('navHome')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              {/* 2. About KASS */}
              <Link
                to="/about"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/about')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/about') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <Info className="w-4 h-4" />
                  </div>
                  <span>{t('navAbout')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/about') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              {/* 3. Our Programs */}
              <Link
                to="/programs"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/programs')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/programs') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <span>{t('navPrograms')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/programs') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              {/* 4. Admissions */}
              <Link
                to="/admissions"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/admissions')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/admissions') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <span>{t('navAdmissions')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/admissions') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              {/* 5. Track Status */}
              <Link
                to="/track"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/track')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/track') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <Search className="w-4 h-4" />
                  </div>
                  <span>{t('navTrackApp')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/track') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              {/* 6. Contact Us */}
              <Link
                to="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                  isActive('/contact')
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${isActive('/contact') ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                    <Mail className="w-4 h-4" />
                  </div>
                  <span>{t('navContact')}</span>
                </div>
                <ChevronRight className={`w-4 h-4 ${isActive('/contact') ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              </Link>

              <div className="pt-2 pb-1">
                <div className="h-px bg-slate-200 dark:bg-slate-800" />
              </div>

              {/* 7. Staff Login OR Dashboard */}
              {user ? (
                <Link
                  to={getDashboardRoute()}
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 min-h-[48px] transition-all hover:bg-emerald-100 dark:hover:bg-emerald-900/50"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-emerald-600 text-white">
                      <LayoutDashboard className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col text-left">
                      <span>{t('navDashboard')}</span>
                      <span className="text-[11px] font-normal text-emerald-600 dark:text-emerald-400">
                        {user.fullName} ({user.role})
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                </Link>
              ) : (
                <Link
                  to="/login"
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all min-h-[48px] ${
                    isActive('/login')
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/70 border border-slate-200/80 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <span>{t('navStaffLogin')}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </Link>
              )}

              {/* 8. Apply Now (Primary Action Button) */}
              <div className="pt-1.5 pb-1">
                <Link
                  to="/apply"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2.5 w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-[0.99] shadow-md shadow-emerald-600/30 transition-all min-h-[48px]"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{t('navApplyNow')}</span>
                </Link>
              </div>

            </div>

            {/* 3. LANGUAGE SELECTOR & THEME CONTROLS (PLACED BELOW THE NAVIGATION LINKS) */}
            <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B1930] flex items-center justify-between gap-2.5 shrink-0">
              {/* Language Selector Buttons */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0">
                <button
                  onClick={() => setLanguage('en')}
                  className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    language === 'en'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => setLanguage('rw')}
                  className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    language === 'rw'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  Kinyarwanda
                </button>
              </div>

              {/* Theme Toggle Button */}
              <button
                onClick={toggleTheme}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-sm cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors shrink-0"
                aria-label="Toggle dark/light theme"
              >
                {theme === 'light' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-slate-600" />
                    <span>Dark</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span>Light</span>
                  </>
                )}
              </button>
            </div>

            {/* 4. DRAWER FOOTER (Accreditation & Location) */}
            <div className="px-4 py-2.5 border-t border-slate-200 dark:border-slate-800/80 bg-slate-100/60 dark:bg-[#071A33] text-center shrink-0">
              <div className="flex items-center justify-center gap-1.5 text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                <Shield className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>KARENGE ADVENTIST SECONDARY SCHOOL</span>
              </div>
              <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                Karenge, Rwanda · TVET / MINEDUC Accredited
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
