/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { OTPSettings, NotificationDeliveryLog, OTPVerificationMode } from '../../types/index.ts';
import {
  Bell,
  ShieldCheck,
  Mail,
  Smartphone,
  MessageSquare,
  CheckCircle2,
  AlertCircle,
  Save,
  Send,
  Radio,
  Clock,
  Filter,
  RefreshCw,
  Search
} from 'lucide-react';

export const NotificationSettingsManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  const [otpSettings, setOtpSettings] = useState<OTPSettings>(() =>
    StorageService.getOTPSettings()
  );
  const [deliveryLogs, setDeliveryLogs] = useState<NotificationDeliveryLog[]>(() =>
    StorageService.getDeliveryLogs()
  );

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [logFilterChannel, setLogFilterChannel] = useState<'all' | 'email' | 'sms' | 'whatsapp'>('all');
  const [testRecipient, setTestRecipient] = useState('+250 788 123 456');
  const [testChannel, setTestChannel] = useState<'sms' | 'email' | 'whatsapp'>('sms');
  const [testSentSuccess, setTestSentSuccess] = useState(false);

  const handleSaveOTPSettings = (e: React.FormEvent) => {
    e.preventDefault();

    StorageService.saveOTPSettings(otpSettings);

    StorageService.addAuditLog({
      action: 'OTP_SETTINGS_UPDATED',
      category: 'system',
      userId: user?.id || 'dir_01',
      userName: user?.fullName || 'School Director',
      userRole: 'director',
      details: `Director updated OTP mandatory mode to ${otpSettings.mode.toUpperCase()} (Validity: ${otpSettings.codeExpiryMinutes} mins)`,
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: 'Authentication Security Updated',
      titleRw: 'Umutekano wo Kwinjira Wavuguruwe',
      message: `Staff login 2FA verification mode changed to ${otpSettings.mode.toUpperCase()}.`,
      messageRw: `Uburyo bwa 2FA bwahinduwe kuri ${otpSettings.mode.toUpperCase()}.`,
      type: 'info',
      category: 'auth',
      targetRoles: ['director', 'accountant', 'animator']
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleSendTestDispatch = (e: React.FormEvent) => {
    e.preventDefault();

    const sampleContent = `[KASS Rwanda Gateway Test] Verification handshake successful via ${testChannel.toUpperCase()} dispatcher at ${new Date().toLocaleTimeString()}.`;

    StorageService.addDeliveryLog({
      channel: testChannel,
      recipient: testRecipient,
      subject: 'KASS Multi-Channel Gateway Handshake Test',
      content: sampleContent,
      status: 'delivered',
      providerResponse: testChannel === 'sms' ? 'SMS_GATEWAY_DELIVERED_RWA' : testChannel === 'whatsapp' ? 'WA_CLOUD_API_200_OK' : 'SMTP_250_ACCEPTED'
    });

    setDeliveryLogs(StorageService.getDeliveryLogs());
    setTestSentSuccess(true);
    setTimeout(() => setTestSentSuccess(false), 3000);
  };

  const filteredLogs = deliveryLogs.filter(
    (log) => logFilterChannel === 'all' || log.channel === logFilterChannel
  );

  if (user?.role !== 'director') {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Director Authorization Required</h3>
        <p className="text-xs text-slate-500">Only the School Director can configure multi-channel gateways and OTP security protocols.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <DashboardPageHeader
        title={t('otpSettingsTitle')}
        subtitle={t('otpSettingsSub')}
        badge={
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-400/20">
            Multi-Channel Communications &amp; Security
          </span>
        }
        variant="indigo"
      >
        <div className="flex items-center gap-2">
          <span className="px-3.5 py-1.5 rounded-xl bg-white/90 dark:bg-slate-900/90 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-600" />
            <span>Gateways: Operational</span>
          </span>
        </div>
      </DashboardPageHeader>

      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-semibold">
            Authentication security mode updated. All upcoming staff logins will enforce the new verification channel.
          </span>
        </div>
      )}

      {/* OTP Configuration Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">
            {t('otpModeLabel')}
          </h3>
        </div>

        <form onSubmit={handleSaveOTPSettings} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                mode: 'email_only' as OTPVerificationMode,
                title: 'OPTION 1: Email Only',
                desc: 'Delivers 6-digit OTP code to verified institutional email address.',
                icon: Mail,
                color: 'text-blue-500'
              },
              {
                mode: 'sms_only' as OTPVerificationMode,
                title: 'OPTION 2: SMS Only (+250)',
                desc: 'Delivers OTP code directly via Rwanda MTN/Airtel SMS cellular gateway.',
                icon: Smartphone,
                color: 'text-emerald-500'
              },
              {
                mode: 'email_and_sms' as OTPVerificationMode,
                title: 'OPTION 3: Dual Email + SMS',
                desc: 'Requires simultaneous verification of both Email and Phone SMS codes.',
                icon: ShieldCheck,
                color: 'text-indigo-500'
              }
            ].map((option) => (
              <div
                key={option.mode}
                onClick={() => setOtpSettings({ ...otpSettings, mode: option.mode })}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                  otpSettings.mode === option.mode
                    ? 'border-emerald-600 bg-emerald-50/40 dark:bg-emerald-950/20'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <option.icon className={`w-5 h-5 ${option.color}`} />
                    <input
                      type="radio"
                      name="otpMode"
                      checked={otpSettings.mode === option.mode}
                      onChange={() => {}}
                      className="text-emerald-600"
                    />
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white mb-1">
                    {option.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                    {option.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('otpExpiryLabel')} *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="2"
                  max="60"
                  required
                  value={otpSettings.codeExpiryMinutes}
                  onChange={(e) =>
                    setOtpSettings({
                      ...otpSettings,
                      codeExpiryMinutes: Number(e.target.value)
                    })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400">mins</span>
              </div>
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-sm transition-all"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{t('saveOtpSettingsBtn')}</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Gateway Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Rwanda SMS (+250)</h4>
              <p className="text-[11px] text-slate-500">MTN & Airtel Gateway</p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded">
            Connected
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-green-50 dark:bg-green-950/60 text-green-600 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">WhatsApp Cloud API</h4>
              <p className="text-[11px] text-slate-500">Meta Business Verified</p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded">
            Active
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">SMTP Email Relay</h4>
              <p className="text-[11px] text-slate-500">TLS Port 587 Secured</p>
            </div>
          </div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded">
            Online
          </span>
        </div>
      </div>

      {/* Gateway Handshake Testing Tool */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <Send className="w-4 h-4 text-emerald-600" />
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">
            Live Gateway Dispatch Tester
          </h3>
        </div>

        {testSentSuccess && (
          <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Handshake message dispatched successfully. Check delivery logs below.</span>
          </div>
        )}

        <form onSubmit={handleSendTestDispatch} className="flex flex-col sm:flex-row gap-3">
          <select
            value={testChannel}
            onChange={(e) => setTestChannel(e.target.value as any)}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white"
          >
            <option value="sms">Rwanda SMS (+250)</option>
            <option value="email">Email SMTP</option>
            <option value="whatsapp">WhatsApp Business API</option>
          </select>

          <input
            type="text"
            required
            value={testRecipient}
            onChange={(e) => setTestRecipient(e.target.value)}
            placeholder="Recipient phone or email..."
            className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono"
          />

          <button
            type="submit"
            className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send Test Ping</span>
          </button>
        </form>
      </div>

      {/* Real-time Delivery Logs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              {t('deliveryLogsTitle')}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={logFilterChannel}
              onChange={(e) => setLogFilterChannel(e.target.value as any)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white"
            >
              <option value="all">All Channels</option>
              <option value="sms">SMS Gateway</option>
              <option value="email">Email</option>
              <option value="whatsapp">WhatsApp</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
              <tr>
                <th className="py-3 px-4">Channel</th>
                <th className="py-3 px-4">Recipient</th>
                <th className="py-3 px-4">Subject & Message Summary</th>
                <th className="py-3 px-4">Delivery Status</th>
                <th className="py-3 px-4 text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 font-mono font-bold uppercase text-[11px] px-2 py-0.5 rounded ${
                      log.channel === 'sms'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : log.channel === 'whatsapp'
                        ? 'bg-green-100 text-green-800 dark:bg-green-950/60 dark:text-green-300'
                        : 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                    }`}>
                      {log.channel}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-mono text-[11px] text-slate-900 dark:text-white">
                    {log.recipient}
                  </td>

                  <td className="py-3 px-4">
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {log.subject}
                    </span>
                    <p className="text-[11px] text-slate-500 truncate max-w-md">
                      {log.content}
                    </p>
                  </td>

                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      log.status === 'delivered'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : log.status === 'failed'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                    }`}>
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{log.status}</span>
                    </span>
                  </td>

                  <td className="py-3 px-4 text-right font-mono text-[11px] text-slate-400">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
