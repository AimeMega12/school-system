/**
 * Role-Based Access Control (RBAC) & Granular Permission Middleware
 */

export const requireRole = (allowedRoles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Unauthorized. Please sign in.' });
    }

    if (req.user.role === 'director') {
      return next(); // Director is Super Admin with full sovereign permissions
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden. Your role (${req.user.role.toUpperCase()}) lacks authority for this operation.`
      });
    }

    next();
  };
};

export const requirePermission = (permissionKey) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Unauthorized. Please sign in.' });
    }

    if (req.user.role === 'director') {
      return next(); // Director has all permissions
    }

    const userPerms = req.user.permissions || [];
    if (!userPerms.includes(permissionKey)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: Missing required permission '${permissionKey}'. Contact the School Director.`
      });
    }

    next();
  };
};

export default { requireRole, requirePermission };
