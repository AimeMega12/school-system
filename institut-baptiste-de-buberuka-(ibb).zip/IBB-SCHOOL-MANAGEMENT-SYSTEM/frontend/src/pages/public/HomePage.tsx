/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import {
  Code,
  Wrench,
  CheckCircle,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Users,
  Building,
  Sparkles,
  ChevronRight
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 text-white">
        {/* Background Campus Image with measured contrast scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/ibb_campus_hero_1793449104422.jpg"
            alt="Institut Baptiste de Buberuka Campus"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/75 to-slate-900/50" />
          <div className="absolute inset-0 bg-radial-at-c from-transparent via-transparent to-slate-950/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="max-w-3xl">
            {/* Admissions Banner */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold mb-6 backdrop-blur-sm">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('heroBadge')}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight mb-6">
              {t('heroTitle')}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-300 mb-8 leading-relaxed max-w-2xl">
              {t('heroSubtitle')}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4">
              <Link
                to="/apply"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 shadow-lg shadow-emerald-600/30 transition-all"
              >
                <span>{t('heroCtaApply')}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <Link
                to="/programs"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm text-white bg-white/10 hover:bg-white/20 border border-white/20 backdrop-blur-sm transition-all"
              >
                <span>{t('heroCtaPrograms')}</span>
              </Link>

              <Link
                to="/track"
                className="inline-flex items-center gap-2 px-4 py-3.5 rounded-xl font-medium text-xs text-slate-300 hover:text-white transition-colors"
              >
                <span>{t('heroCtaTrack')}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* KPI Proof Strip */}
      <section className="bg-emerald-700 dark:bg-emerald-950 text-white py-8 border-b border-emerald-600 dark:border-emerald-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-3">
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums text-white">
                {t('statGraduatesVal')}
              </div>
              <div className="text-xs sm:text-sm font-medium text-emerald-100 mt-1">
                {t('statGraduates')}
              </div>
            </div>
            <div className="p-3">
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums text-white">
                {t('statLabsVal')}
              </div>
              <div className="text-xs sm:text-sm font-medium text-emerald-100 mt-1">
                {t('statLabs')}
              </div>
            </div>
            <div className="p-3">
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums text-white">
                {t('statStudentsVal')}
              </div>
              <div className="text-xs sm:text-sm font-medium text-emerald-100 mt-1">
                {t('statStudents')}
              </div>
            </div>
            <div className="p-3">
              <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums text-white">
                {t('statPartnersVal')}
              </div>
              <div className="text-xs sm:text-sm font-medium text-emerald-100 mt-1">
                {t('statPartners')}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Programs Showcase */}
      <section className="py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
              Technical Excellence
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-2 mb-4 tracking-tight">
              {t('programsTitle')}
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
              {t('programsSubtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
            {/* Program 1: Software Development */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col hover:shadow-xl transition-shadow">
              <div className="relative h-64 overflow-hidden">
                <img
                  src="/src/assets/images/ibb_software_lab_1793449105866.jpg"
                  alt="Software Development Laboratory at IBB"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-md">
                  {t('levelBadge')}
                </div>
              </div>
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 text-blue-600 dark:text-blue-400 mb-3">
                    <Code className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase tracking-wider">
                      Department of ICT & Software
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-3">
                    {t('progSoftTitle')}
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                    {t('progSoftDesc')}
                  </p>
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 mb-6">
                    <strong className="text-slate-900 dark:text-white block mb-1">
                      Target Career Outcomes:
                    </strong>
                    {t('progSoftCareers')}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {t('durationBadge')}
                  </span>
                  <Link
                    to="/apply?dept=software_development"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 transition-colors"
                  >
                    <span>{t('heroCtaApply')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>

            {/* Program 2: Automobile Technology */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col hover:shadow-xl transition-shadow">
              <div className="relative h-64 overflow-hidden">
                <img
                  src="/src/assets/images/ibb_automobile_tech_1793449106101.jpg"
                  alt="Automobile Technology Workshop at IBB"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-md">
                  {t('levelBadge')}
                </div>
              </div>
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 text-emerald-600 dark:text-emerald-400 mb-3">
                    <Wrench className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase tracking-wider">
                      Department of Automotive Engineering
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mb-3">
                    {t('progAutoTitle')}
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                    {t('progAutoDesc')}
                  </p>
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300 mb-6">
                    <strong className="text-slate-900 dark:text-white block mb-1">
                      Target Career Outcomes:
                    </strong>
                    {t('progAutoCareers')}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {t('durationBadge')}
                  </span>
                  <Link
                    to="/apply?dept=automobile_technology"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 transition-colors"
                  >
                    <span>{t('heroCtaApply')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose IBB */}
      <section className="py-20 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left 6 cols: Reasons */}
            <div className="lg:col-span-7">
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
                Institutional Pillars
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-2 mb-4 tracking-tight">
                {t('whyTitle')}
              </h2>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mb-10 leading-relaxed">
                {t('whySubtitle')}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                      {t('whyPoint1Title')}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {t('whyPoint1Desc')}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <Building className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                      {t('whyPoint2Title')}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {t('whyPoint2Desc')}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                      {t('whyPoint3Title')}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {t('whyPoint3Desc')}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-9 h-9 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                      {t('whyPoint4Title')}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {t('whyPoint4Desc')}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right 5 cols: Student Life Image */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800">
                <img
                  src="/src/assets/images/ibb_student_life_1793449105656.jpg"
                  alt="Students at Institut Baptiste de Buberuka"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 inset-x-0 p-5 bg-gradient-to-t from-slate-950/90 to-transparent text-white">
                  <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
                    Discipline & Brotherhood
                  </div>
                  <div className="text-sm font-bold mt-1">
                    Boarding Community & Christian Fellowship
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Direct Admission CTA Banner */}
      <section className="bg-slate-900 text-white py-16 border-t border-slate-800">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight mb-4">
            Ready to Begin Your Technical Career at IBB?
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto mb-8">
            Submit your online application for Level 3 (L3) with your S3 National Exam marks slip and passport photograph.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/apply"
              className="px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all"
            >
              {t('heroCtaApply')}
            </Link>
            <Link
              to="/track"
              className="px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-all"
            >
              {t('heroCtaTrack')}
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
