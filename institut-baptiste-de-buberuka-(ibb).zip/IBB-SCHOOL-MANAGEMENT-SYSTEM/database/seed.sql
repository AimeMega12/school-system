-- ==============================================================================
-- INSTITUT BAPTISTE DE BUBERUKA (IBB) - RWANDA
-- MySQL Initial Seed Data Script
-- ==============================================================================

USE `ibb_school_db`;

-- 1. USERS & STAFF ACCOUNTS (Password: Password123!)
-- Hash: $2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `full_name`, `role_id`, `phone`, `avatar_url`, `two_factor_enabled`, `two_factor_secret`, `status`) VALUES
('user_director_01', 'director', 'tzrdidier@gmail.com', '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'Rev. Dr. Emmanuel Nshimyumuremyi', 'director', '+250 788 123 456', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', TRUE, 'IBB-SEC-DIR-991', 'active'),
('user_accountant_01', 'accountant', 'accountant@ibb.ac.rw', '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'Clarisse Mukakarisa, CPA', 'accountant', '+250 788 654 321', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150', TRUE, 'IBB-SEC-ACC-402', 'active'),
('user_animator_01', 'animator', 'animator@ibb.ac.rw', '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW', 'Jean-Claude Habimana', 'animator', '+250 788 901 345', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', TRUE, 'IBB-SEC-ANI-773', 'active')
ON DUPLICATE KEY UPDATE `email`=VALUES(`email`), `full_name`=VALUES(`full_name`);

-- 2. ACADEMIC POLICY
INSERT INTO `academic_grading_policies` (`id`, `academic_year`, `minimum_admission_percentage`, `minimum_passing_percentage`, `boarding_eligibility_percentage`, `rules_per_level`, `grade_ranges`, `effective_date`) VALUES
('policy_2026_v1', '2026/2027', 50.00, 50.00, 80.00, 
 '[{"level":"L3","minScore":50.0,"description":"Completion of Senior 3 with minimum 50% score."},{"level":"L4","minScore":55.0,"description":"Completion of Level 3 TVET with 55% verified marks."},{"level":"L5","minScore":60.0,"description":"Completion of Level 4 TVET with 60% technical competence."}]',
 '[{"grade":"Distinction (A)","minPercentage":80.0,"maxPercentage":100.0,"standing":"distinction"},{"grade":"Credit (B)","minPercentage":65.0,"maxPercentage":79.99,"standing":"credit"},{"grade":"Pass (C)","minPercentage":50.0,"maxPercentage":64.99,"standing":"pass"},{"grade":"Fail (F)","minPercentage":0.0,"maxPercentage":49.99,"standing":"fail_repeat"}]',
 '2026-01-01')
ON DUPLICATE KEY UPDATE `minimum_admission_percentage`=VALUES(`minimum_admission_percentage`);

-- 3. PRODUCTS & STAPLE COMMODITIES
INSERT INTO `products` (`id`, `code`, `name_rw`, `name_en`, `category`, `unit`, `min_threshold`, `target_capacity`, `unit_cost_rwf`, `current_stock`) VALUES
('prod_rice_01', 'STK-RIC-01', 'Umuceri', 'Rice', 'cereal', 'Kg', 300.00, 1500.00, 1400.00, 850.00),
('prod_beans_02', 'STK-BEA-02', 'Ibishyimbo', 'Beans', 'vegetable', 'Kg', 250.00, 1200.00, 1100.00, 620.00),
('prod_flour_03', 'STK-MAI-03', 'Kawunga', 'Maize Flour', 'flour', 'Kg', 400.00, 2000.00, 950.00, 1200.00),
('prod_oil_04', 'STK-OIL-04', 'Amavuta yo Guteka', 'Cooking Oil', 'oil', 'Litres', 100.00, 500.00, 2600.00, 240.00),
('prod_potatoes_05', 'STK-POT-05', 'Ibirayi', 'Irish Potatoes', 'tuber', 'Kg', 500.00, 2500.00, 550.00, 140.00),
('prod_sugar_06', 'STK-SUG-06', 'Isukari', 'Sugar', 'sweetener', 'Kg', 80.00, 400.00, 1800.00, 180.00),
('prod_salt_07', 'STK-SLT-07', 'Umunyu', 'Iodized Salt', 'spice', 'Kg', 50.00, 300.00, 400.00, 110.00)
ON DUPLICATE KEY UPDATE `current_stock`=VALUES(`current_stock`);

-- 4. SUPPLIERS
INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `phone`, `email`, `address`, `tin_number`, `rating`) VALUES
('sup_01', 'Agro-Supply Ltd Burera', 'Kamanzi Celestin', '+250 788 112 233', 'kamanzi@agrosupply.rw', 'Burera, Buberuka Commercial Center', '100234567', 5),
('sup_02', 'Koperative Icyerekezo Musanze', 'Mukandori Beatrice', '+250 788 445 566', 'icyerekezo@coop.rw', 'Musanze, Kinigi', '100987654', 5),
('sup_03', 'Rwanda Distribution Commodities Ltd', 'Ntaganda Alexis', '+250 788 778 899', 'alexis@rdc.rw', 'Kigali, Gikondo Industrial Zone', '100554433', 4)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- 5. WORKING HOURS SCHEDULE
INSERT INTO `stock_schedules` (`id`, `morning_start`, `morning_end`, `evening_start`, `evening_end`, `timezone`, `enforce_hours`, `emergency_override_active`) VALUES
('default_schedule', '06:00:00', '08:00:00', '17:00:00', '19:00:00', 'Africa/Kigali', TRUE, FALSE)
ON DUPLICATE KEY UPDATE `enforce_hours`=VALUES(`enforce_hours`);

-- 6. INITIAL APPROVED STUDENTS
INSERT INTO `approved_students` (`id`, `application_id`, `student_name`, `application_number`, `admission_level`, `department`, `academic_score`, `approval_date`, `approved_by`, `boarding_status`, `academic_year`, `status`) VALUES
('appr_01', 'app_03', 'Uwase Claudine', 'IBB-2026-01928', 'L3', 'software_development', 86.00, '2026-10-27 16:00:00', 'Rev. Dr. Emmanuel Nshimyumuremyi', 'boarding_scholar', '2026/2027', 'enrolled'),
('appr_02', 'app_04', 'Manzi Kevin', 'IBB-2026-05612', 'L5', 'automobile_technology', 82.50, '2026-10-26 15:20:00', 'Rev. Dr. Emmanuel Nshimyumuremyi', 'boarding_scholar', '2026/2027', 'enrolled')
ON DUPLICATE KEY UPDATE `student_name`=VALUES(`student_name`);
