/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.tsx';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { NotificationDropdown } from '../../components/common/NotificationDropdown.tsx';
import { StorageService } from '../../services/storage.ts';
import {
  GraduationCap,
  LayoutDashboard,
  Users,
  Package,
  Truck,
  FileBarChart,
  Clock,
  ShieldAlert,
  LogOut,
  Sun,
  Moon,
  Globe,
  Menu,
  X,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Award,
  Radio,
  UserCheck
} from 'lucide-react';

export const DashboardLayout: React.FC = () => {
  const { user, logout, isAuthenticated, hasPermission } = useAuth();
  const { t, language, toggleLanguage } = useLanguage();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // If not logged in, redirect to login declaratively to avoid setState during render
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (path: string) => location.pathname === path;

  // Build nav items based on role & granular permissions
  const getNavItems = () => {
    const items = [];

    if (user.role === 'director') {
      items.push({
        label: t('dirDashboardTitle'),
        path: '/dashboard/director',
        icon: LayoutDashboard
      });
      items.push({
        label: t('admissionsManagementTitle'),
        path: '/dashboard/admissions',
        icon: Users
      });
      items.push({
        label: t('approvedStudentsTitle'),
        path: '/dashboard/approved-students',
        icon: GraduationCap
      });
      items.push({
        label: t('academicPolicyTitle'),
        path: '/dashboard/academic-policy',
        icon: Award
      });
      items.push({
        label: t('stockTitle'),
        path: '/dashboard/stock',
        icon: Package
      });
      items.push({
        label: t('scheduleTitle'),
        path: '/dashboard/schedule',
        icon: Clock
      });
      items.push({
        label: t('suppliersTitle'),
        path: '/dashboard/suppliers',
        icon: Truck
      });
      items.push({
        label: t('accessControlTitle'),
        path: '/dashboard/access-control',
        icon: ShieldCheck
      });
      items.push({
        label: t('otpSettingsTitle'),
        path: '/dashboard/otp-notifications',
        icon: Radio
      });
      items.push({
        label: t('reportsTitle'),
        path: '/dashboard/reports',
        icon: FileBarChart
      });
      items.push({
        label: t('auditLogsTitle'),
        path: '/dashboard/audit',
        icon: ShieldAlert
      });
      items.push({
        label: t('profileTitle'),
        path: '/dashboard/profile',
        icon: UserCheck
      });
    } else if (user.role === 'accountant') {
      items.push({
        label: t('accDashboardTitle'),
        path: '/dashboard/accountant',
        icon: LayoutDashboard
      });
      if (hasPermission('stock_view') || hasPermission('stock_in')) {
        items.push({
          label: t('stockTitle'),
          path: '/dashboard/stock',
          icon: Package
        });
      }
      if (hasPermission('suppliers')) {
        items.push({
          label: t('suppliersTitle'),
          path: '/dashboard/suppliers',
          icon: Truck
        });
      }
      if (hasPermission('reports_financial') || hasPermission('reports_daily')) {
        items.push({
          label: t('reportsTitle'),
          path: '/dashboard/reports',
          icon: FileBarChart
        });
      }
      items.push({
        label: t('profileTitle'),
        path: '/dashboard/profile',
        icon: UserCheck
      });
    } else if (user.role === 'animator') {
      items.push({
        label: t('animDashboardTitle'),
        path: '/dashboard/animator',
        icon: LayoutDashboard
      });
      if (hasPermission('stock_view') || hasPermission('stock_out')) {
        items.push({
          label: t('tabStockOverview'),
          path: '/dashboard/stock',
          icon: Package
        });
      }
      if (hasPermission('reports_daily')) {
        items.push({
          label: t('reportDailyStockOut'),
          path: '/dashboard/reports',
          icon: FileBarChart
        });
      }
      items.push({
        label: t('profileTitle'),
        path: '/dashboard/profile',
        icon: UserCheck
      });
    }

    return items;
  };

  const navItems = getNavItems();

  const getRoleBadgeColor = () => {
    switch (user.role) {
      case 'director':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'accountant':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800';
      case 'animator':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      
      {/* Sidebar Desktop (260px) */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0 select-none">
        {/* Brand */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-blue-700 flex items-center justify-center text-white shadow-md">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="font-extrabold text-sm tracking-tight text-slate-900 dark:text-white leading-none">
              IBB PORTAL
            </div>
            <div className="text-[10px] text-slate-500 font-medium mt-1">
              Institut Baptiste de Buberuka
            </div>
          </div>
        </div>

        {/* User Profile Card */}
        <Link
          to="/dashboard/profile"
          className="p-3 mx-3 my-3 rounded-xl bg-slate-50 hover:bg-emerald-50/50 dark:bg-slate-800/60 dark:hover:bg-slate-800 transition-colors border border-slate-100 dark:border-slate-800 flex items-center gap-3"
        >
          {user.avatarUrl ? (
            <img
              src={user.avatarUrl}
              alt={user.fullName}
              className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
              {user.fullName.charAt(0)}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
              {user.fullName}
            </div>
            <div className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded-md border mt-0.5 ${getRoleBadgeColor()}`}>
              {user.role.toUpperCase()}
            </div>
          </div>
        </Link>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                  active
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Bottom Utility (Logout & System Info) */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 space-y-1">
          <Link
            to="/"
            target="_blank"
            className="flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Globe className="w-4 h-4" />
            <span>{language === 'rw' ? 'Urubuga Rusange' : 'Public Website'}</span>
          </Link>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{t('navLogout')}</span>
          </button>
        </div>
      </aside>

      {/* Main Layout Area */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Topbar */}
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500">
              <span>IBB Rwanda</span>
              <ChevronRight className="w-3.5 h-3.5" />
              <span className="font-semibold text-slate-900 dark:text-white capitalize">
                {location.pathname.split('/')[2] || 'Portal'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Real-time Notifications */}
            <NotificationDropdown />

            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold transition-colors"
              title="Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'en' ? 'RW' : 'EN'}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors"
              title="Toggle Theme"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-600" />}
            </button>
          </div>
        </header>

        {/* Mobile Sidebar Modal */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
              onClick={() => setSidebarOpen(false)}
            />
            <div className="relative w-72 bg-white dark:bg-slate-900 h-full p-5 flex flex-col z-10">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
                <span className="font-extrabold text-sm">IBB PORTAL</span>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="flex-1 py-4 space-y-1 overflow-y-auto">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.path);
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold ${
                        active
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </nav>

              <button
                onClick={handleLogout}
                className="flex items-center gap-2 text-xs font-semibold text-rose-600 pt-4 border-t border-slate-100 dark:border-slate-800"
              >
                <LogOut className="w-4 h-4" />
                <span>{t('navLogout')}</span>
              </button>
            </div>
          </div>
        )}

        {/* Viewport Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>

    </div>
  );
};
