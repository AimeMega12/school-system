/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { StockPermissionDelegation } from '../../types/index.ts';
import {
  DollarSign,
  Package,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  Truck,
  UserCheck,
  FileBarChart,
  Plus,
  Clock,
  ShieldCheck,
  CheckCircle2,
  X
} from 'lucide-react';

export const AccountantDashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  const products = StorageService.getProducts();
  const transactions = StorageService.getTransactions();
  const suppliers = StorageService.getSuppliers();
  const [delegations, setDelegations] = useState<StockPermissionDelegation[]>(() =>
    StorageService.getDelegations()
  );

  // Delegation modal state
  const [isDelegationModalOpen, setIsDelegationModalOpen] = useState(false);
  const [delegationDuration, setDelegationDuration] = useState<'2' | '6' | '24' | '48'>('2');
  const [delegationReason, setDelegationReason] = useState('Delegated to Animator while Accountant attends district education audit');
  const [feedback, setFeedback] = useState('');

  // Calculations
  const totalValuationRwf = products.reduce(
    (sum, p) => sum + p.currentStock * p.unitCostRwf,
    0
  );
  const totalStockKg = products.reduce((sum, p) => sum + p.currentStock, 0);
  const lowStockProducts = products.filter((p) => p.currentStock <= p.minThreshold);
  const recentStockIns = transactions.filter((t) => t.type === 'stock_in').slice(0, 5);
  const recentStockOuts = transactions.filter((t) => t.type === 'stock_out').slice(0, 5);

  const activeDelegation = delegations.find(
    (d) => d.status === 'active' && new Date(d.expiresAt) > new Date()
  );

  const handleGrantDelegation = (e: React.FormEvent) => {
    e.preventDefault();
    const durationHours = Number(delegationDuration);
    const expiresAt = new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString();

    const newDelegation: StockPermissionDelegation = {
      id: `del_${Date.now()}`,
      grantedToUserId: 'user_animator_01',
      grantedToUserName: 'Jean-Claude Habimana',
      grantedByUserId: user!.id,
      grantedByUserName: user!.fullName,
      permission: 'stock_in',
      startsAt: new Date().toISOString(),
      expiresAt,
      status: 'active',
      reason: delegationReason.trim(),
      createdAt: new Date().toISOString()
    };

    StorageService.addDelegation(newDelegation);
    setDelegations(StorageService.getDelegations());

    // Audit log
    StorageService.addAuditLog({
      action: 'PERMISSION_DELEGATED',
      category: 'permission',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Accountant delegated Stock In permission to Animator Jean-Claude for ${durationHours} hours. Reason: ${delegationReason}`,
      ipAddress: '197.243.34.82'
    });

    // Notify Animator and Director
    addNotification({
      title: 'Stock In Permission Delegated to Animator',
      titleRw: 'Uburenganzira bwa Stock In Bwahaye Animator',
      message: `${user!.fullName} granted temporary Stock In authority to Animator for ${durationHours} hours.`,
      messageRw: `${user!.fullName} yahaye Animator uburenganzira bwo kwakira no kwandika ibiribwa byinjiye mu masaha ${durationHours}.`,
      type: 'info',
      category: 'permission',
      targetRoles: ['director', 'accountant', 'animator'],
      relatedId: newDelegation.id
    });

    setIsDelegationModalOpen(false);
    setFeedback(`Granted ${durationHours} hours Stock In delegation to Animator Jean-Claude.`);
    setTimeout(() => setFeedback(''), 4000);
  };

  const handleRevokeDelegation = (id: string) => {
    const updated = delegations.map((d) => (d.id === id ? { ...d, status: 'revoked' as const } : d));
    StorageService.saveDelegations(updated);
    setDelegations(updated);

    StorageService.addAuditLog({
      action: 'PERMISSION_REVOKED',
      category: 'permission',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Accountant revoked delegated Stock In permission from Animator`,
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: 'Delegated Stock In Revoked',
      titleRw: 'Uburenganzira bwo Kwinjiza Bwahagaritswe',
      message: 'Accountant revoked temporary Stock In authority from Animator.',
      messageRw: 'Ushinzwe imari yahagaritse uburenganzira bwa Stock In bwa Animator.',
      type: 'warning',
      category: 'permission',
      targetRoles: ['director', 'accountant', 'animator']
    });

    setFeedback('Delegated permission revoked immediately.');
    setTimeout(() => setFeedback(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('accDashboardTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('accDashboardSub')}
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Link
            to="/dashboard/stock"
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-md shadow-blue-600/20"
          >
            <ArrowDownRight className="w-4 h-4" />
            <span>{t('btnMainStockIn')}</span>
          </Link>

          <button
            onClick={() => setIsDelegationModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors"
          >
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>{t('btnDelegateAnimator')}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Delegation Status Pill */}
      {activeDelegation ? (
        <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span className="font-bold text-blue-900 dark:text-blue-200">
              Active Temporary Delegation: Animator Jean-Claude can perform Main Stock In
            </span>
            <span className="text-slate-500">
              (Expires: {new Date(activeDelegation.expiresAt).toLocaleTimeString()})
            </span>
          </div>
          <button
            onClick={() => handleRevokeDelegation(activeDelegation.id)}
            className="text-xs font-bold text-rose-600 hover:underline"
          >
            Revoke Now
          </button>
        </div>
      ) : null}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Total Inventory Valuation
          </span>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums truncate">
            {totalValuationRwf.toLocaleString()} RWF
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Across 7 staple food categories
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Total Available Stock
          </span>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
            {totalStockKg.toLocaleString()} Units/Kg
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            In physical campus dry food storage
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Low Stock Alerts
          </span>
          <div className={`text-xl sm:text-2xl font-extrabold font-mono tabular-nums ${lowStockProducts.length > 0 ? 'text-rose-600' : 'text-slate-900 dark:text-white'}`}>
            {lowStockProducts.length} Items
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block truncate">
            {lowStockProducts.length > 0 ? 'Reorder orders required' : 'Stock levels adequate'}
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Active Suppliers
          </span>
          <div className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
            {suppliers.length} Vendors
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Vetted local Rwandan coops
          </span>
        </div>
      </div>

      {/* 2-Column Split: Recent Stock In & Recent Stock Out */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left: Main Stock In Consignments */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ArrowDownRight className="w-4 h-4 text-blue-600" />
              <span>Recent Main Stock In (Consignments)</span>
            </h3>
            <Link to="/dashboard/stock" className="text-xs font-bold text-blue-600 hover:underline">
              View All
            </Link>
          </div>

          <div className="space-y-3">
            {recentStockIns.map((tx) => (
              <div
                key={tx.id}
                className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">
                    {tx.productName}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Supplier: {tx.supplierName} · By {tx.performedByUserName}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-extrabold text-blue-600 dark:text-blue-400">
                    +{tx.quantity} {tx.unit}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {new Date(tx.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Daily Stock Out Issues */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <ArrowUpRight className="w-4 h-4 text-emerald-600" />
              <span>Recent Daily Stock Out (Animator Issues)</span>
            </h3>
            <Link to="/dashboard/stock" className="text-xs font-bold text-emerald-600 hover:underline">
              View All
            </Link>
          </div>

          <div className="space-y-3">
            {recentStockOuts.map((tx) => (
              <div
                key={tx.id}
                className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900 dark:text-white">
                    {tx.productName}
                  </div>
                  <div className="text-[11px] text-slate-500 capitalize">
                    Purpose: {tx.mealCategory || 'Meal Ration'} · By {tx.performedByUserName}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-extrabold text-emerald-600 dark:text-emerald-400">
                    -{tx.quantity} {tx.unit}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {new Date(tx.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Modal: Grant Animator Stock In Permission */}
      {isDelegationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('delegationModalTitle')}
              </h3>
              <button onClick={() => setIsDelegationModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
              {t('delegationModalDesc')}
            </p>

            <form onSubmit={handleGrantDelegation} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">
                  Target Staff Member
                </label>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold">
                  Jean-Claude Habimana (Stock Animator)
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">
                  {t('delegationDuration')} *
                </label>
                <select
                  value={delegationDuration}
                  onChange={(e) => setDelegationDuration(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="2">{t('duration2Hours')}</option>
                  <option value="6">{t('duration6Hours')}</option>
                  <option value="24">{t('duration24Hours')}</option>
                  <option value="48">{t('durationWeekend')}</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">
                  Audit Reason for Delegation *
                </label>
                <textarea
                  required
                  rows={3}
                  value={delegationReason}
                  onChange={(e) => setDelegationReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsDelegationModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-md shadow-blue-600/20"
                >
                  {t('grantDelegationBtn')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
