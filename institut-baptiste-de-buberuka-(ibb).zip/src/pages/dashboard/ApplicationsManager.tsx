/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { StudentApplication, ApplicationStatus, DepartmentType, AcademicLevel, ApprovedStudent } from '../../types/index.ts';
import {
  Search,
  CheckCircle2,
  XCircle,
  FileText,
  Eye,
  Filter,
  UserCheck,
  Calendar,
  AlertCircle,
  X,
  Send,
  Download,
  Mail,
  Phone,
  AlertTriangle,
  Award,
  ShieldCheck
} from 'lucide-react';

export const ApplicationsManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();
  const [searchParams] = useSearchParams();

  const [applications, setApplications] = useState<StudentApplication[]>(() =>
    StorageService.getApplications()
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | ApplicationStatus>('all');
  const [deptFilter, setDeptFilter] = useState<'all' | DepartmentType>('all');
  const [levelFilter, setLevelFilter] = useState<'all' | AcademicLevel>('all');

  // Active Review Modal
  const [selectedApp, setSelectedApp] = useState<StudentApplication | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [waiverJustification, setWaiverJustification] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [showWaiverForm, setShowWaiverForm] = useState(false);
  const [documentModalUrl, setDocumentModalUrl] = useState<{ url: string; title: string } | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');
  const [modalError, setModalError] = useState('');

  // Handle direct review link via query param
  useEffect(() => {
    const reviewId = searchParams.get('review');
    if (reviewId) {
      const match = applications.find((a) => a.id === reviewId);
      if (match) {
        setSelectedApp(match);
        setReviewNotes(match.reviewNotes || '');
        setRejectionReason(match.rejectionReason || '');
        setModalError('');
      }
    }
  }, [searchParams, applications]);

  const reloadData = () => {
    setApplications(StorageService.getApplications());
  };

  // Filtered applications
  const filteredApps = applications.filter((app) => {
    const matchesSearch =
      app.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.previousSchool.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.district.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    const matchesDept = deptFilter === 'all' || app.department === deptFilter;
    const matchesLevel = levelFilter === 'all' || app.applyingLevel === levelFilter;

    return matchesSearch && matchesStatus && matchesDept && matchesLevel;
  });

  const handleApprove = (app: StudentApplication, isWaiver = false) => {
    setModalError('');
    if (user?.role !== 'director') {
      setModalError('Only the School Director can approve admissions.');
      return;
    }

    if (isWaiver && !waiverJustification.trim()) {
      setModalError('An exceptional waiver justification reason is mandatory.');
      return;
    }

    const updatedNotes = isWaiver
      ? `Director Exceptional Waiver Issued: ${waiverJustification.trim()}. ${reviewNotes.trim()}`
      : reviewNotes.trim() || `Approved for ${app.applyingLevel} technical intake. All requirements verified.`;

    const updated: StudentApplication = {
      ...app,
      status: 'approved',
      reviewedAt: new Date().toISOString(),
      reviewedBy: user.fullName,
      reviewNotes: updatedNotes
    };

    StorageService.updateApplication(updated);

    // Register into official Approved Students store
    const approvedStudentEntry: ApprovedStudent = {
      id: `appr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      applicationId: app.id,
      studentName: app.fullName,
      applicationNumber: app.trackingNumber,
      admissionLevel: app.applyingLevel,
      department: app.department,
      academicScore: app.academicScorePercentage,
      approvalDate: new Date().toISOString(),
      approvedBy: user.fullName,
      boardingStatus: app.academicScorePercentage >= 80 ? 'boarding_scholar' : 'day_scholar',
      academicYear: app.academicYear || '2026/2027',
      status: 'enrolled'
    };
    StorageService.addApprovedStudent(approvedStudentEntry);

    // Audit log
    StorageService.addAuditLog({
      action: isWaiver ? 'ADMISSION_WAIVER_APPROVED' : 'ADMISSION_APPROVED',
      category: 'admission',
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      details: isWaiver
        ? `Director issued exceptional waiver and approved ${app.fullName} (${app.trackingNumber}) with score ${app.academicScorePercentage}%. Justification: ${waiverJustification.trim()}`
        : `Director approved student ${app.fullName} (${app.trackingNumber}) for ${app.applyingLevel} - ${app.department}`,
      ipAddress: '197.243.34.82'
    });

    // Notify System & Applicant via SMS Delivery Log
    StorageService.addDeliveryLog({
      channel: 'sms',
      recipient: app.phone,
      subject: 'KASS Admission Approved',
      content: `KASS Rwanda: Congratulations ${app.fullName}! Your admission for ${app.applyingLevel} ${app.department === 'software_development' ? 'Software Development' : 'Automobile Tech'} has been APPROVED by the School Director.`,
      status: 'delivered',
      providerResponse: 'SMS_GATEWAY_DELIVERED_RWA'
    });

    addNotification({
      title: `Admission Approved: ${app.fullName} (${app.applyingLevel})`,
      titleRw: `Ubusabe Bwaremewe: ${app.fullName} (${app.applyingLevel})`,
      message: `Director approved admission for candidate ${app.fullName} (${app.trackingNumber}). Candidate enrolled in ${app.applyingLevel}.`,
      messageRw: `Umuyobozi yemeje ko ${app.fullName} (${app.trackingNumber}) yinjira mu cyiciro cya ${app.applyingLevel}.`,
      type: 'success',
      category: 'admission',
      targetRoles: ['director', 'accountant'],
      relatedId: app.id
    });

    setActionSuccessMsg(
      isWaiver
        ? `Exceptional waiver approved for ${app.fullName}. Official registry updated.`
        : `Successfully APPROVED admission for ${app.fullName}. Enrolled into ${app.applyingLevel} register.`
    );
    setSelectedApp(updated);
    setShowWaiverForm(false);
    reloadData();
    setTimeout(() => setActionSuccessMsg(''), 4500);
  };

  const handleReject = (app: StudentApplication) => {
    setModalError('');
    if (user?.role !== 'director') {
      setModalError('Only the School Director can reject admissions.');
      return;
    }

    if (!rejectionReason.trim()) {
      setModalError('A formal rejection reason is mandatory.');
      return;
    }

    const updated: StudentApplication = {
      ...app,
      status: 'rejected',
      reviewedAt: new Date().toISOString(),
      reviewedBy: user.fullName,
      reviewNotes: reviewNotes.trim(),
      rejectionReason: rejectionReason.trim()
    };

    StorageService.updateApplication(updated);

    // Audit log
    StorageService.addAuditLog({
      action: 'ADMISSION_REJECTED',
      category: 'admission',
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      details: `Director rejected application ${app.trackingNumber}. Reason: ${rejectionReason.trim()}`,
      ipAddress: '197.243.34.82'
    });

    // Notify System
    addNotification({
      title: `Application Not Accepted: ${app.fullName}`,
      titleRw: `Ubusabe Butaremejwe: ${app.fullName}`,
      message: `Director declined application ${app.trackingNumber}. Formal reason recorded.`,
      messageRw: `Umuyobozi ntiyemeje ubusabe ${app.trackingNumber}. Impamvu yanditswe.`,
      type: 'warning',
      category: 'admission',
      targetRoles: ['director'],
      relatedId: app.id
    });

    setActionSuccessMsg(`Recorded REJECTION for ${app.fullName} with formal reason.`);
    setSelectedApp(updated);
    setShowRejectForm(false);
    reloadData();
    setTimeout(() => setActionSuccessMsg(''), 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <DashboardPageHeader
        title={t('admissionsManagementTitle')}
        subtitle={t('admissionsSubTitle')}
        variant="blue"
      >
        {/* Counter Pills */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
          <span className="px-3 py-1.5 rounded-xl bg-white/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            {applications.length} Total Applications
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            {applications.filter((a) => a.status === 'approved').length} Approved
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
            {applications.filter((a) => a.status === 'automatically_rejected').length} Auto-Rejected
          </span>
        </div>
      </DashboardPageHeader>

      {actionSuccessMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search candidate name, tracking #, district, or school..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Level Filter */}
          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value as any)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Levels (L3, L4, L5)</option>
            <option value="L3">Level 3 (L3)</option>
            <option value="L4">Level 4 (L4)</option>
            <option value="L5">Level 5 (L5)</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Statuses</option>
            <option value="eligible">Eligible (Ready for Review)</option>
            <option value="pending">Pending</option>
            <option value="under_review">Under Review</option>
            <option value="approved">Approved</option>
            <option value="automatically_rejected">Auto-Rejected (Below Cut-Off)</option>
            <option value="rejected">Rejected</option>
          </select>

          {/* Department Filter */}
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value as any)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Departments</option>
            <option value="software_development">Software Development</option>
            <option value="automobile_technology">Automobile Technology</option>
          </select>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                <th className="py-3 px-4 font-bold">Candidate</th>
                <th className="py-3 px-4 font-bold">Tracking #</th>
                <th className="py-3 px-4 font-bold">Entry Level</th>
                <th className="py-3 px-4 font-bold">Department</th>
                <th className="py-3 px-4 font-bold">Verified Marks</th>
                <th className="py-3 px-4 font-bold">Location</th>
                <th className="py-3 px-4 font-bold">Status</th>
                <th className="py-3 px-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
              {filteredApps.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No applications matched your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredApps.map((app) => (
                  <tr
                    key={app.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedApp(app);
                      setReviewNotes(app.reviewNotes || '');
                      setRejectionReason(app.rejectionReason || '');
                      setShowRejectForm(false);
                      setShowWaiverForm(false);
                    }}
                  >
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 dark:text-white">
                        {app.fullName}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {app.phone} · {app.previousSchool}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {app.trackingNumber}
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 font-mono font-bold px-2 py-0.5 rounded text-xs ${
                        app.applyingLevel === 'L3'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : app.applyingLevel === 'L4'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
                      }`}>
                        {app.applyingLevel}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300 font-medium">
                      {app.department === 'software_development'
                        ? 'Software Development'
                        : 'Automobile Tech'}
                    </td>

                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                      {app.academicScorePercentage}%
                    </td>

                    <td className="py-3.5 px-4 text-slate-500">
                      {app.district}, {app.sector}
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          app.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : app.status === 'automatically_rejected'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                            : app.status === 'rejected'
                            ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                            : app.status === 'eligible'
                            ? 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                        }`}
                      >
                        {app.status === 'automatically_rejected' ? 'Auto-Rejected' : app.status.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedApp(app);
                          setReviewNotes(app.reviewNotes || '');
                          setRejectionReason(app.rejectionReason || '');
                          setShowRejectForm(false);
                          setShowWaiverForm(false);
                        }}
                        className="px-3 py-1 rounded-lg text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100"
                      >
                        Review
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Drawer / Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6">
            
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
                  Director Evaluation Panel
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
                  {selectedApp.fullName}
                </h3>
                <span className="font-mono text-xs text-slate-500">
                  Tracking: {selectedApp.trackingNumber} · Level: {selectedApp.applyingLevel}
                </span>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {modalError && (
              <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{modalError}</span>
              </div>
            )}

            {/* Auto Rejection Alert Banner if applicable */}
            {selectedApp.status === 'automatically_rejected' && (
              <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs text-rose-800 dark:text-rose-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>Flagged by System: Score below Director Admission Threshold</span>
                </div>
                <p>
                  {selectedApp.autoRejectionReason || `Academic score (${selectedApp.academicScorePercentage}%) does not meet minimum cut-off.`}
                </p>
                <p className="text-[11px] opacity-80 pt-1 font-semibold">
                  As School Director, you may issue an Exceptional Admission Waiver below with recorded justification.
                </p>
              </div>
            )}

            {/* Candidate Dossier */}
            <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-slate-500 block">Father's Name</span>
                <span className="font-semibold text-slate-900 dark:text-white">{selectedApp.fatherName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Mother's Name</span>
                <span className="font-semibold text-slate-900 dark:text-white">{selectedApp.motherName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Date of Birth & Gender</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {selectedApp.dateOfBirth} · {selectedApp.gender.toUpperCase()}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Phone (Parent)</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">{selectedApp.phone}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Residential Location</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {selectedApp.district}, {selectedApp.sector}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Previous School & Level</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {selectedApp.previousSchool} ({selectedApp.previousAcademicLevel || 'Senior 3'})
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Target Department</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">
                  {selectedApp.department === 'software_development'
                    ? 'Software Development'
                    : 'Automobile Technology'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Verified Academic Percentage</span>
                <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-sm tabular-nums">
                  {selectedApp.academicScorePercentage}%
                </span>
              </div>
            </div>

            {/* Uploaded Documents Inspection */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3">
                Candidate Submitted Credentials
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() =>
                    setDocumentModalUrl({
                      url: selectedApp.resultSlipUrl,
                      title: `Academic Result Slip - ${selectedApp.fullName}`
                    })
                  }
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-left hover:border-emerald-500 transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-blue-500" />
                    <div>
                      <span className="block font-bold text-xs text-slate-900 dark:text-white">
                        Result Slip / Certificate
                      </span>
                      <span className="text-[10px] text-slate-500 truncate block max-w-[140px]">
                        {selectedApp.resultSlipFileName}
                      </span>
                    </div>
                  </div>
                  <Eye className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setDocumentModalUrl({
                      url: selectedApp.passportPhotoUrl,
                      title: `Passport Photo - ${selectedApp.fullName}`
                    })
                  }
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-left hover:border-emerald-500 transition-colors flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={selectedApp.passportPhotoUrl}
                      alt="passport"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                    <div>
                      <span className="block font-bold text-xs text-slate-900 dark:text-white">
                        Passport Photo
                      </span>
                      <span className="text-[10px] text-slate-500 truncate block max-w-[140px]">
                        {selectedApp.passportPhotoFileName}
                      </span>
                    </div>
                  </div>
                  <Eye className="w-4 h-4 text-slate-400" />
                </button>
              </div>
            </div>

            {/* Internal Review Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Director Review Attestation & Internal Notes
              </label>
              <textarea
                rows={2}
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                placeholder={t('internalNotesPlaceholder')}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Exceptional Waiver Form (for auto-rejected or borderline cases) */}
            {showWaiverForm && (
              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900 dark:text-amber-200">
                  <ShieldCheck className="w-4 h-4 text-amber-600" />
                  <span>Director Exceptional Admission Waiver</span>
                </div>
                <p className="text-[11px] text-amber-800 dark:text-amber-300">
                  Enter formal justification for waiving the threshold for candidate {selectedApp.fullName} (Score: {selectedApp.academicScorePercentage}%):
                </p>
                <textarea
                  required
                  rows={2}
                  value={waiverJustification}
                  onChange={(e) => setWaiverJustification(e.target.value)}
                  placeholder="e.g. Demonstrated exceptional technical aptitude during oral workshop interview and validated practical experience..."
                  className="w-full px-3 py-2 rounded-lg border border-amber-300 dark:border-amber-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowWaiverForm(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApprove(selectedApp, true)}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 shadow-sm"
                  >
                    Authorize Waiver & Enroll Student
                  </button>
                </div>
              </div>
            )}

            {/* Rejection Form Box (if toggled) */}
            {showRejectForm && (
              <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 space-y-3">
                <label className="block text-xs font-bold text-rose-800 dark:text-rose-300">
                  {t('rejectionReasonLabel')} (Mandatory)
                </label>
                <textarea
                  required
                  rows={3}
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder={t('rejectionReasonPlaceholder')}
                  className="w-full px-3 py-2 rounded-lg border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowRejectForm(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => handleReject(selectedApp)}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 shadow-sm"
                  >
                    Confirm Formal Rejection
                  </button>
                </div>
              </div>
            )}

            {/* Action Bar */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500 font-medium">
                Current Status: <strong className="uppercase">{selectedApp.status.replace('_', ' ')}</strong>
              </span>

              <div className="flex flex-wrap items-center gap-2">
                {selectedApp.status === 'automatically_rejected' && !showWaiverForm && (
                  <button
                    type="button"
                    onClick={() => setShowWaiverForm(true)}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 transition-colors flex items-center gap-1.5"
                  >
                    <Award className="w-3.5 h-3.5" />
                    <span>Exceptional Waiver</span>
                  </button>
                )}

                {selectedApp.status !== 'rejected' && !showRejectForm && (
                  <button
                    type="button"
                    onClick={() => setShowRejectForm(true)}
                    className="px-3.5 py-2 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 transition-colors"
                  >
                    {t('rejectApplicationBtn')}
                  </button>
                )}

                {selectedApp.status !== 'approved' && !showWaiverForm && (
                  <button
                    type="button"
                    onClick={() => handleApprove(selectedApp, false)}
                    className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{t('approveApplicationBtn')}</span>
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Document View Modal */}
      {documentModalUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-xl w-full p-6 text-slate-900 dark:text-white">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <h4 className="text-sm font-bold truncate">{documentModalUrl.title}</h4>
              <button
                onClick={() => setDocumentModalUrl(null)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 max-h-[60vh] flex items-center justify-center">
              <img
                src={documentModalUrl.url}
                alt={documentModalUrl.title}
                className="max-h-[60vh] w-auto object-contain"
              />
            </div>
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setDocumentModalUrl(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-slate-800 hover:bg-slate-700"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
