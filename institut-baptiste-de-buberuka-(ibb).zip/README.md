# INSTITUT BAPTISTE DE BUBERUKA (IBB) — RWANDA
## Complete Bilingual School Management System, Student Admissions (L3-L5), Food Stock Inventory & Multi-Channel Security

**Institut Baptiste de Buberuka (IBB)** is an accredited technical and vocational secondary institution situated in Buberuka, Burera District, Northern Province, Rwanda. Operating under the partnership of the Union of Baptist Churches in Rwanda (UEBR) and the Ministry of Education (MINEDUC) / Rwanda TVET Board (RTB), IBB provides industry-aligned technical education in **Software Development** and **Automobile Technology**.

This integrated platform delivers a public institutional portal, student online admission workflows from **Level 3 (L3) to Level 5 (L5)**, configurable RTB academic grading policies, intelligent food inventory management, granular staff access control, configurable multi-channel OTP security, and audit governance.

---

## 1. Key System Modules

### 🌐 A. Public Institutional Portal & Online Admissions (L3, L4, L5)
- **Bilingual Interface**: Instant English and Kinyarwanda (`Ikinyarwanda`) language switching across every page and modal.
- **Dual Themes**: Polished Light Theme (Clean White) and Dark Theme (Deep Navy `#020617`).
- **Accredited TVET Programs from Level 3 to Level 5**:
  1. **Software Development (L3, L4, L5)**: Algorithms, full-stack web, mobile applications, database architecture, DevOps, cloud integration.
  2. **Automobile Technology (L3, L4, L5)**: Computerized OBD-II diagnostics, electronic fuel injection (EFI), hybrid/electric powertrain maintenance, engine overhaul, automotive electricity.
- **Online Admission Application**:
  - Entry level selector: **Level 3 (L3)**, **Level 4 (L4)**, and **Level 5 (L5)**.
  - Candidate, parental, and residential details across Rwanda districts.
  - Verified academic percentage input (e.g., `78.5%`) and previous academic level completed (Senior 3, Level 3 TVET, Senior 4, Level 4 TVET, Senior 5).
  - **Live Eligibility Feedback**: Evaluates applicant percentage against the Director's active policy threshold (`StorageService.getAcademicPolicy()`) in real time, alerting if score meets or falls below cut-off.
  - Digital document uploads: Academic result slips and passport photos.
  - Unique tracking number generation (e.g. `IBB-2026-01928`).
  - Online application tracking with official printable admission acceptance certificates.

### 📜 B. RTB Academic Grading & Admission Policy Governance (Director)
- **Configurable Cut-off Percentages**:
  - Minimum Admission Percentage (e.g., `50.0%`).
  - Minimum Passing Percentage (e.g., `50.0%`).
  - Minimum Score for Boarding Scholar Eligibility (e.g., `80.0%`).
- **Level-Specific Thresholds**: Configurable cut-offs for Level 3, Level 4, and Level 5.
- **Automatic Rejection Engine**: Applications below the minimum threshold are flagged as `automatically_rejected`, generating an immutable audit record and dispatching an SMS/Email notification.
- **Director Exceptional Waiver**: The Director retains sovereign authority to issue an exceptional admission waiver with mandatory recorded justification.
- **Grade Scale & Progressions**: Distinction (≥80%), Credit (65-79.9%), Pass (50-64.9%), Fail (<50%), plus RTB promotion and repeating guidelines.

### 🎓 C. Approved Students Registry (Director)
- Dedicated register of students officially accepted into IBB.
- Grouping and filtering by **Level 3 (L3)**, **Level 4 (L4)**, **Level 5 (L5)**, Specialization, and Boarding Scholar vs. Day Scholar status.
- Printable official student register and instant **CSV / Excel export**.

### 🛡️ D. Centralized Staff Access Control & Granular Permissions (Director)
- Director manages module and action permissions for the **Accountant** and **Animator**.
- Granular permissions: `stock_view`, `stock_in`, `stock_out`, `stock_correction`, `suppliers`, `reports_financial`, `reports_stock`, `admissions_view`.
- Immediate enforcement across active sessions without page reload.
- Full audit logging of all privilege grants and revocations.

### 🔐 E. Configurable OTP Security & Multi-Channel Dispatch (Director)
- **3 Configurable OTP Verification Modes**:
  1. **Option 1: Email Only** (Dispatched to official staff email).
  2. **Option 2: SMS Only** (Direct delivery via Rwanda `+250` MTN/Airtel SMS cellular gateway).
  3. **Option 3: Dual Email + SMS** (Maximum security; requires entering both verification tokens).
- **Multi-Channel Dispatch Engine**: In-App alerts (Socket.IO), SMS (+250 Rwanda Gateway), WhatsApp Business Cloud API, and SMTP Email Relay.
- Real-time **Notification Delivery Logs** (`pending`, `sent`, `delivered`, `failed`) and interactive gateway handshake test ping tool.

### 👤 F. Director Profile & Identity Management
- Official photo upload and replace (JPG, PNG, WebP) with instant preview.
- Personal and institutional contact credentials management.
- **Email-Verified Password Reset**: Requires generating and verifying a 6-digit OTP code dispatched to the registered email before committing password updates.

### 🍲 G. Intelligent Food Stock Management
- 7 staple commodities tracked: Rice, Beans, Maize Flour, Vegetable Oil, Irish Potatoes, Sugar, Salt.
- **Working Hours Automated Enforcement**: Morning distribution (06:00 - 08:00 AM) and Evening distribution (17:00 - 19:00 PM) in Rwanda time (`Africa/Kigali`).
- **Director Emergency Override**: Out-of-hours food issuance with mandatory justification note.
- **Accountant Main Stock In & Temporary Delegation**: Delegate incoming inventory registration to the Animator for a defined time window.
- **Audited Inventory Corrections**: Discrepancy corrections with non-destructive audit log tracking.

---

## 2. Staff Roles & Credentials (Demo Mode)

| Role | Username | Password | Full Name | Primary Responsibilities |
|---|---|---|---|---|
| **Director** (Super Admin) | `director` | `Password123!` | Rev. Dr. Emmanuel Nshimyumuremyi | Admissions, Grading Rules, Staff Permissions, OTP Config, Overrides |
| **Accountant** | `accountant` | `Password123!` | Clarisse Mukakarisa, CPA | Products, Stock In, Suppliers, Financial Reports, Temporary Delegation |
| **Animator** | `animator` | `Password123!` | Jean-Claude Habimana | Daily Meal Stock Out (06:00-08:00 & 17:00-19:00), Stock Balances |

*Note: Demo OTP helper chips are available on the login and verification screens for instant autofill and testing.*

---

## 3. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide React icons, Recharts analytics, Motion.
- **Database Schema**: Full relational MySQL 8.0 DDL provided in `/schema.sql`.
- **Architectural Standards**: Client-side reactive persistence (`StorageService`), granular RBAC middleware, bilingual translation dictionary, dark/light theme tokens.
