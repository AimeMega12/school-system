/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { Link } from 'react-router-dom';
import { FileText, CheckCircle2, Calendar, Award, ShieldAlert, ArrowRight, Search } from 'lucide-react';

export const AdmissionsPage: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="py-12 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            {language === 'rw' ? 'Kwakira Abanyeshuri Bashya' : 'Admissions Portal'}
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-2 mb-4 text-slate-900 dark:text-white">
            {language === 'rw' ? 'Kwinjira muri Karenge Adventist Secondary School' : 'Join Karenge Adventist for Academic Year 2026/2027'}
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300">
            {language === 'rw'
              ? 'Twakira abanyeshuri bose barangije icyiciro rusange cy’amashuri yisumbuye (Ordinary Level / S3) bifuza kwiga imyuga n’ubumenyingiro.'
              : 'Open to all graduates of Nine / Twelve Year Basic Education who have completed Ordinary Level (S3) and hold official national examination result slips.'}
          </p>
        </div>

        {/* Steps to Apply */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-9 h-9 rounded-full bg-emerald-600 text-white font-extrabold flex items-center justify-center text-sm mb-4">
              1
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Tegura Inyandiko' : 'Prepare Documents'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {language === 'rw'
                ? 'Shaka ifoto ya pasiporo igaragara neza hamwe n’icyemezo cy’amanota ya S3 (Result slip).'
                : 'Prepare a digital scan or clear photo of your S3 National Exam result slip and a recent passport photo.'}
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-9 h-9 rounded-full bg-blue-600 text-white font-extrabold flex items-center justify-center text-sm mb-4">
              2
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Uzuza Ifishi ku Murongo' : 'Submit Application'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {language === 'rw'
                ? 'Kanda kuri "Saba Umwanya", uzuze neza imyirondoro yawe n’iy’ababyeyi, uhitemo ishami ry’amahitamo yawe.'
                : 'Fill out our secure online admission form and receive an instant unique tracking number (KASS-2026-XXXXX).'}
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <div className="w-9 h-9 rounded-full bg-indigo-600 text-white font-extrabold flex items-center justify-center text-sm mb-4">
              3
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {language === 'rw' ? 'Isuzuma n’Icyemezo' : 'Director Evaluation'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {language === 'rw'
                ? 'Umuyobozi w’Ikigo asuzuma dosiye yawe, akemeza ko wakirwa, ugahita ubona ibaruwa yawe yo kwakirwa.'
                : 'The School Director reviews your academic profile. Successful candidates receive immediate digital acceptance slips.'}
            </p>
          </div>
        </div>

        {/* Requirements Box */}
        <div className="p-8 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 mb-16">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
            {language === 'rw' ? 'Ibisabwa kugira ngo Wemererwe Kwiga' : 'Admission Requirements & Eligibility'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-400">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Completion of Ordinary Level (Senior 3) in Rwanda or equivalent accredited international certificate.</span>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>National Examination Result Slip stamped or verified by NESA / MINEDUC.</span>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Recent clear passport-sized photo on white background.</span>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Parent / legal guardian active telephone contact for SMS verification and pastoral reports.</span>
            </div>
          </div>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/apply"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all"
          >
            <span>{t('heroCtaApply')}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <Link
            to="/track"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-semibold text-sm text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
          >
            <Search className="w-4 h-4" />
            <span>{t('heroCtaTrack')}</span>
          </Link>
        </div>

      </div>
    </div>
  );
};
