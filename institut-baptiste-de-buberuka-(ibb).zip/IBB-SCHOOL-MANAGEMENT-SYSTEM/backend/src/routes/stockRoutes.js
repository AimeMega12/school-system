import express from 'express';
import {
  getProducts,
  getTransactions,
  recordStockIn,
  recordStockOut,
  recordCorrection,
  toggleEmergencyOverride
} from '../controllers/stockController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole, requirePermission } from '../middleware/rbac.js';
import { checkWorkingHours } from '../middleware/workingHours.js';

const router = express.Router();

router.get('/products', authenticateToken, getProducts);
router.get('/transactions', authenticateToken, getTransactions);

// Stock In: Accountant or Animator with delegation
router.post('/in', authenticateToken, requirePermission('stock_in'), recordStockIn);

// Stock Out: Animator / Accountant with working hours enforcement
router.post('/out', authenticateToken, requirePermission('stock_out'), checkWorkingHours, recordStockOut);

// Audited Correction: Accountant or Director
router.post('/correction', authenticateToken, requireRole(['director', 'accountant']), recordCorrection);

// Director Emergency Override Toggle
router.post('/override', authenticateToken, requireRole(['director']), toggleEmergencyOverride);

export default router;
