/**
 * ==============================================================================
 * INSTITUT BAPTISTE DE BUBERUKA (IBB) - RWANDA
 * Production SMTP Email Dispatcher Service (Nodemailer + Gmail SMTP)
 * ==============================================================================
 */
import nodemailer from 'nodemailer';
import { query } from '../config/database.js';

/**
 * Validates if genuine SMTP credentials are provided in environment
 */
export const isSmtpConfigured = () => {
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!user || !pass) return false;
  if (
    user === 'your_gmail_address' ||
    user === 'your_gmail_address@gmail.com' ||
    user === 'admissions@ibb.ac.rw' && pass === 'demo_pass' ||
    pass === 'your_gmail_app_password' ||
    pass === 'demo_pass' ||
    pass === 'app_password_here'
  ) {
    return false;
  }
  return true;
};

/**
 * Creates a Nodemailer transport instance using environment variables
 */
const getTransporter = () => {
  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const port = Number(process.env.SMTP_PORT) || 587;
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass
    },
    // Reasonable timeouts for production
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 15000
  });
};

/**
 * Professional IBB Branded HTML Template for Login OTP Verification
 */
export const buildLoginOtpEmail = (otp, recipientName = 'Staff Member') => {
  const subject = 'IBB — Your Login Verification Code';
  const plainText = `INSTITUT BAPTISTE DE BUBERUKA
Login Verification

Hello,

A login attempt was made to your IBB School Management System account.

Your verification code is:

${otp}

This code:
- Expires in 5 minutes.
- Can only be used once.
- Must never be shared with anyone.

If you did not request this login, please contact the system administrator.

INSTITUT BAPTISTE DE BUBERUKA (IBB)`;

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IBB Login Verification</title>
</head>
<body style="margin: 0; padding: 0; background-color: #071A33; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #071A33; padding: 40px 15px;">
    <tr>
      <td align="center">
        <!-- Container Card -->
        <table role="presentation" width="100%" style="max-width: 560px; background-color: #ffffff; border-radius: 18px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.35);" cellspacing="0" cellpadding="0">
          
          <!-- Header Banner -->
          <tr>
            <td style="background: linear-gradient(135deg, #071A33 0%, #0B2548 60%, #059669 100%); padding: 32px 30px; text-align: center;">
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="center">
                    <div style="display: inline-block; width: 48px; height: 48px; background-color: rgba(255,255,255,0.12); border-radius: 12px; line-height: 48px; text-align: center; margin-bottom: 12px;">
                      <span style="font-size: 24px; color: #ffffff;">🎓</span>
                    </div>
                    <h1 style="margin: 0; font-size: 19px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px; text-transform: uppercase;">
                      INSTITUT BAPTISTE DE BUBERUKA
                    </h1>
                    <p style="margin: 4px 0 0; font-size: 12px; color: #a7f3d0; font-weight: 600; letter-spacing: 1.5px; text-transform: uppercase;">
                      School Management System • Rwanda
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Body Content -->
          <tr>
            <td style="padding: 36px 32px 28px;">
              <h2 style="margin: 0 0 14px; font-size: 18px; font-weight: 700; color: #0f172a;">
                Login Verification
              </h2>
              <p style="margin: 0 0 18px; font-size: 14px; line-height: 1.6; color: #334155;">
                Hello <strong>${recipientName}</strong>,
              </p>
              <p style="margin: 0 0 24px; font-size: 14px; line-height: 1.6; color: #334155;">
                A login attempt was made to your IBB School Management System account. Enter the verification code below to complete sign in:
              </p>

              <!-- OTP Code Display Box -->
              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-bottom: 24px;">
                <tr>
                  <td align="center" style="background: #f8fafc; border: 2px dashed #059669; border-radius: 14px; padding: 22px 16px;">
                    <span style="display: block; font-size: 11px; text-transform: uppercase; font-weight: 700; color: #059669; letter-spacing: 1.5px; margin-bottom: 6px;">
                      Your One-Time Passcode
                    </span>
                    <span style="display: block; font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 800; letter-spacing: 10px; color: #071A33; line-height: 1.2;">
                      ${otp}
                    </span>
                  </td>
                </tr>
              </table>

              <!-- Security Information List -->
              <div style="background-color: #f1f5f9; border-left: 4px solid #059669; border-radius: 8px; padding: 14px 16px; margin-bottom: 24px;">
                <p style="margin: 0 0 6px; font-size: 12px; font-weight: 700; color: #0f172a;">
                  Security Requirements:
                </p>
                <ul style="margin: 0; padding-left: 18px; font-size: 12px; line-height: 1.6; color: #475569;">
                  <li>Expires in <strong>5 minutes</strong>.</li>
                  <li>Can only be used once.</li>
                  <li>Must never be shared with anyone.</li>
                </ul>
              </div>

              <p style="margin: 0; font-size: 12px; line-height: 1.6; color: #64748b;">
                If you did not request this login, please contact the system administrator immediately to protect your account.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f8fafc; border-top: 1px solid #e2e8f0; padding: 20px 32px; text-align: center;">
              <p style="margin: 0; font-size: 11px; color: #94a3b8; font-weight: 500;">
                INSTITUT BAPTISTE DE BUBERUKA (IBB) • Burera, Northern Province, Rwanda
              </p>
              <p style="margin: 4px 0 0; font-size: 10px; color: #cbd5e1;">
                Automated security notification • Please do not reply directly to this email
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  return { subject, plainText, html };
};

/**
 * Professional IBB Branded HTML Template for Password Change Verification
 */
export const buildPasswordChangeOtpEmail = (otp, recipientName = 'Staff Member') => {
  const subject = 'IBB — Password Change Verification Code';
  const plainText = `INSTITUT BAPTISTE DE BUBERUKA
Password Change Verification

Hello,

A password change was requested for your IBB School Management System account.

Your verification code is:

${otp}

This code:
- Expires in 5 minutes.
- Can only be used once.
- Must never be shared with anyone.

If you did not request this password change, please contact the system administrator immediately.

INSTITUT BAPTISTE DE BUBERUKA (IBB)`;

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IBB Password Change Verification</title>
</head>
<body style="margin: 0; padding: 0; background-color: #071A33; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #071A33; padding: 40px 15px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" style="max-width: 560px; background-color: #ffffff; border-radius: 18px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.35);" cellspacing="0" cellpadding="0">
          <tr>
            <td style="background: linear-gradient(135deg, #071A33 0%, #1e293b 60%, #d97706 100%); padding: 30px; text-align: center;">
              <h1 style="margin: 0; font-size: 19px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px; text-transform: uppercase;">
                INSTITUT BAPTISTE DE BUBERUKA
              </h1>
              <p style="margin: 4px 0 0; font-size: 12px; color: #fde68a; font-weight: 600; letter-spacing: 1.5px; text-transform: uppercase;">
                Account Security Notice
              </p>
            </td>
          </tr>
          <tr>
            <td style="padding: 34px 30px 26px;">
              <h2 style="margin: 0 0 14px; font-size: 18px; font-weight: 700; color: #0f172a;">
                Password Change Verification
              </h2>
              <p style="margin: 0 0 16px; font-size: 14px; line-height: 1.6; color: #334155;">
                Hello <strong>${recipientName}</strong>,
              </p>
              <p style="margin: 0 0 22px; font-size: 14px; line-height: 1.6; color: #334155;">
                A request was submitted to update the password for your account. Enter the verification code below:
              </p>

              <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-bottom: 22px;">
                <tr>
                  <td align="center" style="background: #fffbeb; border: 2px dashed #d97706; border-radius: 14px; padding: 20px 16px;">
                    <span style="display: block; font-size: 11px; text-transform: uppercase; font-weight: 700; color: #d97706; letter-spacing: 1.5px; margin-bottom: 6px;">
                      Verification Passcode
                    </span>
                    <span style="display: block; font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 800; letter-spacing: 10px; color: #071A33; line-height: 1.2;">
                      ${otp}
                    </span>
                  </td>
                </tr>
              </table>

              <div style="background-color: #f8fafc; border-left: 4px solid #d97706; border-radius: 8px; padding: 12px 16px; margin-bottom: 22px;">
                <ul style="margin: 0; padding-left: 18px; font-size: 12px; line-height: 1.6; color: #475569;">
                  <li>Expires in <strong>5 minutes</strong>.</li>
                  <li>Can only be used once.</li>
                  <li>Never share this code with anyone.</li>
                </ul>
              </div>

              <p style="margin: 0; font-size: 12px; line-height: 1.6; color: #dc2626; font-weight: 600;">
                If you did not request this change, do NOT enter this code and contact the School Director immediately.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background-color: #f8fafc; border-top: 1px solid #e2e8f0; padding: 18px 30px; text-align: center;">
              <p style="margin: 0; font-size: 11px; color: #94a3b8;">
                INSTITUT BAPTISTE DE BUBERUKA (IBB) • Burera, Rwanda
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

  return { subject, plainText, html };
};

/**
 * Sends an email using Nodemailer and records delivery in database
 */
export const sendEmail = async ({ to, subject, html, text }) => {
  if (!to) {
    return { success: false, error: 'Recipient email address is required.' };
  }

  // Check if SMTP is configured
  if (!isSmtpConfigured()) {
    console.warn(`⚠️ [SMTP SERVICE] Cannot send email to ${to}: SMTP credentials not configured.`);
    return {
      success: false,
      error: 'SMTP credentials missing. Please set SMTP_USER and SMTP_PASS (Gmail App Password) in your backend environment to dispatch real emails.',
      code: 'SMTP_CONFIG_REQUIRED'
    };
  }

  const logId = `deliv_mail_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const fromAddress =
    process.env.EMAIL_FROM ||
    `"INSTITUT BAPTISTE DE BUBERUKA" <${process.env.SMTP_USER}>`;

  try {
    const transporter = getTransporter();
    console.log(`✉️ [SMTP SERVICE] Dispatching email to ${to} via ${process.env.SMTP_HOST || 'smtp.gmail.com'}`);

    const info = await transporter.sendMail({
      from: fromAddress,
      to,
      subject,
      text,
      html
    });

    console.log(`✅ [SMTP SERVICE] Email successfully delivered to ${to}. MessageId: ${info.messageId}`);

    // Persist to audit log table
    try {
      await query(
        `INSERT INTO notification_delivery_logs (id, channel, recipient, subject, content, status, provider_response, timestamp)
         VALUES (?, 'email', ?, ?, ?, 'delivered', ?, NOW())`,
        [logId, to, subject, text ? text.slice(0, 500) : subject, `SMTP_250_OK_${info.messageId}`]
      );
    } catch (dbErr) {
      // Non-fatal if DB is in fallback
    }

    return {
      success: true,
      messageId: info.messageId,
      status: 'delivered'
    };
  } catch (error) {
    console.error(`❌ [SMTP SERVICE ERROR] Failed to send email to ${to}:`, error.message);

    try {
      await query(
        `INSERT INTO notification_delivery_logs (id, channel, recipient, subject, content, status, provider_response, timestamp)
         VALUES (?, 'email', ?, ?, ?, 'failed', ?, NOW())`,
        [logId, to, subject, text ? text.slice(0, 500) : subject, error.message.slice(0, 255)]
      );
    } catch (dbErr) {}

    return {
      success: false,
      error: `Email delivery failed: ${error.message}. Please check your Gmail App Password and network connection.`
    };
  }
};

export default {
  sendEmail,
  isSmtpConfigured,
  buildLoginOtpEmail,
  buildPasswordChangeOtpEmail
};
