/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { t, language } = useLanguage();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deliveredRecipients, setDeliveredRecipients] = useState<{ role: string; email: string; name: string }[]>([]);
  const [submitError, setSubmitError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const result = StorageService.submitContactInquiry({
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim()
      });

      if (result.success) {
        setDeliveredRecipients(result.deliveredTo);
        setSent(true);
      } else {
        setSubmitError(result.error || 'Failed to dispatch message to administration leaders.');
      }
    } catch (err: any) {
      setSubmitError(err.message || 'An unexpected error occurred during dispatch.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-12 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            {language === 'rw' ? 'Twandikire cyangwa Udusure' : 'Institutional Inquiries'}
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-2 mb-4 text-slate-900 dark:text-white">
            {t('navContact')}
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300">
            {language === 'rw'
              ? 'Turi hano kugira ngo dusubize ibibazo byawe byerekeye kwiga muri Karenge Adventist Secondary School, amashami yacu, n’ibindi bisobanuro wifuza.'
              : 'Our administrative and admissions offices are open Monday through Friday. Reach out for student admissions, partnerships, and academic consultations.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Contact Cards (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Physical Campus Location
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  KARENGE ADVENTIST SECONDARY SCHOOL<br />
                  Karenge, Rwanda
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Direct Phone Lines
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Admissions Office: +250 788 412 890<br />
                  Finance &amp; Accounting: +250 788 563 219<br />
                  Director’s Office: +250 788 901 345
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Official Email Desks
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Admissions: admissions@kass.ac.rw<br />
                  Director: director@kass.ac.rw<br />
                  General: info@kass.ac.rw
                </p>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-1">
                  Working Hours (CAT)
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Monday – Friday: 07:30 AM – 05:30 PM<br />
                  Sunday – Friday: Academic &amp; Boarding Services<br />
                  Saturday: Sabbath Worship Observance
                </p>
              </div>
            </div>
          </div>

          {/* Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                Send an Official Message
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mb-6">
                Fill in your details and our administration will respond within 24 hours.
              </p>

              {submitError && (
                <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              {sent ? (
                <div className="p-6 sm:p-8 text-center bg-white dark:bg-slate-800 rounded-xl border border-emerald-200 dark:border-emerald-800 shadow-md">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h4 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-1.5">
                    Message Dispatched Successfully
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mb-5 leading-relaxed max-w-md mx-auto">
                    Thank you, <strong className="text-slate-900 dark:text-white">{name}</strong>. Your inquiry has been routed directly to the three school administration leaders.
                  </p>

                  {/* Verified Delivery Badges to the Three Leaders */}
                  <div className="text-left bg-slate-50 dark:bg-slate-900/80 rounded-xl p-4 border border-slate-200 dark:border-slate-700 mb-5 text-xs space-y-2.5">
                    <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white text-xs border-b border-slate-200 dark:border-slate-800 pb-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Verified Recipient Routing (3 Leadership Desks)</span>
                    </div>

                    <div className="space-y-1.5 pt-1 text-[11px]">
                      <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                        <span className="font-semibold">1. School Director:</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-mono">Delivered (tzrdidier@gmail.com)</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                        <span className="font-semibold">2. School Accountant:</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-mono">Delivered (accountant@kass.ac.rw)</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                        <span className="font-semibold">3. School Animator:</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-mono">Delivered (animator@kass.ac.rw)</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSent(false);
                      setName('');
                      setEmail('');
                      setSubject('');
                      setMessage('');
                      setSubmitError('');
                    }}
                    className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] transition-all cursor-pointer min-h-[40px]"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Jean Damascene"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="e.g. Admission Inquiry for Academic Year 2026/2027"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Message *
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Write your inquiry here..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 active:scale-[0.98] shadow-md shadow-emerald-600/30 transition-all min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:ring-offset-2 cursor-pointer disabled:opacity-70"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSubmitting ? t('sendingMessageBtn') : t('sendMessageBtn')}</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
