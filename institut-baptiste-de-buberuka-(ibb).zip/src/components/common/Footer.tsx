/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { GraduationCap, MapPin, Phone, Mail, Award, CheckCircle2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Col 1: Identity & Accreditation */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] flex items-center justify-center text-white shadow-md">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">
                KARENGE <span className="text-emerald-400">ADVENTIST</span>
              </span>
            </div>
            <p className="text-xs leading-relaxed text-slate-400">
              {t('footerAbout')}
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
              <Award className="w-4 h-4 shrink-0" />
              <span>Accredited by Rwanda TVET Board (RTB)</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-white mb-4">
              {t('footerQuickLinks')}
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <Link to="/" className="hover:text-white transition-colors">
                  {t('navHome')}
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  {t('navAbout')}
                </Link>
              </li>
              <li>
                <Link to="/admissions" className="hover:text-white transition-colors">
                  {t('navAdmissions')}
                </Link>
              </li>
              <li>
                <Link to="/apply" className="hover:text-white transition-colors text-emerald-400 font-semibold">
                  {t('navApplyNow')}
                </Link>
              </li>
              <li>
                <Link to="/track" className="hover:text-white transition-colors">
                  {t('navTrackApp')}
                </Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-white transition-colors">
                  {t('navStaffLogin')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Programs Offered */}
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-white mb-4">
              {t('footerPrograms')}
            </h4>
            <ul className="space-y-3 text-xs text-slate-400">
              <li className="flex flex-col gap-1">
                <span className="text-white font-medium">Software Development (L3 – L5)</span>
                <span className="text-slate-500">Web, Mobile Apps & Data Systems</span>
              </li>
              <li className="flex flex-col gap-1">
                <span className="text-white font-medium">Automobile Technology (L3 – L5)</span>
                <span className="text-slate-500">Electronic Diagnostics & Engine Overhaul</span>
              </li>
              <li className="flex items-center gap-1.5 text-emerald-400 font-medium pt-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>3-Year RTB Certificate of Competency</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & Location */}
          <div>
            <h4 className="text-xs uppercase font-bold tracking-wider text-white mb-4">
              {t('footerContact')}
            </h4>
            <div className="space-y-3 text-xs text-slate-400">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Karenge, Rwanda</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>+250 788 412 890 / +250 788 563 219</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>admissions@kass.ac.rw / info@kass.ac.rw</span>
              </div>
              <div className="pt-2 text-slate-500 text-[11px]">
                Monday – Friday: 07:30 AM – 05:30 PM (CAT)
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} {t('footerRights')}
          </div>
          <div className="flex items-center gap-6">
            <span>MINEDUC / RTB Certified</span>
            <span>·</span>
            <span>Bilingual (EN / RW)</span>
            <span>·</span>
            <Link to="/login" className="hover:text-emerald-400 transition-colors">
              Staff Portal (2FA Protected)
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
