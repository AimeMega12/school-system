/**
 * Automated Food Stock Working Hours Enforcement Middleware
 * Window 1: 06:00 - 08:00 (Breakfast preparation)
 * Window 2: 17:00 - 19:00 (Dinner preparation)
 * Timezone: Africa/Kigali (CAT / UTC+2)
 */
import { query } from '../config/database.js';

export const checkWorkingHours = async (req, res, next) => {
  // Director can always override
  if (req.user && req.user.role === 'director') {
    return next();
  }

  // Check emergency override flag in DB
  try {
    const schedules = await query(`SELECT emergency_override_active, morning_start, morning_end, evening_start, evening_end FROM stock_schedules LIMIT 1`);
    if (schedules && schedules.length > 0 && schedules[0].emergency_override_active) {
      console.log('⚡ [Stock Policy] Emergency schedule override active. Allowing operation.');
      return next();
    }
  } catch (err) {
    // Proceed to time check
  }

  // Calculate Rwanda Time (Africa/Kigali = UTC+2)
  const now = new Date();
  const utcHours = now.getUTCHours();
  const utcMinutes = now.getUTCMinutes();
  const rwandaHours = (utcHours + 2) % 24;
  const currentMinutes = rwandaHours * 60 + utcMinutes;

  const morningStart = 6 * 60;      // 06:00
  const morningEnd = 8 * 60;        // 08:00
  const eveningStart = 17 * 60;     // 17:00
  const eveningEnd = 19 * 60;       // 19:00

  const isMorningWindow = currentMinutes >= morningStart && currentMinutes <= morningEnd;
  const isEveningWindow = currentMinutes >= eveningStart && currentMinutes <= eveningEnd;

  if (isMorningWindow || isEveningWindow) {
    return next();
  }

  // In demo development mode, allow simulation with header or warning:
  if (req.headers['x-bypass-schedule'] === 'true' || process.env.NODE_ENV === 'development') {
    console.log('ℹ️ [Stock Hours] Development mode bypass active.');
    return next();
  }

  return res.status(403).json({
    success: false,
    message: `STORAGE CLOSED: Food stock distribution is restricted to 06:00-08:00 and 17:00-19:00 Rwanda Time. Contact the Director for an Emergency Override.`
  });
};

export default { checkWorkingHours };
