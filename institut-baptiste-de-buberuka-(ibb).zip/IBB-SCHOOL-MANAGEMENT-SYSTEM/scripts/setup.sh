#!/usr/bin/env bash
# ==============================================================================
# INSTITUT BAPTISTE DE BUBERUKA (IBB) - Automated Setup Script
# ==============================================================================

echo "🚀 Setting up IBB School Management System..."

# 1. Install Backend Dependencies
echo "📦 Installing backend dependencies..."
cd backend && npm install
cd ..

# 2. Install Frontend Dependencies
echo "📦 Installing frontend dependencies..."
cd frontend && npm install
cd ..

echo "✅ All dependencies installed successfully!"
echo "👉 Run './scripts/start.sh' to launch both backend and frontend servers."
