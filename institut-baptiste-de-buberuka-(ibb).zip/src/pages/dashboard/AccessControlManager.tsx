/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { User, PermissionModule } from '../../types/index.ts';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Save,
  Lock,
  UserCheck,
  Check,
  X,
  Info
} from 'lucide-react';

interface PermissionDefinition {
  key: PermissionModule;
  nameEn: string;
  nameRw: string;
  category: 'Stock & Inventory' | 'Suppliers & Vendors' | 'Reports & Finance' | 'Admissions';
  descEn: string;
  descRw: string;
}

const ALL_PERMISSIONS: PermissionDefinition[] = [
  {
    key: 'stock_view',
    nameEn: 'View Available Stock',
    nameRw: 'Kureba Ibiribwa Bihari',
    category: 'Stock & Inventory',
    descEn: 'Inspect current warehouse staple balances and alert thresholds.',
    descRw: 'Kureba ingano y’ibiribwa biri mu bubiko n’integuza.'
  },
  {
    key: 'stock_in',
    nameEn: 'Perform Stock In (Incoming Shipments)',
    nameRw: 'Kwandika Ibiribwa Byinjiye',
    category: 'Stock & Inventory',
    descEn: 'Register incoming food deliveries, purchase quantities, and costs.',
    descRw: 'Kwandika ibiribwa bishya byageze mu kigo n’ibiciro byabyo.'
  },
  {
    key: 'stock_out',
    nameEn: 'Perform Stock Out (Meal Distribution)',
    nameRw: 'Kwandika Ibisohotse (Kugaburira)',
    category: 'Stock & Inventory',
    descEn: 'Record scheduled daily commodity withdrawals for dining hall meals.',
    descRw: 'Gusohora ibiribwa byo gutekera abanyeshuri ku masaha yabigenewe.'
  },
  {
    key: 'stock_correction',
    nameEn: 'Perform Stock Inventory Correction',
    nameRw: 'Gukosora Ingano y\'Ibiribwa',
    category: 'Stock & Inventory',
    descEn: 'Audit and record reconciliation adjustments with mandatory explanation.',
    descRw: 'Gukosora amakosa mu mibare y\'ibiribwa no gutanga ibisobanuro.'
  },
  {
    key: 'suppliers',
    nameEn: 'Manage Suppliers & Vendor Directory',
    nameRw: 'Gucunga Abagemura Ibiribwa',
    category: 'Suppliers & Vendors',
    descEn: 'Add, edit, and evaluate registered food suppliers and TIN numbers.',
    descRw: 'Kwandika no gusuzuma abagemura ibiribwa n’amakuru ya TIN.'
  },
  {
    key: 'reports_financial',
    nameEn: 'Access Financial & Valuation Reports',
    nameRw: 'Kureba Raporo z’Umutungo n’Amafaranga',
    category: 'Reports & Finance',
    descEn: 'Inspect expenditure reports, stock monetary valuation, and supplier payments.',
    descRw: 'Kureba raporo z’amafaranga yasohotse n’agaciro k’ububiko.'
  },
  {
    key: 'reports_stock',
    nameEn: 'Export Stock & Consumption Reports',
    nameRw: 'Gukuramo Raporo z\'Ububiko',
    category: 'Reports & Finance',
    descEn: 'Export daily consumption, stock in/out ledgers to Excel and PDF.',
    descRw: 'Gukuramo raporo z’ibisohoka buri munsi mu buryo bwa Excel na PDF.'
  },
  {
    key: 'admissions_view',
    nameEn: 'View Applicant Records',
    nameRw: 'Kureba Abasabye Kwiga',
    category: 'Admissions',
    descEn: 'Inspect student applications and academic score breakdowns.',
    descRw: 'Kureba dosiye z’abasabye kwiga n’amanota bagize.'
  }
];

export const AccessControlManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user: currentUser } = useAuth();
  const { addNotification } = useNotifications();

  const [users, setUsers] = useState<User[]>(() => StorageService.getUsers());
  const [selectedUserId, setSelectedUserId] = useState<string>('user_accountant_01');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Exclude director from editable list (Director always has super-admin full permissions)
  const staffUsers = users.filter((u) => u.role !== 'director');
  const selectedUser = users.find((u) => u.id === selectedUserId) || staffUsers[0];

  const togglePermission = (permKey: PermissionModule) => {
    if (!selectedUser) return;

    const currentPerms = selectedUser.permissions || [];
    const hasPerm = currentPerms.includes(permKey);

    const updatedPerms = hasPerm
      ? currentPerms.filter((p) => p !== permKey)
      : [...currentPerms, permKey];

    const updatedUser: User = {
      ...selectedUser,
      permissions: updatedPerms
    };

    const updatedUsers = users.map((u) => (u.id === updatedUser.id ? updatedUser : u));
    setUsers(updatedUsers);
    StorageService.saveUsers(updatedUsers);

    // Audit log
    StorageService.addAuditLog({
      action: hasPerm ? 'PERMISSION_REVOKED' : 'PERMISSION_GRANTED',
      category: 'permission',
      userId: currentUser?.id || 'dir_01',
      userName: currentUser?.fullName || 'School Director',
      userRole: 'director',
      details: `Director ${hasPerm ? 'revoked' : 'granted'} permission '${permKey}' for ${selectedUser.fullName} (${selectedUser.role.toUpperCase()})`,
      ipAddress: '197.243.34.82'
    });

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const toggleUserStatus = () => {
    if (!selectedUser) return;

    const newStatus = selectedUser.status === 'active' ? 'inactive' : 'active';
    const updatedUser: User = {
      ...selectedUser,
      status: newStatus
    };

    const updatedUsers = users.map((u) => (u.id === updatedUser.id ? updatedUser : u));
    setUsers(updatedUsers);
    StorageService.saveUsers(updatedUsers);

    StorageService.addAuditLog({
      action: newStatus === 'active' ? 'USER_ACTIVATED' : 'USER_DEACTIVATED',
      category: 'permission',
      userId: currentUser?.id || 'dir_01',
      userName: currentUser?.fullName || 'School Director',
      userRole: 'director',
      details: `Director changed status for ${selectedUser.fullName} to ${newStatus.toUpperCase()}`,
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: `Account Status Changed: ${selectedUser.fullName}`,
      titleRw: `Imiterere ya Konti Yahinduwe: ${selectedUser.fullName}`,
      message: `User account is now ${newStatus.toUpperCase()}.`,
      messageRw: `Konti yumukozi ubu irakora: ${newStatus.toUpperCase()}.`,
      type: newStatus === 'active' ? 'success' : 'warning',
      category: 'permission',
      targetRoles: ['director']
    });
  };

  if (currentUser?.role !== 'director') {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-900">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Director Authorization Required</h3>
        <p className="text-xs text-slate-500">Only the School Director possesses the constitutional authority to configure staff access permissions.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <DashboardPageHeader
        title={t('accessControlTitle')}
        subtitle={t('accessControlSub')}
        badge={
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-400/20">
            Granular Role-Based Access Control (RBAC)
          </span>
        }
        variant="purple"
      >
        <div className="flex items-center gap-2">
          <span className="px-3.5 py-1.5 rounded-xl bg-white/90 dark:bg-slate-900/90 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Super Admin: Full Authority</span>
          </span>
        </div>
      </DashboardPageHeader>

      {saveSuccess && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-semibold">
            {t('permissionEnforcedNotice')}
          </span>
        </div>
      )}

      {/* Staff User Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {staffUsers.map((u) => {
          const isSelected = u.id === selectedUser?.id;
          return (
            <div
              key={u.id}
              onClick={() => setSelectedUserId(u.id)}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between ${
                isSelected
                  ? 'border-emerald-600 bg-white dark:bg-slate-900 shadow-md'
                  : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <img
                  src={u.avatarUrl}
                  alt={u.fullName}
                  className="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700"
                />
                <div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {u.fullName}
                  </h4>
                  <p className="text-xs text-slate-500 font-mono">
                    Role: {u.role.toUpperCase()} · @{u.username}
                  </p>
                  <span className={`inline-block mt-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                    u.status === 'active'
                      ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                      : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                  }`}>
                    {u.status}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 block tabular-nums">
                  {u.permissions?.length || 0} / {ALL_PERMISSIONS.length}
                </span>
                <span className="text-[11px] text-slate-400">Permissions Active</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Permission Matrix */}
      {selectedUser && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Configuring Granular Authorizations for {selectedUser.fullName}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Toggle individual permissions on or off. Changes are enforced instantly across active sessions.
              </p>
            </div>

            <button
              type="button"
              onClick={toggleUserStatus}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors ${
                selectedUser.status === 'active'
                  ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border border-rose-200 dark:border-rose-800 hover:bg-rose-100'
                  : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-sm'
              }`}
            >
              {selectedUser.status === 'active' ? 'Deactivate Account' : 'Reactivate Account'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ALL_PERMISSIONS.map((perm) => {
              const hasPermission = (selectedUser.permissions || []).includes(perm.key);
              return (
                <div
                  key={perm.key}
                  className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                    hasPermission
                      ? 'bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 opacity-75'
                  }`}
                >
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      {perm.category}
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      {language === 'rw' ? perm.nameRw : perm.nameEn}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                      {language === 'rw' ? perm.descRw : perm.descEn}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => togglePermission(perm.key)}
                    className={`shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                      hasPermission
                        ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/30'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-500 hover:bg-slate-300'
                    }`}
                  >
                    {hasPermission ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  </button>
                </div>
              );
            })}
          </div>

          <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 text-xs text-blue-900 dark:text-blue-300 flex items-start gap-2.5">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-600" />
            <p className="leading-relaxed">
              <strong>Architectural Note:</strong> The School Director has sovereign super-admin permissions across all operational modules. The Accountant and Animator can access only the specific routes and actions enabled in this matrix.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
