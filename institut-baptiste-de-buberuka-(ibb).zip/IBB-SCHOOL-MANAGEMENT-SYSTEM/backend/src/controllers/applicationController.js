/**
 * Student Admissions Controller (L3, L4, L5)
 */
import { query } from '../config/database.js';
import { logActivity } from '../services/auditService.js';
import { sendSMS } from '../services/smsService.js';

// Seed initial applications
const inMemoryApplications = [
  {
    id: 'app_01',
    trackingNumber: 'IBB-2026-04192',
    fullName: 'Mugisha Jean Paul',
    fatherName: 'Hategekimana Pierre',
    motherName: 'Mukamugema Marie',
    dateOfBirth: '2008-05-12',
    gender: 'male',
    phone: '+250 788 123 456',
    email: 'mugisha.jp@gmail.com',
    residentialAddress: 'Burera, Buberuka, Kagogo',
    district: 'Burera',
    sector: 'Buberuka',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Buberuka Catholique',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 74.5,
    s3AggregateScore: 18,
    resultSlipFileName: 's3_slip_mugisha.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'passport_mugisha.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
    status: 'eligible',
    submittedAt: '2026-10-30T10:00:00Z',
    academicYear: '2026/2027'
  },
  {
    id: 'app_02',
    trackingNumber: 'IBB-2026-08341',
    fullName: 'Nkurunziza Eric',
    fatherName: 'Habimana Gaspard',
    motherName: 'Mukeshimana Consolee',
    dateOfBirth: '2007-11-20',
    gender: 'male',
    phone: '+250 788 776 543',
    email: 'nkurunziza.e@yahoo.fr',
    residentialAddress: 'Gicumbi, Byumba',
    district: 'Gicumbi',
    sector: 'Byumba',
    applyingLevel: 'L4',
    department: 'automobile_technology',
    previousSchool: 'TSS Byumba',
    previousAcademicLevel: 'Level 3 TVET',
    academicScorePercentage: 68.0,
    s3AggregateScore: 22,
    resultSlipFileName: 'l3_transcripts_eric.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'passport_eric.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300',
    status: 'under_review',
    submittedAt: '2026-10-28T09:15:00Z',
    academicYear: '2026/2027'
  },
  {
    id: 'app_03',
    trackingNumber: 'IBB-2026-01928',
    fullName: 'Uwase Claudine',
    fatherName: 'Bizimana Alphonse',
    motherName: 'Mukamazimpaka Jeanne',
    dateOfBirth: '2009-02-14',
    gender: 'female',
    phone: '+250 788 456 789',
    email: 'uwase.claudine@outlook.com',
    residentialAddress: 'Musanze, Muhoza',
    district: 'Musanze',
    sector: 'Muhoza',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Muhoza I',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 86.0,
    s3AggregateScore: 14,
    resultSlipFileName: 's3_slip_uwase.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'passport_uwase.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300',
    status: 'approved',
    submittedAt: '2026-10-25T11:00:00Z',
    reviewedAt: '2026-10-27T16:00:00Z',
    reviewedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    academicYear: '2026/2027'
  },
  {
    id: 'app_04',
    trackingNumber: 'IBB-2026-05612',
    fullName: 'Manzi Kevin',
    fatherName: 'Karekezi Vincent',
    motherName: 'Ingabire Beata',
    dateOfBirth: '2008-08-05',
    gender: 'male',
    phone: '+250 788 332 119',
    email: 'kevin.manzi@gmail.com',
    residentialAddress: 'Burera, Rugarama',
    district: 'Burera',
    sector: 'Rugarama',
    applyingLevel: 'L5',
    department: 'automobile_technology',
    previousSchool: 'IPRC Musanze Technical',
    previousAcademicLevel: 'Level 4 TVET',
    academicScorePercentage: 82.5,
    s3AggregateScore: 25,
    resultSlipFileName: 'manzi_l4_cert.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'manzi_photo.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300',
    status: 'approved',
    submittedAt: '2026-10-24T08:30:00Z',
    reviewedAt: '2026-10-26T15:20:00Z',
    reviewedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    academicYear: '2026/2027'
  },
  {
    id: 'app_05',
    trackingNumber: 'IBB-2026-09102',
    fullName: 'Kagabo Thierry',
    fatherName: 'Rutayisire Emmanuel',
    motherName: 'Mukashyaka Odette',
    dateOfBirth: '2009-06-18',
    gender: 'male',
    phone: '+250 788 661 229',
    email: 'kagabo.t@gmail.com',
    residentialAddress: 'Burera, Cyanika',
    district: 'Burera',
    sector: 'Cyanika',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Cyanika',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 42.0,
    s3AggregateScore: 48,
    resultSlipFileName: 'kagabo_s3.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'kagabo.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300',
    status: 'automatically_rejected',
    autoRejectionReason: 'Academic score (42.0%) is below the configured school minimum admission threshold of 50.0%.',
    submittedAt: '2026-10-29T10:00:00Z',
    academicYear: '2026/2027'
  }
];

export const submitApplication = async (req, res) => {
  const data = req.body;
  const randomSuffix = Math.floor(10000 + Math.random() * 90000).toString();
  const trackingNumber = `IBB-2026-${randomSuffix}`;

  const score = Number(data.academicScorePercentage) || 60.0;
  const minRequiredThreshold = 50.0;

  let initialStatus = 'eligible';
  let rejectionReason = null;

  if (score < minRequiredThreshold) {
    initialStatus = 'automatically_rejected';
    rejectionReason = `Academic score (${score}%) is below the minimum admission threshold of ${minRequiredThreshold}%.`;

    await sendSMS({
      to: data.phone,
      subject: 'IBB Admission Application Status',
      message: `IBB Rwanda: Dear ${data.fullName}, your score of ${score}% does not satisfy the active minimum threshold (${minRequiredThreshold}%). Application preserved in archive.`
    });
  } else {
    await sendSMS({
      to: data.phone,
      subject: 'IBB Application Received',
      message: `IBB Rwanda: Application (${trackingNumber}) received. Score ${score}% qualifies for Director review.`
    });
  }

  const newApp = {
    id: `app_${Date.now()}`,
    trackingNumber,
    fullName: data.fullName,
    fatherName: data.fatherName,
    motherName: data.motherName,
    dateOfBirth: data.dateOfBirth,
    gender: data.gender,
    phone: data.phone,
    email: data.email,
    residentialAddress: data.residentialAddress,
    district: data.district,
    sector: data.sector,
    applyingLevel: data.applyingLevel || 'L3',
    department: data.department || 'software_development',
    previousSchool: data.previousSchool,
    previousAcademicLevel: data.previousAcademicLevel || 'Senior 3',
    academicScorePercentage: score,
    s3AggregateScore: Number(data.s3AggregateScore) || 20,
    resultSlipFileName: data.resultSlipFileName || 'result_slip.pdf',
    resultSlipUrl: data.resultSlipUrl || 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: data.passportPhotoFileName || 'passport.jpg',
    passportPhotoUrl: data.passportPhotoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
    status: initialStatus,
    autoRejectionReason: rejectionReason,
    isEligibleForBoarding: score >= 80.0,
    academicYear: '2026/2027',
    submittedAt: new Date().toISOString()
  };

  inMemoryApplications.unshift(newApp);

  await logActivity({
    action: 'ADMISSION_SUBMITTED',
    category: 'admission',
    userId: 'public_portal',
    userName: newApp.fullName,
    userRole: 'animator',
    details: `Online application submitted: ${newApp.fullName} (${trackingNumber}) for ${newApp.applyingLevel}. Status: ${initialStatus}`,
    ipAddress: req.ip
  });

  res.status(201).json({ success: true, application: newApp });
};

export const trackApplication = (req, res) => {
  const queryParam = (req.params.trackingNumber || '').trim().toUpperCase();
  const match = inMemoryApplications.find(
    a => a.trackingNumber.toUpperCase() === queryParam || a.phone.replace(/\s+/g, '') === queryParam.replace(/\s+/g, '')
  );

  if (!match) {
    return res.status(404).json({ success: false, message: 'Application not found with provided tracking identifier.' });
  }

  res.json({ success: true, application: match });
};

export const getApplications = (req, res) => {
  const { level, status, search, department } = req.query;
  let results = [...inMemoryApplications];

  if (level && level !== 'all') {
    results = results.filter(a => a.applyingLevel === level);
  }
  if (status && status !== 'all') {
    results = results.filter(a => a.status === status);
  }
  if (department && department !== 'all') {
    results = results.filter(a => a.department === department);
  }
  if (search) {
    const s = search.toLowerCase();
    results = results.filter(a =>
      a.fullName.toLowerCase().includes(s) ||
      a.trackingNumber.toLowerCase().includes(s) ||
      a.district.toLowerCase().includes(s)
    );
  }

  res.json({ success: true, total: results.length, applications: results });
};

export const approveApplication = async (req, res) => {
  const { id } = req.params;
  const { reviewNotes } = req.body;
  const app = inMemoryApplications.find(a => a.id === id);

  if (!app) return res.status(404).json({ success: false, message: 'Application not found.' });

  app.status = 'approved';
  app.reviewedAt = new Date().toISOString();
  app.reviewedBy = req.user.fullName;
  app.reviewNotes = reviewNotes || 'Admitted under official RTB criteria.';

  await sendSMS({
    to: app.phone,
    subject: 'IBB Admission Approved',
    message: `IBB Rwanda: Congratulations ${app.fullName}! Your admission for ${app.applyingLevel} ${app.department} has been APPROVED.`
  });

  await logActivity({
    action: 'ADMISSION_APPROVED',
    category: 'admission',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Director approved candidate ${app.fullName} (${app.trackingNumber}) for ${app.applyingLevel}`,
    ipAddress: req.ip
  });

  res.json({ success: true, application: app });
};

export const rejectApplication = async (req, res) => {
  const { id } = req.params;
  const { rejectionReason, reviewNotes } = req.body;
  const app = inMemoryApplications.find(a => a.id === id);

  if (!app) return res.status(404).json({ success: false, message: 'Application not found.' });
  if (!rejectionReason) return res.status(400).json({ success: false, message: 'Rejection reason is mandatory.' });

  app.status = 'rejected';
  app.rejectionReason = rejectionReason;
  app.reviewNotes = reviewNotes || '';
  app.reviewedAt = new Date().toISOString();
  app.reviewedBy = req.user.fullName;

  await logActivity({
    action: 'ADMISSION_REJECTED',
    category: 'admission',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Director rejected application ${app.trackingNumber}. Reason: ${rejectionReason}`,
    ipAddress: req.ip
  });

  res.json({ success: true, application: app });
};

export const issueWaiver = async (req, res) => {
  const { id } = req.params;
  const { waiverJustification } = req.body;
  const app = inMemoryApplications.find(a => a.id === id);

  if (!app) return res.status(404).json({ success: false, message: 'Application not found.' });
  if (!waiverJustification) return res.status(400).json({ success: false, message: 'Waiver justification is mandatory.' });

  app.status = 'approved';
  app.reviewNotes = `Director Exceptional Waiver Issued: ${waiverJustification}`;
  app.reviewedAt = new Date().toISOString();
  app.reviewedBy = req.user.fullName;

  await logActivity({
    action: 'ADMISSION_WAIVER_APPROVED',
    category: 'admission',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Director issued exceptional waiver and approved ${app.fullName} (${app.trackingNumber}). Justification: ${waiverJustification}`,
    ipAddress: req.ip
  });

  res.json({ success: true, application: app });
};

export default {
  submitApplication,
  trackApplication,
  getApplications,
  approveApplication,
  rejectApplication,
  issueWaiver
};
