/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { StorageService } from '../../services/storage.ts';
import {
  Users,
  Clock,
  CheckCircle2,
  XCircle,
  Package,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  ArrowRight,
  ShieldAlert,
  Calendar,
  Layers
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';

export const DirectorDashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const [timeFilter, setTimeFilter] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');

  // Load live database information
  const applications = StorageService.getApplications();
  const products = StorageService.getProducts();
  const transactions = StorageService.getTransactions();
  const schedule = StorageService.getSchedule();
  const auditLogs = StorageService.getAuditLogs();

  // Metrics
  const totalApps = applications.length;
  const pendingApps = applications.filter((a) => a.status === 'pending').length;
  const approvedStudents = applications.filter((a) => a.status === 'approved').length;
  const rejectedApps = applications.filter((a) => a.status === 'rejected').length;

  const softDevApps = applications.filter((a) => a.department === 'software_development').length;
  const autoTechApps = applications.filter((a) => a.department === 'automobile_technology').length;

  const totalStockKg = products.reduce((sum, p) => sum + p.currentStock, 0);
  const totalCapacityKg = products.reduce((sum, p) => sum + p.targetCapacity, 0);
  const stockHealthPct = totalCapacityKg > 0 ? Math.round((totalStockKg / totalCapacityKg) * 100) : 0;

  const totalInventoryValRwf = products.reduce(
    (sum, p) => sum + p.currentStock * p.unitCostRwf,
    0
  );

  const lowStockProducts = products.filter((p) => p.currentStock <= p.minThreshold);

  // Recharts Data Sets
  const departmentChartData = [
    { name: 'Software Dev', value: softDevApps, color: '#2563eb' },
    { name: 'Automobile Tech', value: autoTechApps, color: '#059669' }
  ];

  const consumptionTrendData = [
    { day: 'Mon', Rice: 65, Flour: 70, Veg: 20 },
    { day: 'Tue', Rice: 70, Flour: 75, Veg: 25 },
    { day: 'Wed', Rice: 65, Flour: 80, Veg: 18 },
    { day: 'Thu', Rice: 60, Flour: 70, Veg: 22 },
    { day: 'Fri', Rice: 80, Flour: 85, Veg: 30 },
    { day: 'Sat', Rice: 75, Flour: 80, Veg: 25 },
    { day: 'Sun', Rice: 85, Flour: 90, Veg: 35 }
  ];

  const monthlyExpenditureData = [
    { month: 'Jun', expenditure: 3200000, stockInflow: 3800000 },
    { month: 'Jul', expenditure: 2800000, stockInflow: 3100000 },
    { month: 'Aug', expenditure: 4100000, stockInflow: 4500000 },
    { month: 'Sep', expenditure: 5600000, stockInflow: 6200000 },
    { month: 'Oct', expenditure: 4800000, stockInflow: 5100000 }
  ];

  const stockMovementData = [
    { date: '25 Oct', stockIn: 1000, stockOut: 140 },
    { date: '26 Oct', stockIn: 1500, stockOut: 160 },
    { date: '27 Oct', stockIn: 0, stockOut: 155 },
    { date: '28 Oct', stockIn: 0, stockOut: 150 },
    { date: '29 Oct', stockIn: 0, stockOut: 165 },
    { date: '30 Oct', stockIn: 0, stockOut: 148 },
    { date: '31 Oct', stockIn: 0, stockOut: 152 }
  ];

  return (
    <div className="space-y-8">
      
      {/* Title & Timeframe Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('dirDashboardTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('dirDashboardSub')}
          </p>
        </div>

        {/* Time Segmented Control */}
        <div className="inline-flex p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800 self-start sm:self-auto text-xs font-semibold">
          {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setTimeFilter(filter)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-colors ${
                timeFilter === filter
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Emergency Override Banner (if active) */}
      {schedule.emergencyOverrideActive && (
        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <span>Emergency Stock Override is currently ACTIVE.</span>
            <span className="text-xs font-normal opacity-80">Reason: {schedule.overrideReason || 'Administrative dispensation'}</span>
          </div>
          <Link
            to="/dashboard/schedule"
            className="text-xs font-bold underline hover:text-amber-900"
          >
            Manage Schedule
          </Link>
        </div>
      )}

      {/* 4 Primary Executive KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* KPI 1: Admissions */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalApps')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {totalApps}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
              <span className="text-amber-600 dark:text-amber-400 font-semibold">{pendingApps} pending</span>
              <span>·</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{approvedStudents} approved</span>
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/admissions"
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
            >
              <span>Manage Admissions</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 2: Stock Health */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalStockHealth')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Package className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {stockHealthPct}%
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {totalStockKg.toLocaleString()} Kg total inventory on campus
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/stock"
              className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              <span>Inspect Stock</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 3: Valuation */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalInventoryVal')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums truncate">
              {totalInventoryValRwf.toLocaleString()} RWF
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Food reserves asset valuation
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/reports"
              className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              <span>Financial Reports</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 4: Low Stock Warnings */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiLowStockAlerts')}
              </span>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${lowStockProducts.length > 0 ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600' : 'bg-slate-100 text-slate-500'}`}>
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className={`text-2xl sm:text-3xl font-extrabold font-mono tabular-nums ${lowStockProducts.length > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
              {lowStockProducts.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 truncate">
              {lowStockProducts.length > 0
                ? `${lowStockProducts.map((p) => p.nameRw).join(', ')} below threshold`
                : 'All product levels nominal'}
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/stock"
              className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline"
            >
              <span>Reorder Products</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

      </div>

      {/* Row of Charts (2 columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Chart 1: Admissions by Department (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t('chartAdmissionsByDept')}
            </h3>
            <span className="text-xs text-slate-400 font-mono tabular-nums">{totalApps} applicants</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={departmentChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {departmentChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val ?? 0} Candidates`, 'Applications']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-center gap-6 text-xs font-semibold pt-2">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-600" />
              <span>Software Dev ({softDevApps})</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-600" />
              <span>Automobile Tech ({autoTechApps})</span>
            </div>
          </div>
        </div>

        {/* Chart 2: 7-Day Food Consumption (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t('chartStockConsumption')}
            </h3>
            <span className="text-xs text-slate-400">Boarding Hall Cafeteria</span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={consumptionTrendData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff'
                  }}
                />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="Rice" fill="#059669" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Flour" fill="#2563eb" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Veg" fill="#d97706" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Row 2 Charts: Monthly Expenditure & Inflow */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              {t('chartInventoryValue')}
            </h3>
            <p className="text-xs text-slate-500">Commodity purchase costs vs food consumed (RWF)</p>
          </div>
          <span className="text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400">
            MINEDUC / RTB Subsidies Audited
          </span>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyExpenditureData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis
                tick={{ fontSize: 11 }}
                tickFormatter={(val) => `${(val / 1000000).toFixed(1)}M`}
              />
              <Tooltip
                formatter={(val: any) => [`${Number(val || 0).toLocaleString()} RWF`, '']}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  border: '1px solid #334155',
                  borderRadius: '8px',
                  fontSize: '12px',
                  color: '#fff'
                }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area
                type="monotone"
                dataKey="stockInflow"
                name="Stock Inflow Value"
                stroke="#059669"
                fill="#059669"
                fillOpacity={0.2}
              />
              <Area
                type="monotone"
                dataKey="expenditure"
                name="Consumption Expenditure"
                stroke="#2563eb"
                fill="#2563eb"
                fillOpacity={0.1}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick Overview Table: Recent Applications Pending Review */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Student Admission Applications Requiring Director Review
            </h3>
            <p className="text-xs text-slate-500">Only the Director holds legal authority to approve or reject candidates</p>
          </div>
          <Link
            to="/dashboard/admissions"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            View All ({applications.length})
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500">
                <th className="py-3 px-4 font-bold">Tracking #</th>
                <th className="py-3 px-4 font-bold">Applicant Name</th>
                <th className="py-3 px-4 font-bold">Department</th>
                <th className="py-3 px-4 font-bold">S3 Score</th>
                <th className="py-3 px-4 font-bold">Submitted Date</th>
                <th className="py-3 px-4 font-bold">Status</th>
                <th className="py-3 px-4 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
              {applications.slice(0, 4).map((app) => (
                <tr key={app.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                    {app.trackingNumber}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                    {app.fullName}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                    {app.department === 'software_development' ? 'Software Development' : 'Automobile Tech'}
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {app.s3AggregateScore} pts
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-500">
                    {new Date(app.submittedAt).toLocaleDateString()}
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        app.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : app.status === 'rejected'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      {app.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <Link
                      to={`/dashboard/admissions?review=${app.id}`}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all"
                    >
                      <span>Review</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
