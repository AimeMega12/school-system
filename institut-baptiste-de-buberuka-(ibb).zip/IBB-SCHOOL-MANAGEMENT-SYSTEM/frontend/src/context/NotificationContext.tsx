/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { NotificationItem, UserRole } from '../types/index.ts';
import { StorageService } from '../services/storage.ts';
import { useAuth } from './AuthContext.tsx';

interface NotificationContextType {
  notifications: NotificationItem[];
  unreadCount: number;
  addNotification: (notif: Omit<NotificationItem, 'id' | 'createdAt' | 'readBy'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  refreshNotifications: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const all = StorageService.getNotifications();
    if (!user) return [];
    return all.filter((n) => n.targetRoles.includes(user.role));
  });

  const refreshNotifications = useCallback(() => {
    const all = StorageService.getNotifications();
    if (!user) {
      setNotifications([]);
      return;
    }
    // Filter relevant to current role
    const relevant = all.filter((n) => n.targetRoles.includes(user.role));
    setNotifications(relevant);
  }, [user]);

  useEffect(() => {
    refreshNotifications();
    // Simulate real-time event checks every 10 seconds
    const interval = setInterval(refreshNotifications, 10000);
    return () => clearInterval(interval);
  }, [refreshNotifications]);

  const unreadCount = user
    ? notifications.filter((n) => !n.readBy.includes(user.id)).length
    : 0;

  const addNotification = (
    notif: Omit<NotificationItem, 'id' | 'createdAt' | 'readBy'>
  ) => {
    const newItem: NotificationItem = {
      ...notif,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      readBy: []
    };
    StorageService.addNotification(newItem);
    refreshNotifications();
  };

  const markAsRead = (id: string) => {
    if (!user) return;
    StorageService.markNotificationRead(id, user.id);
    refreshNotifications();
  };

  const markAllAsRead = () => {
    if (!user) return;
    StorageService.markAllNotificationsRead(user.id);
    refreshNotifications();
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        refreshNotifications
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
