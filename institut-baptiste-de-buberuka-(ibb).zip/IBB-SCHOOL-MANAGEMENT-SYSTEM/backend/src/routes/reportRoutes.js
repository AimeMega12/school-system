import express from 'express';
import { getAuditLogs, getExecutiveStats } from '../controllers/reportController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = express.Router();

router.get('/stats', authenticateToken, getExecutiveStats);
router.get('/audit-logs', authenticateToken, requireRole(['director']), getAuditLogs);

export default router;
