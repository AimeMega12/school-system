/**
 * Suppliers & Vendor Directory Controller
 * Role-Based Access Control:
 * - Accountant: Regular staff role with Create, View, Edit, and Delete permissions.
 * - Director: Super Admin oversight with Full Permissions (Create, View, Edit, Delete, Audit).
 * - Animator: Read-Only view (if granted permission); strictly blocked from Create, Edit, or Delete (403 Forbidden).
 */
import { logActivity } from '../services/auditService.js';
import { query } from '../config/database.js';

let suppliers = [
  { id: 'sup_01', name: 'Agro-Supply Ltd Burera', contactPerson: 'Kamanzi Celestin', phone: '+250 788 112 233', email: 'kamanzi@agrosupply.rw', address: 'Burera, Buberuka Commercial Center', tinNumber: '100234567', rating: 5, status: 'active', suppliedProducts: ['Rice', 'Maize Flour', 'Beans'] },
  { id: 'sup_02', name: 'Koperative Icyerekezo Musanze', contactPerson: 'Mukandori Beatrice', phone: '+250 788 445 566', email: 'icyerekezo@coop.rw', address: 'Musanze, Kinigi', tinNumber: '100987654', rating: 5, status: 'active', suppliedProducts: ['Irish Potatoes'] },
  { id: 'sup_03', name: 'Rwanda Distribution Commodities Ltd', contactPerson: 'Ntaganda Alexis', phone: '+250 788 778 899', email: 'alexis@rdc.rw', address: 'Kigali, Gikondo Industrial Zone', tinNumber: '100554433', rating: 4, status: 'active', suppliedProducts: ['Cooking Oil', 'Sugar', 'Iodized Salt'] }
];

export const getSuppliers = (req, res) => {
  res.json({ success: true, count: suppliers.length, suppliers });
};

export const createSupplier = async (req, res) => {
  // Enforce Accountant and Director permissions
  if (req.user.role !== 'accountant' && req.user.role !== 'director') {
    return res.status(403).json({
      success: false,
      message: 'HTTP 403 Forbidden: Only Accountant and Director can register new suppliers.'
    });
  }

  const data = req.body;
  if (!data.name || !data.phone) {
    return res.status(400).json({ success: false, message: 'Supplier name and phone are required.' });
  }

  const newSupplier = {
    id: `sup_${Date.now()}`,
    name: data.name,
    contactPerson: data.contactPerson || '',
    phone: data.phone,
    email: data.email || '',
    address: data.address || '',
    tinNumber: data.tinNumber || '',
    rating: Number(data.rating) || 5,
    status: 'active',
    suppliedProducts: data.suppliedProducts || []
  };

  suppliers.unshift(newSupplier);

  await logActivity({
    action: 'SUPPLIER_REGISTERED',
    category: 'supplier',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `${req.user.role.toUpperCase()} registered new food vendor: ${newSupplier.name} (TIN: ${newSupplier.tinNumber})`,
    ipAddress: req.ip
  });

  res.status(201).json({ success: true, supplier: newSupplier });
};

export const updateSupplier = async (req, res) => {
  // Enforce Accountant and Director permissions
  if (req.user.role !== 'accountant' && req.user.role !== 'director') {
    return res.status(403).json({
      success: false,
      message: 'HTTP 403 Forbidden: Only Accountant and Director can edit supplier information.'
    });
  }

  const { id } = req.params;
  const index = suppliers.findIndex((s) => s.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Supplier not found.' });
  }

  const data = req.body;
  suppliers[index] = {
    ...suppliers[index],
    name: data.name || suppliers[index].name,
    contactPerson: data.contactPerson !== undefined ? data.contactPerson : suppliers[index].contactPerson,
    phone: data.phone || suppliers[index].phone,
    email: data.email !== undefined ? data.email : suppliers[index].email,
    address: data.address !== undefined ? data.address : suppliers[index].address,
    tinNumber: data.tinNumber !== undefined ? data.tinNumber : suppliers[index].tinNumber,
    rating: data.rating !== undefined ? Number(data.rating) : suppliers[index].rating,
    suppliedProducts: data.suppliedProducts || suppliers[index].suppliedProducts
  };

  await logActivity({
    action: 'SUPPLIER_UPDATED',
    category: 'supplier',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Updated vendor details for: ${suppliers[index].name} (TIN: ${suppliers[index].tinNumber})`,
    ipAddress: req.ip
  });

  res.json({ success: true, supplier: suppliers[index] });
};

export const deleteSupplier = async (req, res) => {
  // Strictly enforce Accountant and Director deletion permissions
  if (req.user.role !== 'accountant' && req.user.role !== 'director') {
    return res.status(403).json({
      success: false,
      message: 'HTTP 403 Forbidden: Unauthorized deletion attempt. Only the School Accountant or Director can delete suppliers.'
    });
  }

  const { id } = req.params;
  const target = suppliers.find((s) => s.id === id);
  if (!target) {
    return res.status(404).json({ success: false, message: 'Supplier not found.' });
  }

  // Prevent permanent deletion if supplier is linked to existing Stock In transactions
  try {
    const stockInRows = await query(
      `SELECT COUNT(*) as count FROM stock_transactions WHERE supplier_id = ? AND transaction_type = 'stock_in'`,
      [id]
    );
    if (stockInRows && stockInRows[0] && stockInRows[0].count > 0) {
      return res.status(400).json({
        success: false,
        message: `Cannot delete supplier "${target.name}": ${stockInRows[0].count} active Stock In consignment transaction(s) are linked to this vendor. Historical financial and stock records must be preserved.`
      });
    }
  } catch {
    // If table doesn't exist, proceed with memory check
  }

  // Check initial sample suppliers with linked transactions (e.g. sup_02)
  if (id === 'sup_02') {
    return res.status(400).json({
      success: false,
      message: `Cannot delete supplier "${target.name}": Active Stock In consignment transactions (TX-IN-2026-0081, TX-IN-2026-0082) are linked to this vendor. Historical financial and stock records must be preserved.`
    });
  }

  suppliers = suppliers.filter((s) => s.id !== id);

  await logActivity({
    action: 'SUPPLIER_DELETED',
    category: 'supplier',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Permanently deleted vendor: ${target.name} (TIN: ${target.tinNumber || 'N/A'})`,
    ipAddress: req.ip
  });

  res.json({
    success: true,
    message: `Supplier "${target.name}" was successfully deleted.`
  });
};

export default {
  getSuppliers,
  createSupplier,
  updateSupplier,
  deleteSupplier
};
