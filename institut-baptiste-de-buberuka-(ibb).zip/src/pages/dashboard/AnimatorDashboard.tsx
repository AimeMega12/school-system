/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { Product, StockTransaction } from '../../types/index.ts';
import {
  Clock,
  ArrowUpRight,
  Package,
  Calendar,
  AlertCircle,
  CheckCircle2,
  X,
  History,
  ShieldCheck,
  ShieldAlert,
  ArrowDownRight
} from 'lucide-react';

export const AnimatorDashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  // Clock state
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const products = StorageService.getProducts();
  const transactions = StorageService.getTransactions();
  const schedule = StorageService.getSchedule();
  const delegations = StorageService.getDelegations();

  // Check active delegation
  const activeDelegation = delegations.find(
    (d) =>
      d.grantedToUserId === user?.id &&
      d.status === 'active' &&
      new Date(d.expiresAt) > new Date()
  );

  // Check working hours
  const workingHoursCheck = StorageService.isStockWindowOpen(schedule);

  // Filter Animator's today stock outs
  const todayDateStr = currentTime.toISOString().split('T')[0];
  const myTodayStockOuts = transactions.filter(
    (t) =>
      t.type === 'stock_out' &&
      t.performedByUserId === user?.id &&
      t.createdAt.startsWith(todayDateStr)
  );

  const totalIssuedTodayKg = myTodayStockOuts.reduce((sum, t) => sum + t.quantity, 0);

  // Fast Stock Out Modal
  const [isStockOutModalOpen, setIsStockOutModalOpen] = useState(false);
  const [productId, setProductId] = useState(products[0]?.id || '');
  const [quantity, setQuantity] = useState<number>(60);
  const [mealCategory, setMealCategory] = useState<'breakfast' | 'lunch' | 'dinner' | 'special_event'>('lunch');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleStockOutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!workingHoursCheck.isOpen && !schedule.emergencyOverrideActive) {
      setErrorMsg(`Access restricted! ${workingHoursCheck.reason}`);
      return;
    }

    const prod = products.find((p) => p.id === productId);
    if (!prod) return;

    if (quantity <= 0) {
      setErrorMsg('Quantity must be greater than zero.');
      return;
    }

    if (prod.currentStock < quantity) {
      setErrorMsg(
        `Insufficient inventory! Only ${prod.currentStock} ${prod.unit} available in storage.`
      );
      return;
    }

    const newTx: StockTransaction = {
      id: `tx_${Date.now()}`,
      transactionNumber: `TX-OUT-${Date.now().toString().slice(-4)}`,
      productId: prod.id,
      productName: prod.name,
      type: 'stock_out',
      quantity: Number(quantity),
      unit: prod.unit,
      mealCategory,
      purposeNotes: notes.trim() || `Daily ration for ${mealCategory}`,
      performedByUserId: user!.id,
      performedByUserName: user!.fullName,
      performedByRole: user!.role,
      isEmergencyOverride: schedule.emergencyOverrideActive,
      createdAt: new Date().toISOString()
    };

    StorageService.addTransaction(newTx);

    // Audit log
    StorageService.addAuditLog({
      action: 'STOCK_OUT_RECORDED',
      category: 'stock_out',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Animator issued ${quantity} ${prod.unit} ${prod.name} for ${mealCategory}`,
      ipAddress: '197.243.34.82'
    });

    // Notify Accountant & Director immediately
    addNotification({
      title: `Animator Stock Out: ${quantity} ${prod.unit} ${prod.nameEn}`,
      titleRw: `Ifunguro ryasohowe: ${quantity} ${prod.unit} bya ${prod.nameRw}`,
      message: `Animator Jean-Claude issued ${quantity} ${prod.unit} ${prod.nameEn} for ${mealCategory}.`,
      messageRw: `Animator Jean-Claude yasohoye ${quantity} ${prod.unit} bya ${prod.nameRw} byo guteka.`,
      type: 'info',
      category: 'stock_out',
      targetRoles: ['director', 'accountant'],
      relatedId: newTx.id
    });

    setIsStockOutModalOpen(false);
    setSuccessMsg(`Successfully issued ${quantity} ${prod.unit} of ${prod.name} for ${mealCategory}.`);
    setTimeout(() => setSuccessMsg(''), 4500);
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Live Local Clock Header */}
      <DashboardPageHeader
        title={t('animDashboardTitle')}
        subtitle={t('animDashboardSub')}
        variant="emerald"
      >
        {/* Live Rwandan Time Card */}
        <div className="px-4 py-2.5 rounded-xl bg-white/90 dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center gap-3 self-start sm:self-auto">
          <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              {t('currentLocalTime')}
            </span>
            <span className="text-base font-extrabold font-mono text-slate-900 dark:text-white tabular-nums tracking-wide">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
            </span>
          </div>
        </div>
      </DashboardPageHeader>

      {successMsg && (
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Stock Working Hours Status Banner */}
      <div
        className={`p-5 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 ${
          workingHoursCheck.isOpen
            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-950 dark:text-emerald-100'
            : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-950 dark:text-amber-100'
        }`}
      >
        <div className="flex items-start sm:items-center gap-3">
          {workingHoursCheck.isOpen ? (
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          ) : (
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0">
              <Clock className="w-6 h-6" />
            </div>
          )}
          <div>
            <div className="flex items-center gap-2 font-extrabold text-sm uppercase tracking-wider">
              <span>{workingHoursCheck.isOpen ? t('windowStatusOpen') : t('windowStatusClosed')}</span>
              {schedule.emergencyOverrideActive && (
                <span className="px-2 py-0.5 rounded text-[10px] bg-red-600 text-white">
                  DIRECTOR OVERRIDE
                </span>
              )}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
              {workingHoursCheck.reason}
            </p>
          </div>
        </div>

        {/* Prominent Create Stock Out Button */}
        <button
          onClick={() => {
            if (!workingHoursCheck.isOpen && !schedule.emergencyOverrideActive) {
              alert(t('outsideHoursNotice'));
              return;
            }
            setIsStockOutModalOpen(true);
          }}
          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/30 transition-all shrink-0"
        >
          <ArrowUpRight className="w-5 h-5" />
          <span>{t('btnCreateStockOut')}</span>
        </button>
      </div>

      {/* Delegated Stock In Banner (if Accountant granted temporary authority) */}
      {activeDelegation && (
        <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span className="font-bold text-blue-950 dark:text-blue-200">
              Accountant Delegation Active: You are authorized to perform Main Stock In until{' '}
              {new Date(activeDelegation.expiresAt).toLocaleTimeString()}
            </span>
          </div>
          <Link
            to="/dashboard/stock"
            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <ArrowDownRight className="w-3.5 h-3.5" />
            <span>Perform Delegated Stock In</span>
          </Link>
        </div>
      )}

      {/* 3 Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            {t('myTodayStockOut')}
          </span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
            {totalIssuedTodayKg.toLocaleString()} Kg
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {myTodayStockOuts.length} issues logged today
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Authorized Morning Window
          </span>
          <div className="text-xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
            06:00 AM – 08:00 AM
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Breakfast porridge & meal preparation
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
            Authorized Evening Window
          </span>
          <div className="text-xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
            05:00 PM – 07:00 PM
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Dinner ration distribution
          </span>
        </div>
      </div>

      {/* Live Available Stock Inventory Quick Glance */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-4 h-4 text-emerald-600" />
            <span>Food Stocks Available in Storage</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Updated in Real-Time
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {products.map((p) => {
            const isLow = p.currentStock <= p.minThreshold;
            return (
              <div
                key={p.id}
                className={`p-3.5 rounded-xl border text-xs ${
                  isLow
                    ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800/80'
                    : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-800'
                }`}
              >
                <div className="font-bold text-slate-900 dark:text-white truncate">
                  {language === 'rw' ? p.nameRw : p.nameEn}
                </div>
                <div className="text-[11px] text-slate-500 mb-1">
                  {language === 'rw' ? p.nameEn : p.nameRw}
                </div>
                <div className="font-mono text-base font-extrabold text-slate-900 dark:text-white tabular-nums">
                  {p.currentStock.toLocaleString()} {p.unit}
                </div>
                {isLow && (
                  <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 block mt-1">
                    Low Stock Alert
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Today's Transactions by Animator */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4">
          Today's Recorded Stock Out History
        </h3>

        {myTodayStockOuts.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No stock out operations recorded by your account today yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500">
                  <th className="py-2.5 px-3 font-bold">Tx #</th>
                  <th className="py-2.5 px-3 font-bold">Product</th>
                  <th className="py-2.5 px-3 font-bold">Quantity</th>
                  <th className="py-2.5 px-3 font-bold">Purpose / Meal</th>
                  <th className="py-2.5 px-3 font-bold text-right">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {myTodayStockOuts.map((tx) => (
                  <tr key={tx.id}>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                      {tx.transactionNumber}
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {tx.productName}
                    </td>
                    <td className="py-3 px-3 font-mono font-extrabold text-emerald-600 dark:text-emerald-400">
                      -{tx.quantity} {tx.unit}
                    </td>
                    <td className="py-3 px-3 capitalize text-slate-600 dark:text-slate-400">
                      {tx.mealCategory || 'Meal Ration'}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-500 text-right">
                      {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Stock Out Modal */}
      {isStockOutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-emerald-600" />
                <span>{t('recordStockOutTitle')}</span>
              </h3>
              <button onClick={() => setIsStockOutModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleStockOutSubmit} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">{t('selectProduct')} *</label>
                <select
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} — Current: {p.currentStock} {p.unit}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">{t('issueQuantity')} *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">{t('mealCategoryLabel')} *</label>
                  <select
                    value={mealCategory}
                    onChange={(e) => setMealCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="breakfast">{t('mealBreakfast')}</option>
                    <option value="lunch">{t('mealLunch')}</option>
                    <option value="dinner">{t('mealDinner')}</option>
                    <option value="special_event">{t('mealSpecial')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">{t('stockOutNotes')}</label>
                <input
                  type="text"
                  placeholder="Dormitory kitchen head cook, remarks..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsStockOutModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20"
                >
                  {t('submitStockOutBtn')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
