import express from 'express';
import { getApprovedStudents, exportApprovedStudents } from '../controllers/studentController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = express.Router();

router.get('/', authenticateToken, requireRole(['director', 'accountant']), getApprovedStudents);
router.get('/export/csv', authenticateToken, requireRole(['director', 'accountant']), exportApprovedStudents);

export default router;
