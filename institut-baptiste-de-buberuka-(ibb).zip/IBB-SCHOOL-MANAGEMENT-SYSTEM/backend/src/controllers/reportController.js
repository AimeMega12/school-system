/**
 * Analytics & Audit Logs Controller
 */
import { query } from '../config/database.js';

let auditLogs = [
  { id: 'log_01', action: 'ADMISSION_APPROVED', category: 'admission', userId: 'user_director_01', userName: 'Rev. Dr. Emmanuel Nshimyumuremyi', userRole: 'director', details: 'Approved candidate Uwase Claudine (IBB-2026-01928) for L3 Software Development', ipAddress: '197.243.34.82', timestamp: '2026-10-27T16:00:00Z' },
  { id: 'log_02', action: 'STOCK_OUT_RECORDED', category: 'stock_out', userId: 'user_animator_01', userName: 'Jean-Claude Habimana', userRole: 'animator', details: 'Stock Out for breakfast: 60 Kg Rice. Storage Window: 06:00-08:00', ipAddress: '197.243.34.82', timestamp: '2026-10-31T06:45:00Z' },
  { id: 'log_03', action: 'ACADEMIC_POLICY_UPDATED', category: 'academic_rules', userId: 'user_director_01', userName: 'Rev. Dr. Emmanuel Nshimyumuremyi', userRole: 'director', details: 'Updated admission minimum cut-off to 50.0% and boarding cut-off to 80.0%', ipAddress: '197.243.34.82', timestamp: '2026-10-26T09:00:00Z' }
];

export const getAuditLogs = (req, res) => {
  const { category, search } = req.query;
  let list = [...auditLogs];

  if (category && category !== 'all') {
    list = list.filter(l => l.category === category);
  }
  if (search) {
    const s = search.toLowerCase();
    list = list.filter(l =>
      l.action.toLowerCase().includes(s) ||
      l.userName.toLowerCase().includes(s) ||
      l.details.toLowerCase().includes(s)
    );
  }

  res.json({ success: true, count: list.length, logs: list });
};

export const getExecutiveStats = (req, res) => {
  const stats = {
    totalApplications: 5,
    approvedStudents: 2,
    underReview: 1,
    autoRejected: 1,
    inventoryValuationRwf: 4625000,
    lowStockAlerts: 1,
    activeStaffMembers: 3,
    workingHoursMorning: '06:00 - 08:00 AM',
    workingHoursEvening: '17:00 - 19:00 PM',
    currentEmergencyOverride: false
  };

  res.json({ success: true, stats });
};

export default { getAuditLogs, getExecutiveStats };
