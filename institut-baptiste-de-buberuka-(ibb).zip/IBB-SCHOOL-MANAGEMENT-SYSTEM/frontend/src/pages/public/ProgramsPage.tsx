/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { Link } from 'react-router-dom';
import { Code, Wrench, CheckCircle, Clock, BookOpen, Briefcase, ArrowRight } from 'lucide-react';

export const ProgramsPage: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="py-12 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            {language === 'rw' ? 'Amashami Yemewe na RTB' : 'Accredited TVET Programs'}
          </span>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mt-2 mb-4 text-slate-900 dark:text-white">
            {t('programsTitle')}
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-300">
            {t('programsSubtitle')}
          </p>
        </div>

        {/* Program 1: Software Development */}
        <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden mb-16 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
            <div className="lg:col-span-6 relative min-h-[300px]">
              <img
                src="/src/assets/images/ibb_software_lab_1793449105866.jpg"
                alt="Software Development Laboratory at IBB"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 bg-blue-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-md">
                Level 3 (L3) · 3 Years
              </div>
            </div>

            <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 mb-2">
                  <Code className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">
                    Information and Communication Technology
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-4">
                  {t('progSoftTitle')}
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                  {language === 'rw'
                    ? 'Aya masomo ategura umunyeshuri gusesengura, gutegura no kubaka porogaramu za mudasobwa na telefoni, imbuga za interineti, no gucunga ububiko bw’amakuru hakoreshejwe ubumenyi bugezweho mu ikoranabuhanga.'
                    : 'This qualification provides foundational and intermediate competencies in frontend & backend web technologies, relational database management, algorithm design, API integrations, and mobile application engineering.'}
                </p>

                <div className="space-y-4 mb-6">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Key Curriculum Modules:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-600 dark:text-slate-400">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Web Development (HTML, CSS, JS, React)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Relational Databases & SQL</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Backend APIs (Node.js & Express)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Object Oriented Programming</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Cybersecurity Basics & Linux OS</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Software Testing & Git Versioning</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500 block">Entry Requirement</span>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Successful completion of S3
                  </span>
                </div>
                <Link
                  to="/apply?dept=software_development"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-500 shadow-md shadow-blue-600/30 transition-all"
                >
                  <span>Apply for Software Dev</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Program 2: Automobile Technology */}
        <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
            <div className="lg:col-span-6 relative min-h-[300px]">
              <img
                src="/src/assets/images/ibb_automobile_tech_1793449106101.jpg"
                alt="Automobile Technology Workshop at IBB"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-md">
                Level 3 (L3) · 3 Years
              </div>
            </div>

            <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 mb-2">
                  <Wrench className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">
                    Automotive Engineering & Mechanics
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-4">
                  {t('progAutoTitle')}
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                  {language === 'rw'
                    ? 'Inyigisho zihugura abanyeshuri ku buryo bwo gusuzuma amakosa ya moteri hakoreshejwe mudasobwa (OBD scanners), gusana amamodoka yose, gukora amashanyarazi y’ibinyabiziga, no gukurikirana ibinyabiziga bicungwa n’inganda.'
                    : 'Comprehensive workshop-centered training in automotive electronics, computerized fault diagnostics, engine overhaul, suspension, hydraulic brakes, and transmission servicing for light and commercial vehicles.'}
                </p>

                <div className="space-y-4 mb-6">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Key Curriculum Modules:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-600 dark:text-slate-400">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Computerized OBD-II Diagnostics</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Electronic Fuel Injection (EFI) Systems</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Engine Mechanical Overhaul & Tuning</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Automotive Electricity & Wiring</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Braking, ABS & Hydraulic Controls</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      <span>Occupational Health & Workshop Safety</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500 block">Entry Requirement</span>
                  <span className="text-xs font-bold text-slate-900 dark:text-white">
                    Successful completion of S3
                  </span>
                </div>
                <Link
                  to="/apply?dept=automobile_technology"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all"
                >
                  <span>Apply for Automobile Tech</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
