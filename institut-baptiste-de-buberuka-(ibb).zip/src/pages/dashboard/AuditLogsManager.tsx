/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { AuditLog } from '../../types/index.ts';
import { ShieldAlert, Search, Filter, Calendar, UserCheck, ShieldCheck } from 'lucide-react';

export const AuditLogsManager: React.FC = () => {
  const { t, language } = useLanguage();
  const [logs] = useState<AuditLog[]>(() => StorageService.getAuditLogs());
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.ipAddress && log.ipAddress.includes(searchQuery));

    const matchesCat = categoryFilter === 'all' || log.category === categoryFilter;

    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <DashboardPageHeader
        title={t('auditLogsTitle')}
        subtitle={t('auditLogsSub')}
        variant="amber"
      >
        <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-xl bg-white/90 dark:bg-slate-900/90 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Immutable Ledger Active</span>
        </div>
      </DashboardPageHeader>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search action keyword, user, or IP address..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          <option value="all">All Categories</option>
          <option value="auth">Authentication & 2FA</option>
          <option value="admission">Admissions</option>
          <option value="stock_in">Stock In</option>
          <option value="stock_out">Stock Out</option>
          <option value="stock_schedule">Schedule & Overrides</option>
          <option value="permission">Permissions & Delegations</option>
          <option value="system">System Governance</option>
        </select>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                <th className="py-2.5 px-3 font-bold">{t('logAction')}</th>
                <th className="py-2.5 px-3 font-bold">{t('logCategory')}</th>
                <th className="py-2.5 px-3 font-bold">{t('logUser')}</th>
                <th className="py-2.5 px-3 font-bold">{t('logDetails')}</th>
                <th className="py-2.5 px-3 font-bold">IP Address</th>
                <th className="py-2.5 px-3 font-bold text-right">{t('logTimestamp')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                    {log.action}
                  </td>
                  <td className="py-3 px-3">
                    <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {log.category}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {log.userName}
                    </div>
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {log.userRole}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-300 max-w-md">
                    {log.details}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-400 text-[11px]">
                    {log.ipAddress || '197.243.34.82'}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-500 text-right whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
