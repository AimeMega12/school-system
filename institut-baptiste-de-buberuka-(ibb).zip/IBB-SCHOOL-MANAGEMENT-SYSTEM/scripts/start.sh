#!/usr/bin/env bash
# ==============================================================================
# INSTITUT BAPTISTE DE BUBERUKA (IBB) - Development Launch Script
# ==============================================================================

echo "🌟 Launching IBB School Management System..."

# Start backend in background
echo "⚡ Starting Express Backend API on port 5000..."
cd backend && npm start &
BACKEND_PID=$!
cd ..

# Start frontend
echo "🎨 Starting React Frontend on port 3000..."
cd frontend && npm run dev &
FRONTEND_PID=$!
cd ..

echo "=================================================================="
echo "  IBB SCHOOL MANAGEMENT SYSTEM IS RUNNING!"
echo "  Frontend URL: http://localhost:3000"
echo "  Backend API:  http://localhost:5000"
echo "  Health Check: http://localhost:5000/api/health"
echo "=================================================================="

trap "kill $BACKEND_PID $FRONTEND_PID" EXIT
wait
