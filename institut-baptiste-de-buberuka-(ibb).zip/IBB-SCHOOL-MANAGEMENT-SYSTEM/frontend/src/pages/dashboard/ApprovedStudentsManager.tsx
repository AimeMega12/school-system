/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { ApprovedStudent, AcademicLevel, DepartmentType } from '../../types/index.ts';
import {
  GraduationCap,
  Search,
  Filter,
  Download,
  Printer,
  CheckCircle2,
  Award,
  Layers,
  Users,
  Building,
  UserCheck
} from 'lucide-react';

export const ApprovedStudentsManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();

  const [students, setStudents] = useState<ApprovedStudent[]>(() =>
    StorageService.getApprovedStudents()
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<'all' | AcademicLevel>('all');
  const [deptFilter, setDeptFilter] = useState<'all' | DepartmentType>('all');
  const [boardingFilter, setBoardingFilter] = useState<'all' | 'boarding_scholar' | 'day_scholar'>('all');

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchesSearch =
        s.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.applicationNumber.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesLevel = levelFilter === 'all' || s.admissionLevel === levelFilter;
      const matchesDept = deptFilter === 'all' || s.department === deptFilter;
      const matchesBoarding = boardingFilter === 'all' || s.boardingStatus === boardingFilter;

      return matchesSearch && matchesLevel && matchesDept && matchesBoarding;
    });
  }, [students, searchQuery, levelFilter, deptFilter, boardingFilter]);

  const stats = useMemo(() => {
    return {
      total: students.length,
      l3: students.filter((s) => s.admissionLevel === 'L3').length,
      l4: students.filter((s) => s.admissionLevel === 'L4').length,
      l5: students.filter((s) => s.admissionLevel === 'L5').length,
      boarding: students.filter((s) => s.boardingStatus === 'boarding_scholar').length
    };
  }, [students]);

  const handleExportCSV = () => {
    const headers = ['ID', 'Student Name', 'Tracking No', 'Level', 'Department', 'Academic Score (%)', 'Boarding Status', 'Approval Date', 'Approved By'];
    const rows = filteredStudents.map((s) => [
      s.id,
      `"${s.studentName}"`,
      s.applicationNumber,
      s.admissionLevel,
      s.department,
      s.academicScore,
      s.boardingStatus,
      new Date(s.approvalDate).toLocaleDateString(),
      `"${s.approvedBy}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `IBB_Approved_Students_Register_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            Official Admitted Registry (L3, L4, L5)
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            {t('approvedStudentsTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('approvedStudentsSub')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Register</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-colors shadow-sm shadow-emerald-600/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 block mb-1">Total Admitted</span>
          <span className="text-xl font-mono font-black text-slate-900 dark:text-white tabular-nums">
            {stats.total}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 block mb-1">Level 3 (L3)</span>
          <span className="text-xl font-mono font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
            {stats.l3}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 block mb-1">Level 4 (L4)</span>
          <span className="text-xl font-mono font-black text-blue-600 dark:text-blue-400 tabular-nums">
            {stats.l4}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-[11px] text-slate-500 block mb-1">Level 5 (L5)</span>
          <span className="text-xl font-mono font-black text-indigo-600 dark:text-indigo-400 tabular-nums">
            {stats.l5}
          </span>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 col-span-2 sm:col-span-1">
          <span className="text-[11px] text-slate-500 block mb-1">Boarding Scholars</span>
          <span className="text-xl font-mono font-black text-amber-600 dark:text-amber-400 tabular-nums">
            {stats.boarding}
          </span>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search candidate name or tracking number (IBB-2026-XXXX)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Level Filter */}
            <select
              value={levelFilter}
              onChange={(e) => setLevelFilter(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Levels (L3, L4, L5)</option>
              <option value="L3">Level 3 (L3)</option>
              <option value="L4">Level 4 (L4)</option>
              <option value="L5">Level 5 (L5)</option>
            </select>

            {/* Dept Filter */}
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Departments</option>
              <option value="software_development">Software Development</option>
              <option value="automobile_technology">Automobile Technology</option>
            </select>

            {/* Boarding Filter */}
            <select
              value={boardingFilter}
              onChange={(e) => setBoardingFilter(e.target.value as any)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Residencies</option>
              <option value="boarding_scholar">Boarding Scholar</option>
              <option value="day_scholar">Day Scholar</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider font-semibold text-[11px]">
              <tr>
                <th className="py-3.5 px-4">Student & Tracking No</th>
                <th className="py-3.5 px-4">Admitted Level</th>
                <th className="py-3.5 px-4">Department</th>
                <th className="py-3.5 px-4">Verified Score</th>
                <th className="py-3.5 px-4">Residency Status</th>
                <th className="py-3.5 px-4">Approval Attestation</th>
                <th className="py-3.5 px-4 text-right">Enrollment</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredStudents.length > 0 ? (
                filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {s.studentName}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {s.applicationNumber}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 font-mono font-bold px-2.5 py-0.5 rounded text-xs ${
                        s.admissionLevel === 'L3'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : s.admissionLevel === 'L4'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
                      }`}>
                        {s.admissionLevel}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="text-slate-800 dark:text-slate-200">
                        {s.department === 'software_development'
                          ? 'Software Development'
                          : 'Automobile Technology'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {s.academicScore}%
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                        s.boardingStatus === 'boarding_scholar'
                          ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                      }`}>
                        {s.boardingStatus === 'boarding_scholar' ? t('boardingScholar') : t('dayScholar')}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="text-slate-700 dark:text-slate-300 block">
                        {s.approvedBy}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {new Date(s.approvalDate).toLocaleDateString()}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400 text-xs">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span className="uppercase">{s.status}</span>
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-500">
                    No approved students found matching the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
