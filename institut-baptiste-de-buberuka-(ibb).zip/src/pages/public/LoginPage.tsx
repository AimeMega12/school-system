/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.tsx';
import { useLanguage } from '../../context/LanguageContext.tsx';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  GraduationCap,
  Info,
  X,
  ExternalLink
} from 'lucide-react';

declare global {
  interface Window {
    google?: any;
  }
}

export const LoginPage: React.FC = () => {
  const { login, loginWithGoogle, isAuthenticated, user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  // Form State
  const [identifier, setIdentifier] = useState(() => {
    return localStorage.getItem('ibb_remembered_id') || 'director';
  });
  const [password, setPassword] = useState('Password123!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(() => {
    return localStorage.getItem('ibb_remember_me') === 'true';
  });
  const [errorMessage, setErrorMessage] = useState('');
  const [recoveryNotice, setRecoveryNotice] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [googleModalOpen, setGoogleModalOpen] = useState(false);
  const [googleSetupInstructionsOpen, setGoogleSetupInstructionsOpen] = useState(false);

  const googleBtnRef = useRef<HTMLDivElement>(null);

  // If already authenticated, redirect to correct role-based dashboard
  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === 'director') navigate('/dashboard/director');
      else if (user.role === 'accountant') navigate('/dashboard/accountant');
      else if (user.role === 'animator') navigate('/dashboard/animator');
      else navigate('/dashboard');
    }
  }, [isAuthenticated, user, navigate]);

  // Initialize Google Identity Services if available and client ID configured
  useEffect(() => {
    const googleClientId =
      (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID ||
      (import.meta as any).env?.GOOGLE_CLIENT_ID;

    if (window.google?.accounts?.id && googleClientId && googleClientId !== 'your_google_client_id') {
      try {
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: (response: any) => {
            if (response.credential) {
              handleGoogleCredential(response.credential);
            }
          }
        });

        if (googleBtnRef.current) {
          window.google.accounts.id.renderButton(googleBtnRef.current, {
            theme: 'outline',
            size: 'large',
            width: '100%',
            text: 'continue_with'
          });
        }
      } catch (err) {
        console.error('Failed to initialize Google GSI:', err);
      }
    }
  }, []);

  const handleGoogleCredential = async (credential: string) => {
    setIsLoading(true);
    setErrorMessage('');
    const res = loginWithGoogle(credential);
    setIsLoading(false);
    if (!res.success) {
      setErrorMessage(res.error || 'Google Sign-In failed.');
    }
  };

  const handleManualGoogleClick = () => {
    const googleClientId =
      (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID ||
      (import.meta as any).env?.GOOGLE_CLIENT_ID;

    if (!googleClientId || googleClientId === 'your_google_client_id') {
      setGoogleSetupInstructionsOpen(true);
      return;
    }

    if (window.google?.accounts?.id) {
      window.google.accounts.id.prompt((notification: any) => {
        if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
          setGoogleModalOpen(true);
        }
      });
    } else {
      setGoogleSetupInstructionsOpen(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setIsLoading(true);

    if (rememberMe) {
      localStorage.setItem('ibb_remembered_id', identifier);
      localStorage.setItem('ibb_remember_me', 'true');
    } else {
      localStorage.removeItem('ibb_remembered_id');
      localStorage.removeItem('ibb_remember_me');
    }

    const result = login(identifier, password);
    setIsLoading(false);

    if (!result.success) {
      setErrorMessage(result.error || t('invalidCredentials'));
    }
  };

  const autofillAccount = (u: string, p: string) => {
    setIdentifier(u);
    setPassword(p);
    setErrorMessage('');
  };

  return (
    <div className="py-12 sm:py-16 bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-slate-100 min-h-[85vh] flex items-center justify-center">
      <div className="max-w-md mx-auto px-4 w-full">
        {/* Back to Home Button */}
        <div className="mb-6 flex items-center justify-between">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 transition-all shadow-xs group min-h-[40px]"
            title="Return to Karenge Adventist Secondary School public homepage"
          >
            <ArrowLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:-translate-x-0.5 transition-transform" />
            <span>Back to Home</span>
          </Link>
          <span className="text-[11px] font-semibold text-slate-400">
            KARENGE ADVENTIST
          </span>
        </div>

        {/* Brand Lockup */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#071A33] via-[#1769FF] to-[#009B72] text-white flex items-center justify-center mx-auto mb-3 shadow-lg shadow-blue-600/20">
            <GraduationCap className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('loginTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('loginSubtitle')}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>Staff Authentication</span>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Identifier (Email / Username) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                {t('usernameOrEmail')} *
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="e.g. director, accountant, animator, tzrdidier@gmail.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Password with Show/Hide toggle */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  {t('password')} *
                </label>
                <button
                  type="button"
                  onClick={() => setRecoveryNotice(!recoveryNotice)}
                  className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                >
                  {t('forgotPassword')}
                </button>
              </div>

              {recoveryNotice && (
                <div className="mb-2 p-2.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-[11px] leading-relaxed">
                  Please contact the School Director (tzrdidier@gmail.com) to reset your staff credentials or re-enable your account.
                </div>
              )}

              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-600 dark:text-slate-400 select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
                <span>Remember me on this browser</span>
              </label>
            </div>

            {/* Sign In Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-70"
            >
              <span>{isLoading ? 'Authenticating...' : t('loginBtn')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Visual Divider: OR */}
            <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white dark:bg-slate-900 px-3 text-slate-400 font-semibold tracking-wider text-[10px]">
                  OR
                </span>
              </div>
            </div>

            {/* Real Google Sign-In */}
            <div className="w-full">
              <div ref={googleBtnRef} className="w-full flex justify-center empty:hidden" />
              <button
                type="button"
                onClick={handleManualGoogleClick}
                className="w-full flex items-center justify-center gap-3 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/70 text-slate-700 dark:text-slate-200 text-xs font-semibold shadow-sm transition-all cursor-pointer"
              >
                {/* Official Google G Logo SVG */}
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>

            {/* Quick Demo Staff Accounts Helper */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
                {t('clickToAutofill')} (Strong Passwords)
              </span>
              <div className="space-y-1.5">
                <button
                  type="button"
                  onClick={() => autofillAccount('director', 'Password123!')}
                  className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-emerald-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block text-xs">
                      Director (Super Admin)
                    </span>
                    <span className="text-[11px] text-slate-500">tzrdidier@gmail.com</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                    Use
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => autofillAccount('accountant', 'Password123!')}
                  className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-blue-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block text-xs">
                      Accountant (Suppliers & Stock In)
                    </span>
                    <span className="text-[11px] text-slate-500">accountant@ibb.ac.rw</span>
                  </div>
                  <span className="text-[11px] font-mono text-blue-600 dark:text-blue-400 font-semibold">
                    Use
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => autofillAccount('animator', 'Password123!')}
                  className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-amber-50 dark:bg-slate-800 dark:hover:bg-slate-700/80 transition-colors flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block text-xs">
                      Animator (Daily Stock Out)
                    </span>
                    <span className="text-[11px] text-slate-500">animator@ibb.ac.rw</span>
                  </div>
                  <span className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-semibold">
                    Use
                  </span>
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Security badge notice */}
        <div className="mt-6 text-center text-xs text-slate-400 flex items-center justify-center gap-1.5">
          <Lock className="w-3.5 h-3.5 text-emerald-500" />
          <span>Encrypted Session · Strong Password Policy & Google OAuth 2.0</span>
        </div>
      </div>

      {/* Google Setup Guide Modal (When credentials are not yet entered in .env) */}
      {googleSetupInstructionsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-md w-full p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Google OAuth Configuration Required
                </h3>
              </div>
              <button
                onClick={() => setGoogleSetupInstructionsOpen(false)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              Google Sign-In is built with official Google OAuth 2.0 / OpenID Connect. To connect your Google Cloud project:
            </p>

            <ol className="list-decimal pl-5 space-y-1.5 text-slate-600 dark:text-slate-400">
              <li>Open Google Cloud Console &gt; APIs &amp; Services &gt; Credentials.</li>
              <li>Create an OAuth 2.0 Client ID (Web Application).</li>
              <li>Add authorized JavaScript origin: <code className="font-mono bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">http://localhost:3000</code></li>
              <li>Add backend variables to <code className="font-mono bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded">backend/.env</code>:
                <pre className="font-mono bg-slate-100 dark:bg-slate-800 p-2 rounded mt-1 text-[10px]">
                  GOOGLE_CLIENT_ID=your_id.apps.googleusercontent.com{'\n'}
                  GOOGLE_CLIENT_SECRET=your_secret{'\n'}
                  GOOGLE_CALLBACK_URL=http://localhost:3000/api/auth/google/callback
                </pre>
              </li>
              <li>Ensure staff accounts in Karenge Adventist match their verified Google email (e.g. <span className="font-bold text-slate-800 dark:text-slate-200">tzrdidier@gmail.com</span>).</li>
            </ol>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setGoogleSetupInstructionsOpen(false)}
                className="px-4 py-2 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
