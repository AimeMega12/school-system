/**
 * Intelligent Food Stock & Commodities Controller
 */
import { logActivity } from '../services/auditService.js';

let products = [
  { id: 'prod_rice_01', code: 'STK-RIC-01', nameRw: 'Umuceri', nameEn: 'Rice', category: 'cereal', unit: 'Kg', minThreshold: 300, currentStock: 850, unitCostRwf: 1400 },
  { id: 'prod_beans_02', code: 'STK-BEA-02', nameRw: 'Ibishyimbo', nameEn: 'Beans', category: 'vegetable', unit: 'Kg', minThreshold: 250, currentStock: 620, unitCostRwf: 1100 },
  { id: 'prod_flour_03', code: 'STK-MAI-03', nameRw: 'Kawunga', nameEn: 'Maize Flour', category: 'flour', unit: 'Kg', minThreshold: 400, currentStock: 1200, unitCostRwf: 950 },
  { id: 'prod_oil_04', code: 'STK-OIL-04', nameRw: 'Amavuta yo Guteka', nameEn: 'Cooking Oil', category: 'oil', unit: 'Litres', minThreshold: 100, currentStock: 240, unitCostRwf: 2600 },
  { id: 'prod_potatoes_05', code: 'STK-POT-05', nameRw: 'Ibirayi', nameEn: 'Irish Potatoes', category: 'tuber', unit: 'Kg', minThreshold: 500, currentStock: 140, unitCostRwf: 550 },
  { id: 'prod_sugar_06', code: 'STK-SUG-06', nameRw: 'Isukari', nameEn: 'Sugar', category: 'sweetener', unit: 'Kg', minThreshold: 80, currentStock: 180, unitCostRwf: 1800 },
  { id: 'prod_salt_07', code: 'STK-SLT-07', nameRw: 'Umunyu', nameEn: 'Iodized Salt', category: 'spice', unit: 'Kg', minThreshold: 50, currentStock: 110, unitCostRwf: 400 }
];

let transactions = [
  {
    id: 'tx_01',
    transactionNumber: 'TX-IN-2026-001',
    productId: 'prod_rice_01',
    productName: 'Rice (Umuceri)',
    type: 'stock_in',
    quantity: 500,
    unit: 'Kg',
    unitPriceRwf: 1400,
    totalPriceRwf: 700000,
    supplierName: 'Agro-Supply Ltd Burera',
    performedByUserName: 'Clarisse Mukakarisa, CPA',
    performedByRole: 'accountant',
    createdAt: '2026-10-25T08:30:00Z'
  },
  {
    id: 'tx_02',
    transactionNumber: 'TX-OUT-2026-002',
    productId: 'prod_rice_01',
    productName: 'Rice (Umuceri)',
    type: 'stock_out',
    quantity: 60,
    unit: 'Kg',
    mealCategory: 'lunch',
    performedByUserName: 'Jean-Claude Habimana',
    performedByRole: 'animator',
    createdAt: '2026-10-31T06:45:00Z'
  }
];

let emergencyOverrideActive = false;

export const getProducts = (req, res) => {
  res.json({ success: true, count: products.length, products });
};

export const getTransactions = (req, res) => {
  res.json({ success: true, count: transactions.length, transactions });
};

export const recordStockIn = async (req, res) => {
  const { productId, quantity, unitCostRwf, supplierId, supplierName, deliveryDate, expirationDate, invoiceNotes } = req.body;
  const product = products.find(p => p.id === productId);

  if (!product) return res.status(404).json({ success: false, message: 'Product not found.' });

  const qty = Number(quantity);
  const cost = Number(unitCostRwf) || product.unitCostRwf;
  product.currentStock += qty;

  const txNumber = `TX-IN-${Date.now().toString().slice(-6)}`;
  const newTx = {
    id: `tx_${Date.now()}`,
    transactionNumber: txNumber,
    productId,
    productName: `${product.nameEn} (${product.nameRw})`,
    type: 'stock_in',
    quantity: qty,
    unit: product.unit,
    unitPriceRwf: cost,
    totalPriceRwf: qty * cost,
    supplierId,
    supplierName: supplierName || 'Registered Supplier',
    deliveryDate,
    expirationDate,
    purposeNotes: invoiceNotes,
    performedByUserId: req.user.id,
    performedByUserName: req.user.fullName,
    performedByRole: req.user.role,
    createdAt: new Date().toISOString()
  };

  transactions.unshift(newTx);

  await logActivity({
    action: 'STOCK_IN_RECORDED',
    category: 'stock_in',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Stock In: ${qty} ${product.unit} of ${product.nameEn}. New balance: ${product.currentStock} ${product.unit}`,
    ipAddress: req.ip
  });

  res.status(201).json({ success: true, transaction: newTx, product });
};

export const recordStockOut = async (req, res) => {
  const { productId, quantity, mealCategory, purposeNotes } = req.body;
  const product = products.find(p => p.id === productId);

  if (!product) return res.status(404).json({ success: false, message: 'Product not found.' });

  const qty = Number(quantity);
  if (product.currentStock < qty) {
    return res.status(400).json({
      success: false,
      message: `Insufficient stock: Requested ${qty} ${product.unit}, but only ${product.currentStock} ${product.unit} available.`
    });
  }

  product.currentStock -= qty;

  const txNumber = `TX-OUT-${Date.now().toString().slice(-6)}`;
  const newTx = {
    id: `tx_${Date.now()}`,
    transactionNumber: txNumber,
    productId,
    productName: `${product.nameEn} (${product.nameRw})`,
    type: 'stock_out',
    quantity: qty,
    unit: product.unit,
    mealCategory: mealCategory || 'lunch',
    purposeNotes,
    performedByUserId: req.user.id,
    performedByUserName: req.user.fullName,
    performedByRole: req.user.role,
    createdAt: new Date().toISOString()
  };

  transactions.unshift(newTx);

  await logActivity({
    action: 'STOCK_OUT_RECORDED',
    category: 'stock_out',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Stock Out for ${mealCategory}: ${qty} ${product.unit} of ${product.nameEn}. Remaining: ${product.currentStock} ${product.unit}`,
    ipAddress: req.ip
  });

  res.status(201).json({ success: true, transaction: newTx, product });
};

export const recordCorrection = async (req, res) => {
  const { productId, deltaQuantity, correctionReason } = req.body;
  const product = products.find(p => p.id === productId);

  if (!product) return res.status(404).json({ success: false, message: 'Product not found.' });
  if (!correctionReason) return res.status(400).json({ success: false, message: 'Audit explanation is required.' });

  const delta = Number(deltaQuantity);
  product.currentStock = Math.max(0, product.currentStock + delta);

  const tx = {
    id: `tx_corr_${Date.now()}`,
    transactionNumber: `TX-CORR-${Date.now().toString().slice(-6)}`,
    productId,
    productName: `${product.nameEn} (${product.nameRw})`,
    type: 'correction',
    quantity: delta,
    unit: product.unit,
    correctionReason,
    performedByUserId: req.user.id,
    performedByUserName: req.user.fullName,
    performedByRole: req.user.role,
    createdAt: new Date().toISOString()
  };

  transactions.unshift(tx);

  await logActivity({
    action: 'STOCK_CORRECTION_AUDITED',
    category: 'stock_schedule',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Audited Correction: Adjusted ${delta > 0 ? '+' : ''}${delta} ${product.unit} on ${product.nameEn}. Reason: ${correctionReason}`,
    ipAddress: req.ip
  });

  res.json({ success: true, transaction: tx, product });
};

export const toggleEmergencyOverride = async (req, res) => {
  const { active, reason } = req.body;
  emergencyOverrideActive = Boolean(active);

  await logActivity({
    action: emergencyOverrideActive ? 'EMERGENCY_OVERRIDE_ENABLED' : 'EMERGENCY_OVERRIDE_DISABLED',
    category: 'stock_schedule',
    userId: req.user.id,
    userName: req.user.fullName,
    userRole: req.user.role,
    details: `Director set emergency override to ${emergencyOverrideActive ? 'ACTIVE' : 'INACTIVE'}. Justification: ${reason || 'N/A'}`,
    ipAddress: req.ip
  });

  res.json({ success: true, emergencyOverrideActive });
};

export default {
  getProducts,
  getTransactions,
  recordStockIn,
  recordStockOut,
  recordCorrection,
  toggleEmergencyOverride
};
