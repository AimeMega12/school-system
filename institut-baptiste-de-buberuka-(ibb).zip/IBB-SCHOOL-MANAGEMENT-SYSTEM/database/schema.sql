-- ==============================================================================
-- INSTITUT BAPTISTE DE BUBERUKA (IBB) - RWANDA
-- Complete Relational Database Schema & Seeding (MySQL 8.0+ / MariaDB)
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `ibb_school_db` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `ibb_school_db`;

-- ------------------------------------------------------------------------------
-- 1. ROLES, USERS & GRANULAR PERMISSIONS (WITH OTP & BCRYPT AUTH)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
('director', 'School Director (Super Admin)', 'Full administrative jurisdiction over admissions, inventory, staff accounts, grading policies, and schedules'),
('accountant', 'School Accountant', 'Manages products, performs main Stock In, supplier oversight, thresholds, and financial records as granted'),
('animator', 'Stock Animator', 'Performs daily Stock Out within authorized meal hours, views food stock availability and personal history')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `username` VARCHAR(100) NOT NULL UNIQUE,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL, -- bcrypt hashed
  `full_name` VARCHAR(255) NOT NULL,
  `role_id` VARCHAR(50) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `avatar_url` TEXT NULL,
  `two_factor_enabled` BOOLEAN DEFAULT TRUE,
  `two_factor_secret` VARCHAR(100) NOT NULL,
  `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  `last_login_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX `idx_users_role` ON `users`(`role_id`);
CREATE INDEX `idx_users_status` ON `users`(`status`);

CREATE TABLE IF NOT EXISTS `user_permissions` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `user_id` VARCHAR(64) NOT NULL,
  `permission_key` VARCHAR(50) NOT NULL,
  `granted_by` VARCHAR(64) NOT NULL,
  `granted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `uniq_user_perm` (`user_id`, `permission_key`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 1B. TWO-FACTOR AUTHENTICATION & SECURE EMAIL OTP STORE
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `user_two_factor_otps` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `user_id` VARCHAR(64) NOT NULL,
  `otp_hash` VARCHAR(255) NOT NULL, -- Cryptographically secure SHA-256 hash with salt
  `salt` VARCHAR(64) NOT NULL,
  `purpose` ENUM('login', 'password_change') NOT NULL DEFAULT 'login',
  `attempt_count` INT NOT NULL DEFAULT 0,
  `max_attempts` INT NOT NULL DEFAULT 5,
  `is_used` BOOLEAN NOT NULL DEFAULT FALSE,
  `used_at` TIMESTAMP NULL,
  `ip_address` VARCHAR(45) NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX `idx_otp_user` ON `user_two_factor_otps`(`user_id`);
CREATE INDEX `idx_otp_expires` ON `user_two_factor_otps`(`expires_at`);
CREATE INDEX `idx_otp_status` ON `user_two_factor_otps`(`is_used`, `expires_at`);

-- ------------------------------------------------------------------------------
-- 2. ACADEMIC GRADING POLICIES & ADMISSION RULES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `academic_grading_policies` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `academic_year` VARCHAR(20) NOT NULL, -- e.g. '2026/2027'
  `minimum_admission_percentage` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
  `minimum_passing_percentage` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
  `boarding_eligibility_percentage` DECIMAL(5,2) NOT NULL DEFAULT 80.00,
  `rules_per_level` JSON NOT NULL, -- JSON rules for L3, L4, L5
  `grade_ranges` JSON NOT NULL, -- Distinction, Credit, Pass, Fail thresholds
  `effective_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `approved_students` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `application_id` VARCHAR(64) NOT NULL,
  `student_name` VARCHAR(255) NOT NULL,
  `application_number` VARCHAR(50) NOT NULL UNIQUE,
  `admission_level` ENUM('L3', 'L4', 'L5') NOT NULL,
  `department` VARCHAR(50) NOT NULL,
  `academic_score` DECIMAL(5,2) NOT NULL,
  `approval_date` TIMESTAMP NOT NULL,
  `approved_by` VARCHAR(255) NOT NULL,
  `boarding_status` ENUM('boarding_scholar', 'day_scholar') DEFAULT 'day_scholar',
  `academic_year` VARCHAR(20) NOT NULL,
  `status` ENUM('enrolled', 'completed', 'transferred', 'dismissed') DEFAULT 'enrolled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE INDEX `idx_appr_level` ON `approved_students`(`admission_level`);
CREATE INDEX `idx_appr_year` ON `approved_students`(`academic_year`);

-- ------------------------------------------------------------------------------
-- 3. STUDENT ADMISSIONS MODULE (L3 to L5)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `code` VARCHAR(20) NOT NULL UNIQUE,
  `name_en` VARCHAR(150) NOT NULL,
  `name_rw` VARCHAR(150) NOT NULL,
  `level` VARCHAR(20) DEFAULT 'L3-L5',
  `duration_years` INT DEFAULT 3,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO `departments` (`id`, `code`, `name_en`, `name_rw`) VALUES
('software_development', 'SOD', 'Software Development', 'Ikoranabuhanga rya Porogaramu'),
('automobile_technology', 'AUT', 'Automobile Technology', 'Ibinyabiziga n\'Imodoka')
ON DUPLICATE KEY UPDATE `name_en`=VALUES(`name_en`);

CREATE TABLE IF NOT EXISTS `applications` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `tracking_number` VARCHAR(50) NOT NULL UNIQUE,
  `full_name` VARCHAR(255) NOT NULL,
  `father_name` VARCHAR(255) NOT NULL,
  `mother_name` VARCHAR(255) NOT NULL,
  `date_of_birth` DATE NOT NULL,
  `gender` ENUM('male', 'female') NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `email` VARCHAR(255) NULL,
  `residential_address` TEXT NOT NULL,
  `district` VARCHAR(100) NOT NULL,
  `sector` VARCHAR(100) NOT NULL,
  `applying_level` ENUM('L3', 'L4', 'L5') NOT NULL DEFAULT 'L3',
  `department_id` VARCHAR(50) NOT NULL,
  `previous_school` VARCHAR(255) NOT NULL,
  `previous_academic_level` VARCHAR(100) NULL, -- 'Senior 3', 'Level 3 TVET', etc.
  `academic_score_percentage` DECIMAL(5,2) NOT NULL DEFAULT 50.00,
  `s3_aggregate_score` INT NOT NULL DEFAULT 20,
  `result_slip_file_name` VARCHAR(255) NOT NULL,
  `result_slip_url` TEXT NOT NULL,
  `passport_photo_file_name` VARCHAR(255) NOT NULL,
  `passport_photo_url` TEXT NOT NULL,
  `status` ENUM('pending', 'eligible', 'under_review', 'approved', 'rejected', 'automatically_rejected') DEFAULT 'pending',
  `auto_rejection_reason` TEXT NULL,
  `is_eligible_for_boarding` BOOLEAN DEFAULT FALSE,
  `academic_year` VARCHAR(20) DEFAULT '2026/2027',
  `reviewed_at` TIMESTAMP NULL,
  `reviewed_by` VARCHAR(255) NULL,
  `review_notes` TEXT NULL,
  `rejection_reason` TEXT NULL,
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX `idx_app_tracking` ON `applications`(`tracking_number`);
CREATE INDEX `idx_app_status` ON `applications`(`status`);
CREATE INDEX `idx_app_level` ON `applications`(`applying_level`);

-- ------------------------------------------------------------------------------
-- 4. OTP SETTINGS & MULTI-CHANNEL DELIVERY LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `otp_settings` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `mode` ENUM('email_only', 'sms_only', 'email_and_sms') NOT NULL DEFAULT 'email_only',
  `code_expiry_minutes` INT NOT NULL DEFAULT 10,
  `sms_provider_status` ENUM('connected', 'disconnected', 'error') DEFAULT 'connected',
  `whatsapp_provider_status` ENUM('connected', 'disconnected', 'error') DEFAULT 'connected',
  `email_smtp_status` ENUM('connected', 'disconnected', 'error') DEFAULT 'connected',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `notification_delivery_logs` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `channel` ENUM('email', 'sms', 'whatsapp', 'in_app') NOT NULL,
  `recipient` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `status` ENUM('pending', 'sent', 'delivered', 'failed') NOT NULL DEFAULT 'delivered',
  `provider_response` TEXT NULL,
  `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE INDEX `idx_deliv_channel` ON `notification_delivery_logs`(`channel`);
CREATE INDEX `idx_deliv_status` ON `notification_delivery_logs`(`status`);
CREATE INDEX `idx_deliv_time` ON `notification_delivery_logs`(`timestamp`);

-- ------------------------------------------------------------------------------
-- 5. INTELLIGENT FOOD INVENTORY & COMMODITIES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `contact_person` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `email` VARCHAR(255) NULL,
  `address` TEXT NOT NULL,
  `tin_number` VARCHAR(50) NOT NULL UNIQUE,
  `rating` INT DEFAULT 5,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `name_rw` VARCHAR(150) NOT NULL,
  `name_en` VARCHAR(150) NOT NULL,
  `category` ENUM('cereal', 'flour', 'oil', 'vegetable', 'tuber', 'sweetener', 'spice', 'other') NOT NULL,
  `unit` VARCHAR(20) NOT NULL, -- 'Kg', 'Litres', 'Pieces'
  `min_threshold` DECIMAL(12,2) NOT NULL DEFAULT 100.00,
  `target_capacity` DECIMAL(12,2) NOT NULL DEFAULT 1000.00,
  `unit_cost_rwf` DECIMAL(12,2) NOT NULL DEFAULT 1000.00,
  `current_stock` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `shelf_life_days` INT DEFAULT 180,
  `last_restocked_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `chk_current_stock_positive` CHECK (`current_stock` >= 0)
) ENGINE=InnoDB;

CREATE INDEX `idx_prod_code` ON `products`(`code`);
CREATE INDEX `idx_prod_category` ON `products`(`category`);

-- ------------------------------------------------------------------------------
-- 6. STOCK TRANSACTIONS & AUDITABLE CORRECTIONS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_transactions` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `transaction_number` VARCHAR(50) NOT NULL UNIQUE,
  `product_id` VARCHAR(64) NOT NULL,
  `type` ENUM('stock_in', 'stock_out', 'correction') NOT NULL,
  `quantity` DECIMAL(12,2) NOT NULL,
  `unit` VARCHAR(20) NOT NULL,
  `unit_price_rwf` DECIMAL(12,2) NULL,
  `total_price_rwf` DECIMAL(12,2) NULL,
  `supplier_id` VARCHAR(64) NULL,
  `delivery_date` DATE NULL,
  `expiration_date` DATE NULL,
  `meal_category` ENUM('breakfast', 'lunch', 'dinner', 'special_event') NULL,
  `purpose_notes` TEXT NULL,
  `performed_by_user_id` VARCHAR(64) NOT NULL,
  `performed_by_role` VARCHAR(50) NOT NULL,
  `is_delegated_stock_in` BOOLEAN DEFAULT FALSE,
  `is_emergency_override` BOOLEAN DEFAULT FALSE,
  `correction_original_tx_id` VARCHAR(64) NULL,
  `correction_reason` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON UPDATE CASCADE,
  FOREIGN KEY (`supplier_id`) REFERENCES `suppliers`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`performed_by_user_id`) REFERENCES `users`(`id`) ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE INDEX `idx_tx_type` ON `stock_transactions`(`type`);
CREATE INDEX `idx_tx_product` ON `stock_transactions`(`product_id`);
CREATE INDEX `idx_tx_date` ON `stock_transactions`(`created_at`);

-- ------------------------------------------------------------------------------
-- 7. STOCK WORKING HOURS & EMERGENCY OVERRIDES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_schedules` (
  `id` VARCHAR(50) NOT NULL PRIMARY KEY,
  `morning_start` TIME NOT NULL DEFAULT '06:00:00',
  `morning_end` TIME NOT NULL DEFAULT '08:00:00',
  `evening_start` TIME NOT NULL DEFAULT '17:00:00',
  `evening_end` TIME NOT NULL DEFAULT '19:00:00',
  `timezone` VARCHAR(50) DEFAULT 'Africa/Kigali',
  `enforce_hours` BOOLEAN DEFAULT TRUE,
  `emergency_override_active` BOOLEAN DEFAULT FALSE,
  `override_reason` TEXT NULL,
  `override_set_by` VARCHAR(255) NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 8. TEMPORARY STOCK DELEGATIONS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_permission_delegations` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `granted_to_user_id` VARCHAR(64) NOT NULL,
  `granted_by_user_id` VARCHAR(64) NOT NULL,
  `permission` VARCHAR(50) DEFAULT 'stock_in',
  `starts_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NOT NULL,
  `status` ENUM('active', 'revoked', 'expired') DEFAULT 'active',
  `reason` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`granted_to_user_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`granted_by_user_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB;

-- ------------------------------------------------------------------------------
-- 9. NOTIFICATIONS & IMMUTABLE SYSTEM AUDIT LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `title_en` VARCHAR(255) NOT NULL,
  `title_rw` VARCHAR(255) NOT NULL,
  `message_en` TEXT NOT NULL,
  `message_rw` TEXT NOT NULL,
  `type` ENUM('info', 'success', 'warning', 'alert') DEFAULT 'info',
  `category` VARCHAR(50) NOT NULL,
  `target_roles` JSON NOT NULL, -- JSON array of roles e.g. ["director", "accountant"]
  `read_by_users` JSON NOT NULL, -- JSON array of user IDs
  `related_id` VARCHAR(64) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `activity_audit_logs` (
  `id` VARCHAR(64) NOT NULL PRIMARY KEY,
  `action` VARCHAR(100) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `user_id` VARCHAR(64) NOT NULL,
  `user_name` VARCHAR(255) NOT NULL,
  `user_role` VARCHAR(50) NOT NULL,
  `details` TEXT NOT NULL,
  `ip_address` VARCHAR(45) NULL,
  `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE INDEX `idx_audit_user` ON `activity_audit_logs`(`user_id`);
CREATE INDEX `idx_audit_category` ON `activity_audit_logs`(`category`);
CREATE INDEX `idx_audit_timestamp` ON `activity_audit_logs`(`timestamp`);
