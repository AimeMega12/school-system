/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import {
  User as UserIcon,
  Camera,
  Lock,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Mail,
  Smartphone,
  Save,
  Copy,
  Check
} from 'lucide-react';

export const DirectorProfilePage: React.FC = () => {
  const { t, language } = useLanguage();
  const { user, updateProfile, requestPasswordChangeOTP, verifyAndChangePassword } = useAuth();
  const { addNotification } = useNotifications();

  // Profile Edit State
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [email, setEmail] = useState(user?.email || '');
  const [avatarPreview, setAvatarPreview] = useState(user?.avatarUrl || '');
  const [profileSaveSuccess, setProfileSaveSuccess] = useState(false);
  const [profileError, setProfileError] = useState('');

  // Password Change State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [expectedDemoOtp, setExpectedDemoOtp] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [copiedOtp, setCopiedOtp] = useState(false);

  // Handle Photo Upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 4 * 1024 * 1024) {
        setProfileError('Photo size must be smaller than 4MB.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setAvatarPreview(base64);
        if (user) {
          updateProfile({ avatarUrl: base64 });
          setProfileSaveSuccess(true);
          setTimeout(() => setProfileSaveSuccess(false), 2500);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Profile Update
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError('');

    if (!fullName.trim() || !email.trim()) {
      setProfileError('Full Name and Email are required.');
      return;
    }

    updateProfile({
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      avatarUrl: avatarPreview
    });

    setProfileSaveSuccess(true);
    setTimeout(() => setProfileSaveSuccess(false), 2500);

    addNotification({
      title: 'Profile Updated',
      titleRw: 'Umwirondoro Wavuguruwe',
      message: 'Administrative profile details updated successfully.',
      messageRw: 'Amakuru y’umwirondoro yavuguruwe neza.',
      type: 'success',
      category: 'admission',
      targetRoles: ['director']
    });
  };

  // Step 1: Request Password OTP
  const handleRequestPasswordOtp = () => {
    setPasswordError('');

    if (!user) return;

    if (!newPassword || newPassword.length < 8) {
      setPasswordError('New password must be at least 8 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('New password and confirmation do not match.');
      return;
    }

    const res = requestPasswordChangeOTP(user.id);
    if (res.success && res.otpCode) {
      setOtpSent(true);
      setExpectedDemoOtp(res.otpCode);
      setEnteredOtp(res.otpCode); // autofill for demo ease
    } else {
      setPasswordError(res.error || 'Failed to dispatch verification OTP.');
    }
  };

  // Step 2: Commit Password with OTP
  const handleVerifyOtpAndChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');

    if (!user) return;

    if (!enteredOtp) {
      setPasswordError('Please enter the 6-digit verification code.');
      return;
    }

    const res = verifyAndChangePassword(user.id, enteredOtp, newPassword);
    if (res.success) {
      setPasswordChangeSuccess(true);
      setOtpSent(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setEnteredOtp('');
      setTimeout(() => setPasswordChangeSuccess(false), 3500);
    } else {
      setPasswordError(res.error || 'Invalid verification OTP.');
    }
  };

  const handleCopyDemoOtp = () => {
    if (expectedDemoOtp) {
      navigator.clipboard.writeText(expectedDemoOtp);
      setCopiedOtp(true);
      setTimeout(() => setCopiedOtp(false), 2000);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            Account Security & Identity
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            {t('profileTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('profileSub')}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Role: {user?.role.toUpperCase()}</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Avatar & Quick Info */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm flex flex-col items-center text-center">
          <div className="relative mb-4 group">
            <img
              src={avatarPreview || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300'}
              alt={user?.fullName}
              className="w-32 h-32 rounded-2xl object-cover border-4 border-emerald-500/20 shadow-md"
            />
            <label className="absolute inset-0 rounded-2xl bg-black/50 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white cursor-pointer transition-opacity">
              <Camera className="w-6 h-6 mb-1" />
              <span className="text-[10px] font-bold uppercase">{t('uploadPhotoBtn')}</span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </label>
          </div>

          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            {user?.fullName}
          </h3>
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
            {user?.role === 'director' ? 'School Director · Super Admin' : user?.role.toUpperCase()}
          </p>
          <span className="text-[11px] text-slate-400 font-mono mt-1">
            @{user?.username}
          </span>

          <label className="mt-4 w-full py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer flex items-center justify-center gap-2 transition-colors">
            <Camera className="w-3.5 h-3.5" />
            <span>{t('uploadPhotoBtn')}</span>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handlePhotoUpload}
              className="hidden"
            />
          </label>

          <div className="w-full mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 text-left text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-500">Account Status:</span>
              <span className="font-bold text-emerald-600 uppercase">{user?.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Two-Factor Auth:</span>
              <span className="font-bold text-blue-600">Active (TOTP)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Institution:</span>
              <span className="font-medium text-slate-900 dark:text-white">IBB Rwanda</span>
            </div>
          </div>
        </div>

        {/* Right Column: Edit Profile & Password Change */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Edit Profile Details */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <div className="flex items-center gap-2 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
              <UserIcon className="w-4 h-4 text-emerald-600" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Personal & Contact Details
              </h3>
            </div>

            {profileSaveSuccess && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Profile details saved successfully.</span>
              </div>
            )}

            {profileError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{profileError}</span>
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Full Legal Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Official Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Phone Number (+250 Rwanda)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Assigned Role
                  </label>
                  <div className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/80 text-xs font-mono font-bold text-slate-600 dark:text-slate-400">
                    {user?.role.toUpperCase()} (Fixed)
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-sm transition-all"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Update Profile</span>
                </button>
              </div>
            </form>
          </div>

          {/* Email-Verified Password Update */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
            <div className="flex items-center gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
              <Lock className="w-4 h-4 text-blue-600" />
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {t('changePasswordTitle')}
                </h3>
                <p className="text-xs text-slate-500">
                  Password changes require mandatory 6-digit email OTP verification.
                </p>
              </div>
            </div>

            {passwordChangeSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Password updated successfully. Active sessions re-secured.</span>
              </div>
            )}

            {passwordError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            {!otpSent ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      {t('newPasswordLabel')} *
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Minimum 8 characters"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                      {t('confirmPasswordLabel')} *
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Re-enter new password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleRequestPasswordOtp}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-blue-600 hover:bg-blue-500 shadow-sm transition-all"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{t('requestPasswordOtpBtn')}</span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleVerifyOtpAndChangePassword} className="space-y-4">
                <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-xs text-blue-900 dark:text-blue-300 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center gap-1.5">
                      <Mail className="w-4 h-4 text-blue-600" />
                      Verification Code Sent to {user?.email}
                    </span>
                    {expectedDemoOtp && (
                      <button
                        type="button"
                        onClick={handleCopyDemoOtp}
                        className="text-[11px] text-blue-700 dark:text-blue-300 hover:underline flex items-center gap-1 font-mono font-bold"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedOtp ? 'Copied' : `Demo Code: ${expectedDemoOtp}`}</span>
                      </button>
                    )}
                  </div>
                  <p className="opacity-90">
                    Please input the 6-digit confirmation code dispatched to your registered email to authorize this security update.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    {t('enterPasswordOtpLabel')} *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={enteredOtp}
                    onChange={(e) => setEnteredOtp(e.target.value)}
                    placeholder="000000"
                    className="w-full text-center text-xl font-mono tracking-widest px-3.5 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-sm transition-all"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{t('confirmPasswordChangeBtn')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
