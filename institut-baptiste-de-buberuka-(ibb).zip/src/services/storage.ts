/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  User,
  UserRole,
  StudentApplication,
  Product,
  StockTransaction,
  Supplier,
  StockSchedule,
  StockPermissionDelegation,
  NotificationItem,
  AuditLog,
  AcademicGradingPolicy,
  ApprovedStudent,
  OTPSettings,
  NotificationDeliveryLog,
  PermissionModule,
  PermissionAction
} from '../types/index.ts';

// Password Validation Interface & Helper
export interface PasswordValidationResult {
  isValid: boolean;
  hasMinLength: boolean;
  hasUpper: boolean;
  hasLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
  score: number;
  strength: 'weak' | 'medium' | 'strong';
  errors: string[];
}

export function validatePasswordStrength(password: string): PasswordValidationResult {
  const pwd = password || '';
  const hasMinLength = pwd.length >= 8;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[^A-Za-z0-9]/.test(pwd);

  const errors: string[] = [];
  if (!hasMinLength) errors.push('Minimum 8 characters');
  if (!hasUpper) errors.push('At least one uppercase letter (A-Z)');
  if (!hasLower) errors.push('At least one lowercase letter (a-z)');
  if (!hasNumber) errors.push('At least one number (0-9)');
  if (!hasSpecial) errors.push('At least one special character (!@#$%^&*...)');

  let score = 0;
  if (hasMinLength) score++;
  if (hasUpper && hasLower) score++;
  if (hasNumber) score++;
  if (hasSpecial) score++;

  let strength: 'weak' | 'medium' | 'strong' = 'weak';
  if (score >= 4 && pwd.length >= 8) {
    strength = 'strong';
  } else if (score >= 2 && pwd.length >= 6) {
    strength = 'medium';
  }

  const isValid = hasMinLength && hasUpper && hasLower && hasNumber && hasSpecial;

  return {
    isValid,
    hasMinLength,
    hasUpper,
    hasLower,
    hasNumber,
    hasSpecial,
    score,
    strength,
    errors
  };
}

// Initial Demo Users with Granular Permissions
const INITIAL_USERS: User[] = [
  {
    id: 'user_director_01',
    username: 'director',
    email: 'tzrdidier@gmail.com',
    fullName: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    role: 'director',
    phone: '+250 788 412 890',
    avatarUrl: '/src/assets/images/ibb_student_life_1793449105656.jpg',
    twoFactorEnabled: true,
    twoFactorSecret: 'KASS-SEC-DIR-991',
    status: 'active',
    permissions: [
      'stock_view',
      'stock_in',
      'stock_out',
      'stock_correction',
      'suppliers',
      'admissions_view',
      'admissions_approve',
      'academic_rules',
      'staff_management',
      'reports_financial',
      'reports_stock',
      'audit_logs',
      'system_settings'
    ],
    createdAt: '2025-01-10T08:00:00Z',
    lastLoginAt: '2026-10-31T05:10:00Z'
  },
  {
    id: 'user_accountant_01',
    username: 'accountant',
    email: 'accountant@kass.ac.rw',
    fullName: 'Clarisse Mukakarisa, CPA',
    role: 'accountant',
    phone: '+250 788 563 219',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
    twoFactorEnabled: true,
    twoFactorSecret: 'KASS-SEC-ACC-442',
    status: 'active',
    permissions: ['stock_view', 'stock_in', 'stock_correction', 'suppliers', 'reports_stock'],
    createdAt: '2025-01-15T09:00:00Z',
    lastLoginAt: '2026-10-30T16:30:00Z'
  },
  {
    id: 'user_animator_01',
    username: 'animator',
    email: 'animator@kass.ac.rw',
    fullName: 'Jean-Claude Habimana',
    role: 'animator',
    phone: '+250 788 901 345',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    twoFactorEnabled: true,
    twoFactorSecret: 'KASS-SEC-ANI-773',
    status: 'active',
    permissions: ['stock_view', 'stock_out'],
    createdAt: '2025-02-01T10:00:00Z',
    lastLoginAt: '2026-10-31T06:15:00Z'
  }
];

// Initial Academic Grading & Admission Policy (Director Configurable)
const INITIAL_ACADEMIC_POLICY: AcademicGradingPolicy = {
  id: 'policy_2026_v1',
  academicYear: '2026/2027',
  minimumAdmissionPercentage: 50.0,
  minimumPassingPercentage: 50.0,
  boardingEligibilityPercentage: 80.0,
  effectiveDate: '2026-01-01',
  rulesPerLevel: [
    {
      level: 'L3',
      minScore: 50.0,
      description: 'Completion of Ordinary Level (Senior 3) with minimum 50% aggregate score.'
    },
    {
      level: 'L4',
      minScore: 55.0,
      description: 'Completion of Level 3 or Senior 4 technical credits with minimum 55% verified marks.'
    },
    {
      level: 'L5',
      minScore: 60.0,
      description: 'Completion of Level 4 or Senior 5 certificate with minimum 60% technical competence.'
    }
  ],
  gradeRanges: [
    {
      grade: 'Distinction (A)',
      labelEn: 'Distinction / Boarding Priority',
      labelRw: 'Amanota Asumba Ayandi / Icumbi',
      minPercentage: 80.0,
      maxPercentage: 100.0,
      standing: 'distinction'
    },
    {
      grade: 'Credit (B)',
      labelEn: 'High Technical Credit',
      labelRw: 'Amanota Meza Cyane',
      minPercentage: 65.0,
      maxPercentage: 79.99,
      standing: 'credit'
    },
    {
      grade: 'Pass (C)',
      labelEn: 'Technical Pass',
      labelRw: 'Yaratsinze bisanzwe',
      minPercentage: 50.0,
      maxPercentage: 64.99,
      standing: 'pass'
    },
    {
      grade: 'Fail (F)',
      labelEn: 'Fail / Repeat Required',
      labelRw: 'Yaratsinzwe / Asabwa Gusibira',
      minPercentage: 0.0,
      maxPercentage: 49.99,
      standing: 'fail_repeat'
    }
  ],
  promotionRequirements: 'Minimum 50% continuous assessment + satisfactory workshop practical skills evaluation.',
  repeatingRequirements: 'Scores below 50% require repeat of academic year or formal pedagogical remediation.',
  updatedAt: '2026-01-15T08:00:00Z',
  updatedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi (Director)'
};

// Initial Configurable OTP Settings
const INITIAL_OTP_SETTINGS: OTPSettings = {
  mode: 'email_only', // Real Email 2FA OTP
  codeExpiryMinutes: 5, // Strictly 5 minutes
  maxAttempts: 5,
  resendCooldownSeconds: 60, // Strictly 60 seconds cooldown
  smsProviderConfigured: true,
  smsProviderName: 'Rwanda Telecom SMS Gateway (+250)',
  emailSmtpConfigured: true,
  whatsAppConfigured: true,
  updatedAt: new Date().toISOString()
};

// Initial Food Products
const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod_umuceri',
    code: 'IBB-FD-01',
    name: 'Umuceri (Rice)',
    nameRw: 'Umuceri',
    nameEn: 'Rice',
    category: 'cereal',
    unit: 'Kg',
    minThreshold: 500,
    targetCapacity: 3000,
    unitCostRwf: 1250,
    currentStock: 1850,
    shelfLifeDays: 365,
    lastRestockedAt: '2026-10-25T10:00:00Z'
  },
  {
    id: 'prod_akawunga',
    code: 'IBB-FD-02',
    name: 'Akawunga (Maize Flour)',
    nameRw: 'Akawunga',
    nameEn: 'Maize Flour',
    category: 'flour',
    unit: 'Kg',
    minThreshold: 600,
    targetCapacity: 4000,
    unitCostRwf: 850,
    currentStock: 2400,
    shelfLifeDays: 180,
    lastRestockedAt: '2026-10-26T14:30:00Z'
  },
  {
    id: 'prod_amavuta',
    code: 'IBB-FD-03',
    name: 'Amavuta yo kurya (Cooking Oil)',
    nameRw: 'Amavuta yo kurya',
    nameEn: 'Cooking Oil',
    category: 'oil',
    unit: 'Litres',
    minThreshold: 120,
    targetCapacity: 800,
    unitCostRwf: 2900,
    currentStock: 340,
    shelfLifeDays: 365,
    lastRestockedAt: '2026-10-20T11:00:00Z'
  },
  {
    id: 'prod_amashu',
    code: 'IBB-FD-04',
    name: 'Amashu (Cabbage)',
    nameRw: 'Amashu',
    nameEn: 'Cabbage',
    category: 'vegetable',
    unit: 'Pieces',
    minThreshold: 100,
    targetCapacity: 600,
    unitCostRwf: 350,
    currentStock: 95,
    shelfLifeDays: 14,
    lastRestockedAt: '2026-10-28T07:15:00Z'
  },
  {
    id: 'prod_ibijumba',
    code: 'IBB-FD-05',
    name: 'Ibijumba (Sweet Potatoes)',
    nameRw: 'Ibijumba',
    nameEn: 'Sweet Potatoes',
    category: 'tuber',
    unit: 'Kg',
    minThreshold: 400,
    targetCapacity: 2500,
    unitCostRwf: 380,
    currentStock: 1200,
    shelfLifeDays: 21,
    lastRestockedAt: '2026-10-27T09:45:00Z'
  },
  {
    id: 'prod_isukari',
    code: 'IBB-FD-06',
    name: 'Isukari (Sugar)',
    nameRw: 'Isukari',
    nameEn: 'Sugar',
    category: 'sweetener',
    unit: 'Kg',
    minThreshold: 150,
    targetCapacity: 1000,
    unitCostRwf: 1600,
    currentStock: 480,
    shelfLifeDays: 730,
    lastRestockedAt: '2026-10-18T16:00:00Z'
  },
  {
    id: 'prod_umunyu',
    code: 'IBB-FD-07',
    name: 'Umunyu (Salt)',
    nameRw: 'Umunyu',
    nameEn: 'Salt',
    category: 'spice',
    unit: 'Kg',
    minThreshold: 50,
    targetCapacity: 300,
    unitCostRwf: 500,
    currentStock: 140,
    shelfLifeDays: 1000,
    lastRestockedAt: '2026-10-15T13:00:00Z'
  }
];

const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup_01',
    name: "Koperative y'Abahinzi ba Karenge (KOAKA)",
    contactPerson: 'Théogène Hategekimana',
    phone: '+250 788 334 112',
    email: 'koaka.karenge@gmail.com',
    address: 'Karenge Center, Rwamagana District',
    tinNumber: '102948172',
    suppliedProducts: ['prod_ibijumba', 'prod_amashu'],
    rating: 5,
    status: 'active',
    createdAt: '2025-01-20T08:00:00Z'
  },
  {
    id: 'sup_02',
    name: 'Ets. Ruhango Grains & Milling Ltd',
    contactPerson: 'Mugisha Patrick',
    phone: '+250 788 772 901',
    email: 'ruhango.grains@supply.rw',
    address: 'Musanze Commercial Area',
    tinNumber: '104882190',
    suppliedProducts: ['prod_umuceri', 'prod_akawunga'],
    rating: 5,
    status: 'active',
    createdAt: '2025-01-25T11:00:00Z'
  },
  {
    id: 'sup_03',
    name: 'Rwanda Oil & Commodities Distributors',
    contactPerson: 'Aline Uwera',
    phone: '+250 788 991 223',
    email: 'info@rwcommodities.co.rw',
    address: 'Kigali Special Economic Zone',
    tinNumber: '100349281',
    suppliedProducts: ['prod_amavuta', 'prod_isukari', 'prod_umunyu'],
    rating: 4,
    status: 'active',
    createdAt: '2025-02-05T14:00:00Z'
  }
];

const INITIAL_SCHEDULE: StockSchedule = {
  id: 'schedule_main',
  morningStart: '06:00',
  morningEnd: '08:00',
  eveningStart: '17:00',
  eveningEnd: '19:00',
  timezone: 'Africa/Kigali',
  enforceHours: true,
  emergencyOverrideActive: false,
  updatedAt: new Date().toISOString()
};

// Initial Applications supporting L3, L4, L5
const INITIAL_APPLICATIONS: StudentApplication[] = [
  {
    id: 'app_01',
    trackingNumber: 'IBB-2026-04192',
    fullName: 'Mugisha Keza Delphine',
    fatherName: 'Hategekimana Jean Pierre',
    motherName: 'Mukamurenzi Chantal',
    dateOfBirth: '2009-04-12',
    gender: 'female',
    phone: '+250 788 123 456',
    email: 'keza.delphine@gmail.com',
    residentialAddress: 'Rwamagana, Karenge, Nyakarambi Cell',
    district: 'Rwamagana',
    sector: 'Karenge',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Karenge',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 76.5,
    s3AggregateScore: 18,
    resultSlipFileName: 's3_exam_slip_keza.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'passport_keza.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
    status: 'eligible',
    submittedAt: '2026-10-29T14:30:00Z',
    academicYear: '2026/2027'
  },
  {
    id: 'app_02',
    trackingNumber: 'IBB-2026-08341',
    fullName: 'Ndoli Eric Fabrice',
    fatherName: 'Nsabimana Celestin',
    motherName: 'Uwimana Christine',
    dateOfBirth: '2008-11-20',
    gender: 'male',
    phone: '+250 788 987 654',
    email: 'ndoli.eric@yahoo.com',
    residentialAddress: 'Gicumbi, Byumba, Kivuruga',
    district: 'Gicumbi',
    sector: 'Byumba',
    applyingLevel: 'L4',
    department: 'automobile_technology',
    previousSchool: 'ES Byumba',
    previousAcademicLevel: 'Level 3 TVET',
    academicScorePercentage: 68.0,
    s3AggregateScore: 22,
    resultSlipFileName: 's3_ndoli_cert.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'ndoli_photo.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300',
    status: 'under_review',
    submittedAt: '2026-10-28T09:15:00Z',
    academicYear: '2026/2027',
    reviewNotes: 'Strong mathematics & physics marks in L3. Candidate for Level 4 automotive workshop.'
  },
  {
    id: 'app_03',
    trackingNumber: 'IBB-2026-01928',
    fullName: 'Uwase Claudine',
    fatherName: 'Bizimana Alphonse',
    motherName: 'Mukamazimpaka Jeanne',
    dateOfBirth: '2009-02-14',
    gender: 'female',
    phone: '+250 788 456 789',
    email: 'uwase.claudine@outlook.com',
    residentialAddress: 'Musanze, Muhoza, Cyivugiza',
    district: 'Musanze',
    sector: 'Muhoza',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Muhoza I',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 86.0,
    s3AggregateScore: 14,
    resultSlipFileName: 's3_slip_uwase.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'passport_uwase.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300',
    status: 'approved',
    submittedAt: '2026-10-25T11:00:00Z',
    reviewedAt: '2026-10-27T16:00:00Z',
    reviewedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    isEligibleForBoarding: true,
    academicYear: '2026/2027',
    reviewNotes: 'Distinction 86.0% verified. Admitted with full boarding scholar status.'
  },
  {
    id: 'app_04',
    trackingNumber: 'IBB-2026-05612',
    fullName: 'Manzi Kevin',
    fatherName: 'Karekezi Vincent',
    motherName: 'Ingabire Beata',
    dateOfBirth: '2008-08-05',
    gender: 'male',
    phone: '+250 788 332 119',
    email: 'kevin.manzi@gmail.com',
    residentialAddress: 'Burera, Rugarama',
    district: 'Burera',
    sector: 'Rugarama',
    applyingLevel: 'L5',
    department: 'automobile_technology',
    previousSchool: 'IPRC Musanze Technical',
    previousAcademicLevel: 'Level 4 TVET',
    academicScorePercentage: 82.5,
    s3AggregateScore: 25,
    resultSlipFileName: 'manzi_l4_cert.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'manzi_photo.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300',
    status: 'approved',
    submittedAt: '2026-10-24T08:30:00Z',
    reviewedAt: '2026-10-26T15:20:00Z',
    reviewedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    isEligibleForBoarding: true,
    academicYear: '2026/2027',
    reviewNotes: 'Accepted for Advanced Technician L5 Automobile Technology.'
  },
  {
    id: 'app_05',
    trackingNumber: 'IBB-2026-09102',
    fullName: 'Kagabo Thierry',
    fatherName: 'Rutayisire Emmanuel',
    motherName: 'Mukashyaka Odette',
    dateOfBirth: '2009-06-18',
    gender: 'male',
    phone: '+250 788 661 229',
    email: 'kagabo.t@gmail.com',
    residentialAddress: 'Burera, Cyanika',
    district: 'Burera',
    sector: 'Cyanika',
    applyingLevel: 'L3',
    department: 'software_development',
    previousSchool: 'GS Cyanika',
    previousAcademicLevel: 'Senior 3',
    academicScorePercentage: 42.0, // Below 50% threshold!
    s3AggregateScore: 48,
    resultSlipFileName: 'kagabo_s3.pdf',
    resultSlipUrl: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
    passportPhotoFileName: 'kagabo.jpg',
    passportPhotoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300',
    status: 'automatically_rejected',
    autoRejectionReason: 'Academic score (42.0%) is below the configured school minimum admission threshold of 50.0%.',
    submittedAt: '2026-10-29T10:00:00Z',
    academicYear: '2026/2027'
  }
];

// Initial Approved Students Register
const INITIAL_APPROVED_STUDENTS: ApprovedStudent[] = [
  {
    id: 'appr_01',
    applicationId: 'app_03',
    studentName: 'Uwase Claudine',
    applicationNumber: 'IBB-2026-01928',
    admissionLevel: 'L3',
    department: 'software_development',
    academicScore: 86.0,
    approvalDate: '2026-10-27T16:00:00Z',
    approvedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    boardingStatus: 'boarding_scholar',
    academicYear: '2026/2027',
    status: 'enrolled'
  },
  {
    id: 'appr_02',
    applicationId: 'app_04',
    studentName: 'Manzi Kevin',
    applicationNumber: 'IBB-2026-05612',
    admissionLevel: 'L5',
    department: 'automobile_technology',
    academicScore: 82.5,
    approvalDate: '2026-10-26T15:20:00Z',
    approvedBy: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    boardingStatus: 'boarding_scholar',
    academicYear: '2026/2027',
    status: 'enrolled'
  }
];

// Initial Notification Delivery Logs
const INITIAL_DELIVERY_LOGS: NotificationDeliveryLog[] = [
  {
    id: 'deliv_01',
    channel: 'sms',
    recipient: '+250 788 456 789',
    subject: 'KASS Admission Approved',
    content: 'Dear Uwase Claudine, Congratulations! Your admission to Karenge Adventist Secondary School for Software Development L3 has been APPROVED by the School Director.',
    status: 'delivered',
    providerResponse: 'DELIVERED_RWA_GATEWAY_OK',
    timestamp: '2026-10-27T16:05:00Z'
  },
  {
    id: 'deliv_02',
    channel: 'whatsapp',
    recipient: '+250 788 332 119',
    subject: 'Official KASS Acceptance Notice',
    content: 'Karenge Adventist Secondary School: Dear Manzi Kevin, you have been admitted into Level 5 Automobile Technology (Tracking: KASS-2026-05612).',
    status: 'delivered',
    providerResponse: 'WA_CLOUD_MSG_ID_99412',
    timestamp: '2026-10-26T15:25:00Z'
  },
  {
    id: 'deliv_03',
    channel: 'email',
    recipient: 'tzrdidier@gmail.com',
    subject: 'Stock In Alert: +1000 Kg Rice',
    content: 'Accountant Clarisse Mukakarisa recorded a consignment of 1000 Kg Rice from Ets. Ruhango Grains & Milling Ltd.',
    status: 'delivered',
    providerResponse: 'SMTP_250_MESSAGE_ACCEPTED',
    timestamp: '2026-10-25T10:02:00Z'
  }
];

const INITIAL_TRANSACTIONS: StockTransaction[] = [
  {
    id: 'tx_01',
    transactionNumber: 'TX-IN-2026-0081',
    productId: 'prod_umuceri',
    productName: 'Umuceri (Rice)',
    type: 'stock_in',
    quantity: 1000,
    unit: 'Kg',
    unitPriceRwf: 1250,
    totalPriceRwf: 1250000,
    supplierId: 'sup_02',
    supplierName: 'Ets. Ruhango Grains & Milling Ltd',
    deliveryDate: '2026-10-25',
    expirationDate: '2027-10-25',
    purposeNotes: 'Monthly boarding food supply consignment',
    performedByUserId: 'user_accountant_01',
    performedByUserName: 'Clarisse Mukakarisa, CPA',
    performedByRole: 'accountant',
    createdAt: '2026-10-25T10:00:00Z'
  },
  {
    id: 'tx_02',
    transactionNumber: 'TX-IN-2026-0082',
    productId: 'prod_akawunga',
    productName: 'Akawunga (Maize Flour)',
    type: 'stock_in',
    quantity: 1500,
    unit: 'Kg',
    unitPriceRwf: 850,
    totalPriceRwf: 1275000,
    supplierId: 'sup_02',
    supplierName: 'Ets. Ruhango Grains & Milling Ltd',
    deliveryDate: '2026-10-26',
    expirationDate: '2027-04-26',
    purposeNotes: 'Consignment for porridge and posho lunches',
    performedByUserId: 'user_accountant_01',
    performedByUserName: 'Clarisse Mukakarisa, CPA',
    performedByRole: 'accountant',
    createdAt: '2026-10-26T14:30:00Z'
  },
  {
    id: 'tx_03',
    transactionNumber: 'TX-OUT-2026-0120',
    productId: 'prod_umuceri',
    productName: 'Umuceri (Rice)',
    type: 'stock_out',
    quantity: 65,
    unit: 'Kg',
    mealCategory: 'lunch',
    purposeNotes: 'Lunch service for 650 boarding students',
    performedByUserId: 'user_animator_01',
    performedByUserName: 'Jean-Claude Habimana',
    performedByRole: 'animator',
    createdAt: '2026-10-30T07:15:00Z'
  },
  {
    id: 'tx_04',
    transactionNumber: 'TX-OUT-2026-0121',
    productId: 'prod_amavuta',
    productName: 'Amavuta yo kurya (Cooking Oil)',
    type: 'stock_out',
    quantity: 8,
    unit: 'Litres',
    mealCategory: 'lunch',
    purposeNotes: 'Cooking oil ration for vegetable and bean stew',
    performedByUserId: 'user_animator_01',
    performedByUserName: 'Jean-Claude Habimana',
    performedByRole: 'animator',
    createdAt: '2026-10-30T07:25:00Z'
  },
  {
    id: 'tx_05',
    transactionNumber: 'TX-OUT-2026-0122',
    productId: 'prod_akawunga',
    productName: 'Akawunga (Maize Flour)',
    type: 'stock_out',
    quantity: 75,
    unit: 'Kg',
    mealCategory: 'breakfast',
    purposeNotes: 'Morning nutritious fortified porridge for students',
    performedByUserId: 'user_animator_01',
    performedByUserName: 'Jean-Claude Habimana',
    performedByRole: 'animator',
    createdAt: '2026-10-31T06:30:00Z'
  }
];

const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log_01',
    action: 'USER_LOGIN_OTP',
    category: 'auth',
    userId: 'user_director_01',
    userName: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    userRole: 'director',
    details: 'Successful login with verified OTP token',
    ipAddress: '197.243.34.82',
    timestamp: '2026-10-31T05:10:00Z'
  },
  {
    id: 'log_02',
    action: 'ADMISSION_APPROVED',
    category: 'admission',
    userId: 'user_director_01',
    userName: 'Rev. Dr. Emmanuel Nshimyumuremyi',
    userRole: 'director',
    details: 'Director approved candidate Uwase Claudine (IBB-2026-01928) for Software Development L3',
    ipAddress: '197.243.34.82',
    timestamp: '2026-10-27T16:00:00Z'
  },
  {
    id: 'log_03',
    action: 'ADMISSION_AUTO_REJECTED',
    category: 'admission',
    userId: 'system_evaluator',
    userName: 'System Admission Engine',
    userRole: 'director',
    details: 'Application IBB-2026-09102 (Kagabo Thierry) automatically rejected: 42.0% is below 50.0% minimum threshold.',
    ipAddress: '127.0.0.1',
    timestamp: '2026-10-29T10:00:01Z'
  }
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_01',
    title: 'Low Stock Alert: Amashu (Cabbage)',
    titleRw: 'Integuza: Amashu yageze ku gipimo cyo hasi',
    message: 'Current stock of Cabbage (95 Pieces) is below minimum safety threshold (100 Pieces).',
    messageRw: 'Amashu ari mu bubiko (Ibice 95) ari munsi y’ingano ntarengwa yo kwitondera (Ibice 100).',
    type: 'warning',
    category: 'low_stock',
    targetRoles: ['director', 'accountant'],
    readBy: [],
    relatedId: 'prod_amashu',
    createdAt: '2026-10-30T18:00:00Z'
  },
  {
    id: 'notif_02',
    title: 'New Student Admission Application (L3)',
    titleRw: 'Ubusabe Bushya bwo Kwiga Bwakiriwe (L3)',
    message: 'Candidate Mugisha Keza Delphine applied for Software Development L3 (Score: 76.5%).',
    messageRw: 'Umunyeshuri Mugisha Keza Delphine yasabye kwinjira mu Ishami rya Software Development L3.',
    type: 'info',
    category: 'admission',
    targetRoles: ['director'],
    readBy: [],
    relatedId: 'app_01',
    createdAt: '2026-10-29T14:31:00Z'
  }
];

// LocalStorage helpers with automatic seeding
function getOrInit<T>(key: string, initialValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(initialValue));
      return initialValue;
    }
    return JSON.parse(item);
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return initialValue;
  }
}

function save<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

export const StorageService = {
  // USERS
  getUsers: (): User[] => {
    const list = getOrInit('ibb_users_v3', INITIAL_USERS);
    return list.map((u) => {
      let email = u.email;
      if (u.username === 'director' && (u.email === 'director@ibb.ac.rw' || !u.email)) {
        email = 'tzrdidier@gmail.com';
      } else if (u.username === 'accountant' && (u.email === 'accountant@ibb.ac.rw' || !u.email)) {
        email = 'accountant@kass.ac.rw';
      } else if (u.username === 'animator' && (u.email === 'animator@ibb.ac.rw' || !u.email)) {
        email = 'animator@kass.ac.rw';
      }
      return { ...u, email };
    });
  },
  saveUsers: (users: User[]) => save('ibb_users_v3', users),
  updateUser: (updatedUser: User) => {
    const users = StorageService.getUsers().map((u) =>
      u.id === updatedUser.id ? updatedUser : u
    );
    StorageService.saveUsers(users);
  },

  // ACADEMIC GRADING & ADMISSION POLICY
  getAcademicPolicy: (): AcademicGradingPolicy =>
    getOrInit('ibb_academic_policy', INITIAL_ACADEMIC_POLICY),
  saveAcademicPolicy: (policy: AcademicGradingPolicy) => save('ibb_academic_policy', policy),

  // APPROVED STUDENTS
  getApprovedStudents: (): ApprovedStudent[] =>
    getOrInit('ibb_approved_students', INITIAL_APPROVED_STUDENTS),
  saveApprovedStudents: (students: ApprovedStudent[]) =>
    save('ibb_approved_students', students),
  addApprovedStudent: (student: ApprovedStudent) => {
    const current = StorageService.getApprovedStudents();
    const updated = [student, ...current];
    StorageService.saveApprovedStudents(updated);
  },

  // OTP SETTINGS
  getOTPSettings: (): OTPSettings => getOrInit('ibb_otp_settings', INITIAL_OTP_SETTINGS),
  saveOTPSettings: (settings: OTPSettings) => save('ibb_otp_settings', settings),

  // NOTIFICATION DELIVERY LOGS
  getDeliveryLogs: (): NotificationDeliveryLog[] =>
    getOrInit('ibb_delivery_logs', INITIAL_DELIVERY_LOGS),
  addDeliveryLog: (log: Omit<NotificationDeliveryLog, 'id' | 'timestamp'>) => {
    const current = StorageService.getDeliveryLogs();
    const newLog: NotificationDeliveryLog = {
      ...log,
      id: `deliv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toISOString()
    };
    save('ibb_delivery_logs', [newLog, ...current]);
  },

  // PRODUCTS
  getProducts: (): Product[] => getOrInit('ibb_products', INITIAL_PRODUCTS),
  saveProducts: (products: Product[]) => save('ibb_products', products),
  addProduct: (product: Product): Product => {
    const products = StorageService.getProducts();
    const updated = [product, ...products];
    StorageService.saveProducts(updated);
    return product;
  },
  updateProduct: (updatedProduct: Product): void => {
    const products = StorageService.getProducts().map((p) =>
      p.id === updatedProduct.id ? updatedProduct : p
    );
    StorageService.saveProducts(products);
  },

  // STOCK TRANSACTIONS
  getTransactions: (): StockTransaction[] =>
    getOrInit('ibb_stock_transactions', INITIAL_TRANSACTIONS),
  saveTransactions: (txs: StockTransaction[]) => save('ibb_stock_transactions', txs),
  addTransaction: (tx: StockTransaction): void => {
    const txs = StorageService.getTransactions();
    StorageService.saveTransactions([tx, ...txs]);

    // Update Product Stock
    const products = StorageService.getProducts();
    const product = products.find((p) => p.id === tx.productId);
    if (product) {
      if (tx.type === 'stock_in') {
        product.currentStock += tx.quantity;
        product.lastRestockedAt = tx.createdAt;
      } else if (tx.type === 'stock_out') {
        product.currentStock = Math.max(0, product.currentStock - tx.quantity);
      } else if (tx.type === 'correction') {
        product.currentStock = Math.max(0, product.currentStock + tx.quantity);
      }
      StorageService.saveProducts(products);
    }
  },

  // SUPPLIERS
  getSuppliers: (): Supplier[] => getOrInit('ibb_suppliers', INITIAL_SUPPLIERS),
  saveSuppliers: (suppliers: Supplier[]) => save('ibb_suppliers', suppliers),
  addSupplier: (supplier: Supplier): Supplier => {
    const list = StorageService.getSuppliers();
    const updated = [supplier, ...list];
    StorageService.saveSuppliers(updated);
    return supplier;
  },
  updateSupplier: (supplier: Supplier, performedByUser: User): { success: boolean; error?: string } => {
    if (performedByUser.role !== 'director' && performedByUser.role !== 'accountant') {
      return { success: false, error: 'Unauthorized: Only the School Accountant or Director can edit suppliers.' };
    }
    const list = StorageService.getSuppliers();
    const index = list.findIndex((s) => s.id === supplier.id);
    if (index === -1) {
      return { success: false, error: 'Supplier not found' };
    }
    list[index] = supplier;
    StorageService.saveSuppliers(list);
    StorageService.addAuditLog({
      action: 'SUPPLIER_UPDATED',
      category: 'supplier',
      userId: performedByUser.id,
      userName: performedByUser.fullName,
      userRole: performedByUser.role,
      details: `Updated vendor details for: ${supplier.name} (TIN: ${supplier.tinNumber || 'N/A'})`,
      ipAddress: '197.243.34.82'
    });
    return { success: true };
  },
  deleteSupplier: (supplierId: string, performedByUser: User): { success: boolean; error?: string } => {
    if (performedByUser.role !== 'director' && performedByUser.role !== 'accountant') {
      return { success: false, error: 'Unauthorized: Only the School Accountant or Director can delete suppliers.' };
    }
    const suppliers = StorageService.getSuppliers();
    const target = suppliers.find((s) => s.id === supplierId);
    if (!target) {
      return { success: false, error: 'Supplier not found.' };
    }

    // Check if supplier is linked to existing Stock In transactions
    const transactions = StorageService.getTransactions();
    const linkedTxs = transactions.filter(
      (tx) => tx.type === 'stock_in' && tx.supplierId === supplierId
    );

    if (linkedTxs.length > 0) {
      return {
        success: false,
        error: `Cannot delete supplier "${target.name}": ${linkedTxs.length} active Stock In consignment transaction(s) are linked to this vendor. Historical financial & inventory records must be preserved.`
      };
    }

    const updated = suppliers.filter((s) => s.id !== supplierId);
    StorageService.saveSuppliers(updated);

    StorageService.addAuditLog({
      action: 'SUPPLIER_DELETED',
      category: 'supplier',
      userId: performedByUser.id,
      userName: performedByUser.fullName,
      userRole: performedByUser.role,
      details: `Permanently deleted supplier vendor: ${target.name} (TIN: ${target.tinNumber || 'N/A'})`,
      ipAddress: '197.243.34.82'
    });

    return { success: true };
  },

  // STOCK SCHEDULE & OVERRIDE
  getSchedule: (): StockSchedule => getOrInit('ibb_stock_schedule', INITIAL_SCHEDULE),
  saveSchedule: (schedule: StockSchedule) => save('ibb_stock_schedule', schedule),

  // PERMISSION DELEGATIONS
  getDelegations: (): StockPermissionDelegation[] => getOrInit('ibb_delegations', []),
  saveDelegations: (delegations: StockPermissionDelegation[]) => save('ibb_delegations', delegations),
  addDelegation: (delegation: StockPermissionDelegation): void => {
    const list = StorageService.getDelegations();
    StorageService.saveDelegations([delegation, ...list]);
  },

  // ADMISSION APPLICATIONS
  getApplications: (): StudentApplication[] =>
    getOrInit('ibb_applications_v2', INITIAL_APPLICATIONS),
  saveApplications: (apps: StudentApplication[]) => save('ibb_applications_v2', apps),
  addApplication: (app: StudentApplication): StudentApplication => {
    // 1. Evaluate Eligibility against Configured Academic Policy
    const policy = StorageService.getAcademicPolicy();
    const minRequired = policy.minimumAdmissionPercentage;

    let finalApp = { ...app };

    if (app.academicScorePercentage < minRequired) {
      finalApp.status = 'automatically_rejected';
      finalApp.autoRejectionReason = `Academic score (${app.academicScorePercentage.toFixed(1)}%) is below the school minimum admission threshold of ${minRequired.toFixed(1)}%.`;

      // Log decision
      StorageService.addAuditLog({
        action: 'ADMISSION_AUTO_REJECTED',
        category: 'admission',
        userId: 'system_evaluator',
        userName: 'System Admission Engine',
        userRole: 'director',
        details: `Application ${app.trackingNumber} (${app.fullName}) automatically rejected: score ${app.academicScorePercentage}% is below ${minRequired}% threshold.`,
        ipAddress: '127.0.0.1'
      });

      // Dispatch SMS / Email rejection notification
      StorageService.addDeliveryLog({
        channel: 'sms',
        recipient: app.phone,
        subject: 'KASS Admission Application Status',
        content: `KASS Rwanda: Dear ${app.fullName}, your application for ${app.department} ${app.applyingLevel} could not be accepted as your score (${app.academicScorePercentage}%) does not meet the minimum admission threshold of ${minRequired}%.`,
        status: 'delivered',
        providerResponse: 'SMS_GATEWAY_DELIVERED'
      });
    } else {
      finalApp.status = 'eligible';
      finalApp.isEligibleForBoarding = app.academicScorePercentage >= policy.boardingEligibilityPercentage;

      StorageService.addDeliveryLog({
        channel: 'sms',
        recipient: app.phone,
        subject: 'KASS Application Received & Eligible',
        content: `KASS Rwanda: Dear ${app.fullName}, your application (${app.trackingNumber}) is ELIGIBLE for Director review. Boarding status: ${finalApp.isEligibleForBoarding ? 'Eligible' : 'Day scholar'}.`,
        status: 'delivered',
        providerResponse: 'SMS_GATEWAY_DELIVERED'
      });
    }

    const apps = StorageService.getApplications();
    const updated = [finalApp, ...apps];
    StorageService.saveApplications(updated);
    return finalApp;
  },
  updateApplication: (updatedApp: StudentApplication): void => {
    const apps = StorageService.getApplications().map((a) =>
      a.id === updatedApp.id ? updatedApp : a
    );
    StorageService.saveApplications(apps);
  },

  // NOTIFICATIONS
  getNotifications: (): NotificationItem[] =>
    getOrInit('ibb_notifications_v2', INITIAL_NOTIFICATIONS),
  saveNotifications: (notifs: NotificationItem[]) => save('ibb_notifications_v2', notifs),
  addNotification: (notif: NotificationItem): void => {
    const notifs = StorageService.getNotifications();
    StorageService.saveNotifications([notif, ...notifs]);
  },
  markNotificationRead: (notifId: string, userId: string): void => {
    const notifs = StorageService.getNotifications().map((n) => {
      if (n.id === notifId && !n.readBy.includes(userId)) {
        return { ...n, readBy: [...n.readBy, userId] };
      }
      return n;
    });
    StorageService.saveNotifications(notifs);
  },
  markAllNotificationsRead: (userId: string): void => {
    const notifs = StorageService.getNotifications().map((n) => {
      if (!n.readBy.includes(userId)) {
        return { ...n, readBy: [...n.readBy, userId] };
      }
      return n;
    });
    StorageService.saveNotifications(notifs);
  },

  // AUDIT LOGS
  getAuditLogs: (): AuditLog[] => getOrInit('ibb_audit_logs_v2', INITIAL_AUDIT_LOGS),
  saveAuditLogs: (logs: AuditLog[]) => save('ibb_audit_logs_v2', logs),
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>): void => {
    const logs = StorageService.getAuditLogs();
    const newLog: AuditLog = {
      ...log,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString()
    };
    StorageService.saveAuditLogs([newLog, ...logs]);
  },

  // Permission Verification Helper
  hasPermission: (user: User | null, module: PermissionModule): boolean => {
    if (!user) return false;
    if (user.role === 'director') return true; // Director has full authority
    return user.permissions?.includes(module) ?? false;
  },

  // Stock Hours Validation Helper
  isStockWindowOpen: (schedule: StockSchedule): { isOpen: boolean; reason: string } => {
    if (schedule.emergencyOverrideActive) {
      return { isOpen: true, reason: 'Director Emergency Override Active' };
    }
    if (!schedule.enforceHours) {
      return { isOpen: true, reason: 'Schedule Enforcement Disabled by Administrator' };
    }

    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const currentMinutes = hours * 60 + minutes;

    const parseMinutes = (timeStr: string) => {
      const [h, m] = timeStr.split(':').map(Number);
      return h * 60 + m;
    };

    const morningStart = parseMinutes(schedule.morningStart);
    const morningEnd = parseMinutes(schedule.morningEnd);
    const eveningStart = parseMinutes(schedule.eveningStart);
    const eveningEnd = parseMinutes(schedule.eveningEnd);

    const isMorning = currentMinutes >= morningStart && currentMinutes <= morningEnd;
    const isEvening = currentMinutes >= eveningStart && currentMinutes <= eveningEnd;

    if (isMorning) {
      return { isOpen: true, reason: `Morning Window (${schedule.morningStart} - ${schedule.morningEnd})` };
    }
    if (isEvening) {
      return { isOpen: true, reason: `Evening Window (${schedule.eveningStart} - ${schedule.eveningEnd})` };
    }

    return {
      isOpen: false,
      reason: `Outside authorized hours. Storage opens morning (${schedule.morningStart} - ${schedule.morningEnd}) and evening (${schedule.eveningStart} - ${schedule.eveningEnd}).`
    };
  },

  // Consumption analytics helper
  calculateConsumptionRate: (productId: string, daysWindow = 14): { dailyAverageKg: number; estDaysRemaining: number } => {
    const transactions = StorageService.getTransactions().filter(
      (tx) => tx.productId === productId && tx.type === 'stock_out'
    );
    const products = StorageService.getProducts();
    const product = products.find((p) => p.id === productId);

    if (!product || product.currentStock <= 0) {
      return { dailyAverageKg: 0, estDaysRemaining: 0 };
    }

    const totalIssued = transactions.reduce((sum, tx) => sum + tx.quantity, 0);
    const avgDaily = transactions.length > 0 ? totalIssued / Math.max(1, Math.min(daysWindow, 7)) : 25;
    const estDays = avgDaily > 0 ? Math.round(product.currentStock / avgDaily) : 999;

    return {
      dailyAverageKg: Math.round(avgDaily * 10) / 10,
      estDaysRemaining: estDays
    };
  },

  // Contact Us Inquiries Delivery to the Three School Leaders (Director, Accountant, Animator)
  submitContactInquiry: (inquiry: {
    name: string;
    email: string;
    subject: string;
    message: string;
  }): { success: boolean; deliveredTo: { role: string; email: string; name: string }[]; error?: string } => {
    try {
      const users = StorageService.getUsers();
      const targetRoles: UserRole[] = ['director', 'accountant', 'animator'];
      const recipients: { role: string; email: string; name: string }[] = [];

      for (const role of targetRoles) {
        const u = users.find((user) => user.role === role);
        if (u) {
          recipients.push({
            role: u.role,
            email: u.email,
            name: u.fullName
          });
        }
      }

      // Add in-app notification to all three leaders
      const newNotif: NotificationItem = {
        id: `notif_contact_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        title: `Contact Inquiry: ${inquiry.subject || 'General Information'}`,
        titleRw: `Ubutumwa bushya: ${inquiry.subject || 'Ibibazo Rusange'}`,
        message: `Inquiry from ${inquiry.name} (${inquiry.email}): "${inquiry.message}"`,
        messageRw: `Ubutumwa bwatanzwe na ${inquiry.name} (${inquiry.email}): "${inquiry.message}"`,
        type: 'info',
        category: 'admission',
        targetRoles: ['director', 'accountant', 'animator'],
        readBy: [],
        createdAt: new Date().toISOString()
      };
      StorageService.addNotification(newNotif);

      // Log delivery for each of the three leaders
      for (const recipient of recipients) {
        StorageService.addDeliveryLog({
          channel: 'email',
          recipient: recipient.email,
          subject: `[KARENGE ADVENTIST] Website Inquiry from ${inquiry.name}: ${inquiry.subject || 'General'}`,
          content: `Inquiry details from website visitor:\nName: ${inquiry.name}\nEmail: ${inquiry.email}\nSubject: ${inquiry.subject}\n\nMessage:\n${inquiry.message}`,
          status: 'delivered',
          providerResponse: `Delivered to mail server queue for ${recipient.name} (${recipient.role.toUpperCase()})`
        });
      }

      // Record system audit log
      StorageService.addAuditLog({
        action: 'Contact Us Inquiry Dispatched',
        category: 'system',
        userId: 'visitor',
        userName: inquiry.name,
        userRole: 'director',
        details: `Public visitor ${inquiry.name} (${inquiry.email}) submitted message: "${inquiry.subject}". Routed to Director, Accountant, and Animator.`
      });

      // Save inquiry in persistent contact inquiries storage
      const inquiries = getOrInit<any[]>('kass_contact_inquiries', []);
      save('kass_contact_inquiries', [
        {
          id: `inq_${Date.now()}`,
          name: inquiry.name,
          email: inquiry.email,
          subject: inquiry.subject,
          message: inquiry.message,
          deliveredTo: recipients.map((r) => r.email),
          submittedAt: new Date().toISOString()
        },
        ...inquiries
      ]);

      return { success: true, deliveredTo: recipients };
    } catch (err: any) {
      console.error('Failed to dispatch contact inquiry:', err);
      return { success: false, deliveredTo: [], error: err.message || 'Dispatch failed' };
    }
  }
};
