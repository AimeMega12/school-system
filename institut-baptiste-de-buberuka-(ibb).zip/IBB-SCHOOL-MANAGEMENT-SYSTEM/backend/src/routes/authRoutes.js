import express from 'express';
import {
  login,
  googleSignIn,
  changePassword,
  updateProfile
} from '../controllers/authController.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Direct login (No OTP)
router.post('/login', login);
router.post('/login-step1', login); // Alias for compatibility

// Google OAuth 2.0 / OpenID Connect Sign-In
router.post('/google', googleSignIn);

// Strong Password Change & Profile Management
router.post('/change-password', authenticateToken, changePassword);
router.put('/profile', authenticateToken, updateProfile);

export default router;
