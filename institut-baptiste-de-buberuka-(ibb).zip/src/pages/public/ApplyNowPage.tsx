/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { StudentApplication, DepartmentType, AcademicLevel } from '../../types/index.ts';
import {
  Upload,
  CheckCircle2,
  AlertCircle,
  FileText,
  Image as ImageIcon,
  Printer,
  Search,
  ArrowRight,
  ShieldCheck,
  Award,
  Info
} from 'lucide-react';

export const ApplyNowPage: React.FC = () => {
  const { t, language } = useLanguage();
  const { addNotification } = useNotifications();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const defaultDept =
    searchParams.get('dept') === 'automobile_technology'
      ? 'automobile_technology'
      : 'software_development';

  // Get active Director Academic Policy
  const activePolicy = useMemo(() => StorageService.getAcademicPolicy(), []);

  // Form State
  const [fullName, setFullName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [motherName, setMotherName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [residentialAddress, setResidentialAddress] = useState('');
  const [district, setDistrict] = useState('Rwamagana');
  const [sector, setSector] = useState('Karenge');

  // Academic State (L3 to L5)
  const [applyingLevel, setApplyingLevel] = useState<AcademicLevel>('L3');
  const [department, setDepartment] = useState<DepartmentType>(defaultDept);
  const [previousSchool, setPreviousSchool] = useState('');
  const [previousAcademicLevel, setPreviousAcademicLevel] = useState('Senior 3');
  const [academicScorePercentage, setAcademicScorePercentage] = useState<number>(75.0);
  const [s3Score, setS3Score] = useState<number>(18);

  // File Uploads
  const [resultSlipFile, setResultSlipFile] = useState<File | null>(null);
  const [resultSlipPreview, setResultSlipPreview] = useState<string>('');
  const [passportPhotoFile, setPassportPhotoFile] = useState<File | null>(null);
  const [passportPhotoPreview, setPassportPhotoPreview] = useState<string>('');

  const [declaration, setDeclaration] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedApp, setSubmittedApp] = useState<StudentApplication | null>(null);

  // File handler helpers
  const handleResultSlipChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        setErrorMsg('Result Slip / Certificate must be smaller than 5MB.');
        return;
      }
      setResultSlipFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setResultSlipPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
      setErrorMsg('');
    }
  };

  const handlePassportPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 3 * 1024 * 1024) {
        setErrorMsg('Passport photo must be smaller than 3MB.');
        return;
      }
      setPassportPhotoFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPassportPhotoPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
      setErrorMsg('');
    }
  };

  const isEligible = academicScorePercentage >= activePolicy.minimumAdmissionPercentage;
  const isBoardingEligible = academicScorePercentage >= activePolicy.boardingEligibilityPercentage;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Field validation
    if (!fullName.trim() || !fatherName.trim() || !motherName.trim() || !dateOfBirth) {
      setErrorMsg(language === 'rw' ? 'Nyamuneka uzuza imyirondoro yose isabwa.' : 'Please fill in all personal details.');
      return;
    }

    if (!phone.trim()) {
      setErrorMsg(language === 'rw' ? 'Shyiramo nimero ya telefoni y’umubyeyi.' : 'Please provide parent telephone contact.');
      return;
    }

    if (!previousSchool.trim()) {
      setErrorMsg(language === 'rw' ? 'Shyiramo ikigo wizeho mbere.' : 'Please enter your previous school or institute.');
      return;
    }

    if (academicScorePercentage <= 0 || academicScorePercentage > 100) {
      setErrorMsg('Academic percentage must be between 1% and 100%.');
      return;
    }

    if (!declaration) {
      setErrorMsg(language === 'rw' ? 'Kanda ku gasanduku ko kwemeza ko amakuru ari ukuri.' : 'Please check the declaration box before submitting.');
      return;
    }

    setIsSubmitting(true);

    // Generate unique tracking number KASS-2026-XXXXX
    const randomSuffix = Math.floor(10000 + Math.random() * 90000).toString();
    const trackingNo = `KASS-2026-${randomSuffix}`;

    const newApplication: StudentApplication = {
      id: `app_${Date.now()}`,
      trackingNumber: trackingNo,
      fullName: fullName.trim(),
      fatherName: fatherName.trim(),
      motherName: motherName.trim(),
      dateOfBirth,
      gender,
      phone: phone.trim(),
      email: email.trim() || `${fullName.toLowerCase().replace(/\s+/g, '.') || 'student'}@gmail.com`,
      residentialAddress: residentialAddress.trim() || `${district}, ${sector}`,
      district,
      sector,
      applyingLevel,
      department,
      previousSchool: previousSchool.trim(),
      previousAcademicLevel,
      academicScorePercentage: Number(academicScorePercentage),
      s3AggregateScore: Number(s3Score) || 20,
      resultSlipFileName: resultSlipFile ? resultSlipFile.name : `${applyingLevel.toLowerCase()}_result_slip.pdf`,
      resultSlipUrl: resultSlipPreview || 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600',
      passportPhotoFileName: passportPhotoFile ? passportPhotoFile.name : 'student_passport_photo.jpg',
      passportPhotoUrl: passportPhotoPreview || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300',
      status: 'pending', // StorageService.addApplication will re-evaluate against active policy
      submittedAt: new Date().toISOString(),
      academicYear: activePolicy.academicYear
    };

    // Save to database with automatic eligibility evaluator
    const processedApp = StorageService.addApplication(newApplication);

    // Audit log
    StorageService.addAuditLog({
      action: 'ADMISSION_SUBMITTED',
      category: 'admission',
      userId: 'public_applicant',
      userName: processedApp.fullName,
      userRole: 'animator',
      details: `New online application submitted: ${processedApp.fullName} (${trackingNo}) for ${processedApp.applyingLevel} - ${processedApp.department} with verified score ${processedApp.academicScorePercentage}%. Initial status: ${processedApp.status}`,
      ipAddress: '197.243.34.82'
    });

    // Notify School Director
    addNotification({
      title: `New Admission: ${processedApp.fullName} (${processedApp.applyingLevel})`,
      titleRw: `Ubusabe Bushya: ${processedApp.fullName} (${processedApp.applyingLevel})`,
      message: `Candidate applied for ${processedApp.applyingLevel} in ${processedApp.department === 'software_development' ? 'Software Development' : 'Automobile Tech'} (Score: ${processedApp.academicScorePercentage}% - ${processedApp.status.toUpperCase()}).`,
      messageRw: `Ubusabe bushya bwa ${processedApp.fullName} mu cyiciro cya ${processedApp.applyingLevel} muri ${processedApp.department === 'software_development' ? 'Ikoranabuhanga' : 'Ibinyabiziga'} (${processedApp.academicScorePercentage}%).`,
      type: processedApp.status === 'automatically_rejected' ? 'warning' : 'info',
      category: 'admission',
      targetRoles: ['director'],
      relatedId: processedApp.id
    });

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedApp(processedApp);
    }, 500);
  };

  if (submittedApp) {
    return (
      <div className="py-16 bg-slate-50 dark:bg-slate-900/50 min-h-[80vh] flex items-center justify-center text-slate-900 dark:text-slate-100">
        <div className="max-w-xl mx-auto px-4 w-full">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl text-center">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 ${
              submittedApp.status === 'automatically_rejected'
                ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                : 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
            }`}>
              {submittedApp.status === 'automatically_rejected' ? (
                <AlertCircle className="w-8 h-8" />
              ) : (
                <CheckCircle2 className="w-8 h-8" />
              )}
            </div>

            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-2">
              {submittedApp.status === 'automatically_rejected'
                ? 'Application Processed (Below Threshold)'
                : t('applicationSuccessTitle')}
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-6">
              {submittedApp.status === 'automatically_rejected'
                ? `Your application has been received, but the entered score (${submittedApp.academicScorePercentage}%) does not meet the minimum admission threshold of ${activePolicy.minimumAdmissionPercentage}%. It has been flagged for Director exceptional review.`
                : t('applicationSuccessMsg')}
            </p>

            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-wider mb-6 select-all">
              {submittedApp.trackingNumber}
            </div>

            <div className="mb-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-left text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Admitted Level:</span>
                <span className="font-bold text-slate-900 dark:text-white">{submittedApp.applyingLevel}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Department:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {submittedApp.department === 'software_development' ? 'Software Development' : 'Automobile Technology'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Verified Academic Score:</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">{submittedApp.academicScorePercentage}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className={`font-bold uppercase ${
                  submittedApp.status === 'automatically_rejected' ? 'text-rose-600' : 'text-emerald-600'
                }`}>
                  {submittedApp.status}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-8">
              {t('saveTrackingNote')}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => window.print()}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>{t('printReceipt')}</span>
              </button>

              <Link
                to={`/track?tracking=${submittedApp.trackingNumber}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all"
              >
                <Search className="w-4 h-4" />
                <span>{t('trackNowBtn')}</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 bg-slate-50 dark:bg-slate-900/40 text-slate-900 dark:text-slate-100 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
            MINEDUC / RTB Accredited TVET Intake ({activePolicy.academicYear})
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mt-1 mb-3 text-slate-900 dark:text-white">
            {t('admissionHeader')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            {t('admissionSub')}
          </p>
        </div>

        {errorMsg && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Application Form */}
        <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm space-y-10">
          
          {/* Section 1: Academic Level Selection (L3 to L5) */}
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-6">
              <h3 className="text-sm font-bold uppercase tracking-wider text-blue-700 dark:text-blue-400">
                1. Academic Level & Program Specialization
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                Min. Admission: {activePolicy.minimumAdmissionPercentage}%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {[
                {
                  level: 'L3' as AcademicLevel,
                  title: 'Level 3 (L3)',
                  subtitle: 'Foundation Technical Cycle',
                  req: 'Requires completion of Senior 3 Ordinary Level'
                },
                {
                  level: 'L4' as AcademicLevel,
                  title: 'Level 4 (L4)',
                  subtitle: 'Intermediate Technical Cycle',
                  req: 'Requires Level 3 or Senior 4 technical credits'
                },
                {
                  level: 'L5' as AcademicLevel,
                  title: 'Level 5 (L5)',
                  subtitle: 'Advanced Technician Certificate',
                  req: 'Requires Level 4 TVET or Senior 5 credentials'
                }
              ].map((item) => (
                <div
                  key={item.level}
                  onClick={() => {
                    setApplyingLevel(item.level);
                    if (item.level === 'L3') setPreviousAcademicLevel('Senior 3');
                    else if (item.level === 'L4') setPreviousAcademicLevel('Level 3 TVET');
                    else if (item.level === 'L5') setPreviousAcademicLevel('Level 4 TVET');
                  }}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    applyingLevel === item.level
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                      {item.title}
                    </span>
                    <input
                      type="radio"
                      name="applyingLevel"
                      checked={applyingLevel === item.level}
                      onChange={() => {}}
                      className="text-emerald-600"
                    />
                  </div>
                  <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 mb-1">
                    {item.subtitle}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                    {item.req}
                  </p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('targetDepartment')} *
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value as DepartmentType)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="software_development">{t('softwareDevDept')}</option>
                  <option value="automobile_technology">{t('autoTechDept')}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('previousAcademicLevel')} *
                </label>
                <select
                  value={previousAcademicLevel}
                  onChange={(e) => setPreviousAcademicLevel(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="Senior 3">Ordinary Level (Senior 3)</option>
                  <option value="Level 3 TVET">Level 3 TVET Certificate</option>
                  <option value="Senior 4">Senior 4 General / Technical</option>
                  <option value="Level 4 TVET">Level 4 TVET Certificate</option>
                  <option value="Senior 5">Senior 5 Technical</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('academicPercentage')} *
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="10"
                    max="100"
                    required
                    value={academicScorePercentage}
                    onChange={(e) => setAcademicScorePercentage(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white font-mono tabular-nums focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="e.g. 78.5"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-400">%</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('previousSchool')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. GS Karenge / IPRC Kigali / GS Rwamagana"
                  value={previousSchool}
                  onChange={(e) => setPreviousSchool(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Real-time Admission Eligibility Banner */}
            <div className={`mt-5 p-4 rounded-xl border flex items-start gap-3 ${
              isEligible
                ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
            }`}>
              {isEligible ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="text-xs">
                <span className="font-bold block mb-0.5">
                  {isEligible ? 'Admission Score Eligibility Status: ELIGIBLE' : 'Admission Score Eligibility Status: BELOW THRESHOLD'}
                </span>
                <p className="leading-relaxed opacity-90">
                  {isEligible
                    ? `Your score of ${academicScorePercentage}% meets the Director's minimum intake threshold (${activePolicy.minimumAdmissionPercentage}%). ${
                        isBoardingEligible
                          ? 'Outstanding result! You meet the priority threshold for Boarding Scholar accommodation (≥80%).'
                          : 'Admissible as Day Scholar (Boarding scholar priority is 80%+).'
                      }`
                    : `Your score (${academicScorePercentage}%) is lower than the required minimum threshold of ${activePolicy.minimumAdmissionPercentage}%. Under school regulations, this submission will be flagged as automatically rejected unless the Director issues an exceptional waiver.`}
                </p>
              </div>
            </div>
          </div>

          {/* Section 2: Personal & Guardian Info */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 pb-3 border-b border-slate-100 dark:border-slate-800 mb-6">
              2. {t('personalInfoSection')}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('applicantFullName')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mugisha Jean Paul"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('fatherFullName')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hategekimana Pierre"
                  value={fatherName}
                  onChange={(e) => setFatherName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('motherFullName')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mukamugema Marie"
                  value={motherName}
                  onChange={(e) => setMotherName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('dateOfBirth')} *
                </label>
                <input
                  type="date"
                  required
                  value={dateOfBirth}
                  onChange={(e) => setDateOfBirth(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('gender')} *
                </label>
                <div className="flex items-center gap-4 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300">
                    <input
                      type="radio"
                      name="gender"
                      value="male"
                      checked={gender === 'male'}
                      onChange={() => setGender('male')}
                      className="text-emerald-600"
                    />
                    <span>{t('genderMale')}</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 dark:text-slate-300">
                    <input
                      type="radio"
                      name="gender"
                      value="female"
                      checked={gender === 'female'}
                      onChange={() => setGender('female')}
                      className="text-emerald-600"
                    />
                    <span>{t('genderFemale')}</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('phoneNumber')} *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+250 788 000 000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('emailAddress')}
                </label>
                <input
                  type="email"
                  placeholder="parent.guardian@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('district')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Rwamagana, Gasabo, Kicukiro..."
                  value={district}
                  onChange={(e) => setDistrict(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('sector')} *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Karenge, Nzige, Gahengeri..."
                  value={sector}
                  onChange={(e) => setSector(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Document Attachments */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-400 pb-3 border-b border-slate-100 dark:border-slate-800 mb-6">
              3. {t('documentUploadSection')}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Result Slip */}
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-5 text-center hover:border-emerald-500 dark:hover:border-emerald-500 transition-colors">
                <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <span className="block text-xs font-bold text-slate-900 dark:text-white mb-1">
                  Official Academic Result Slip / Certificate ({applyingLevel}) *
                </span>
                <p className="text-[11px] text-slate-500 mb-3">
                  {resultSlipFile ? resultSlipFile.name : t('uploadDragDrop')}
                </p>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose Result Document</span>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleResultSlipChange}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Passport Photo */}
              <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-5 text-center hover:border-emerald-500 dark:hover:border-emerald-500 transition-colors">
                <ImageIcon className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <span className="block text-xs font-bold text-slate-900 dark:text-white mb-1">
                  {t('passportPhotoLabel')} *
                </span>
                <p className="text-[11px] text-slate-500 mb-3">
                  {passportPhotoFile ? passportPhotoFile.name : t('uploadDragDrop')}
                </p>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Choose Passport Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePassportPhotoChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Declaration */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={declaration}
                onChange={(e) => setDeclaration(e.target.checked)}
                className="mt-0.5 w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                {t('declarationText')}
              </span>
            </label>
          </div>

          {/* Submit Button */}
          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 shadow-lg shadow-emerald-600/30 transition-all"
            >
              <span>{isSubmitting ? t('submittingBtn') : t('submitApplicationBtn')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
