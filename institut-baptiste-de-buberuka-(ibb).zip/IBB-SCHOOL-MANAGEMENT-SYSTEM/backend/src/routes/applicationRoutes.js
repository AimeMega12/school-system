import express from 'express';
import {
  submitApplication,
  trackApplication,
  getApplications,
  approveApplication,
  rejectApplication,
  issueWaiver
} from '../controllers/applicationController.js';
import { authenticateToken } from '../middleware/auth.js';
import { requireRole } from '../middleware/rbac.js';

const router = express.Router();

// Public routes
router.post('/apply', submitApplication);
router.get('/track/:trackingNumber', trackApplication);

// Protected routes (Director & staff)
router.get('/', authenticateToken, getApplications);
router.put('/:id/approve', authenticateToken, requireRole(['director']), approveApplication);
router.put('/:id/reject', authenticateToken, requireRole(['director']), rejectApplication);
router.put('/:id/waiver', authenticateToken, requireRole(['director']), issueWaiver);

export default router;
