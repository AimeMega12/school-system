/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { ThemeProvider } from './context/ThemeContext.tsx';
import { LanguageProvider } from './context/LanguageContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { NotificationProvider } from './context/NotificationContext.tsx';

// Common Components
import { Navbar } from './components/common/Navbar.tsx';
import { Footer } from './components/common/Footer.tsx';

// Public Pages
import { HomePage } from './pages/public/HomePage.tsx';
import { AboutPage } from './pages/public/AboutPage.tsx';
import { ProgramsPage } from './pages/public/ProgramsPage.tsx';
import { AdmissionsPage } from './pages/public/AdmissionsPage.tsx';
import { ApplyNowPage } from './pages/public/ApplyNowPage.tsx';
import { TrackApplicationPage } from './pages/public/TrackApplicationPage.tsx';
import { ContactPage } from './pages/public/ContactPage.tsx';
import { LoginPage } from './pages/public/LoginPage.tsx';

// Dashboard Layout & Pages
import { DashboardLayout } from './pages/dashboard/DashboardLayout.tsx';
import { DirectorDashboard } from './pages/dashboard/DirectorDashboard.tsx';
import { AccountantDashboard } from './pages/dashboard/AccountantDashboard.tsx';
import { AnimatorDashboard } from './pages/dashboard/AnimatorDashboard.tsx';
import { ApplicationsManager } from './pages/dashboard/ApplicationsManager.tsx';
import { ApprovedStudentsManager } from './pages/dashboard/ApprovedStudentsManager.tsx';
import { AcademicPolicyManager } from './pages/dashboard/AcademicPolicyManager.tsx';
import { AccessControlManager } from './pages/dashboard/AccessControlManager.tsx';
import { NotificationSettingsManager } from './pages/dashboard/NotificationSettingsManager.tsx';
import { DirectorProfilePage } from './pages/dashboard/DirectorProfilePage.tsx';
import { StockManager } from './pages/dashboard/StockManager.tsx';
import { SuppliersManager } from './pages/dashboard/SuppliersManager.tsx';
import { ReportsManager } from './pages/dashboard/ReportsManager.tsx';
import { SettingsScheduleManager } from './pages/dashboard/SettingsScheduleManager.tsx';
import { AuditLogsManager } from './pages/dashboard/AuditLogsManager.tsx';

// Public Layout Wrapper
const PublicLayout: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
};

// Route Redirector based on staff role
const DashboardRoleRedirect: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }
  if (user.role === 'director') return <Navigate to="/dashboard/director" replace />;
  if (user.role === 'accountant') return <Navigate to="/dashboard/accountant" replace />;
  if (user.role === 'animator') return <Navigate to="/dashboard/animator" replace />;
  return <Navigate to="/dashboard/director" replace />;
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <NotificationProvider>
            <BrowserRouter>
              <Routes>
                {/* Public Website Routes */}
                <Route element={<PublicLayout />}>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/about" element={<AboutPage />} />
                  <Route path="/programs" element={<ProgramsPage />} />
                  <Route path="/admissions" element={<AdmissionsPage />} />
                  <Route path="/apply" element={<ApplyNowPage />} />
                  <Route path="/track" element={<TrackApplicationPage />} />
                  <Route path="/contact" element={<ContactPage />} />
                  <Route path="/login" element={<LoginPage />} />
                </Route>

                {/* Dashboard Administration Routes */}
                <Route path="/dashboard" element={<DashboardLayout />}>
                  <Route index element={<DashboardRoleRedirect />} />
                  <Route path="director" element={<DirectorDashboard />} />
                  <Route path="accountant" element={<AccountantDashboard />} />
                  <Route path="animator" element={<AnimatorDashboard />} />
                  <Route path="admissions" element={<ApplicationsManager />} />
                  <Route path="approved-students" element={<ApprovedStudentsManager />} />
                  <Route path="academic-policy" element={<AcademicPolicyManager />} />
                  <Route path="access-control" element={<AccessControlManager />} />
                  <Route path="otp-notifications" element={<NotificationSettingsManager />} />
                  <Route path="profile" element={<DirectorProfilePage />} />
                  <Route path="stock" element={<StockManager />} />
                  <Route path="suppliers" element={<SuppliersManager />} />
                  <Route path="reports" element={<ReportsManager />} />
                  <Route path="schedule" element={<SettingsScheduleManager />} />
                  <Route path="audit" element={<AuditLogsManager />} />
                </Route>

                {/* Catch-all fallback */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </BrowserRouter>
          </NotificationProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
