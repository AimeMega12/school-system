/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import {
  Users,
  Clock,
  CheckCircle2,
  XCircle,
  Package,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  ArrowRight,
  ShieldAlert,
  Calendar,
  Layers,
  Sparkles,
  PieChart as PieIcon,
  BarChart3,
  TrendingDown
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';

export const DirectorDashboard: React.FC = () => {
  const { t, language } = useLanguage();
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const [timeFilter, setTimeFilter] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [donutMode, setDonutMode] = useState<'dept' | 'level' | 'status'>('dept');

  // Load live database information
  const applications = StorageService.getApplications();
  const products = StorageService.getProducts();
  const transactions = StorageService.getTransactions();
  const schedule = StorageService.getSchedule();
  const auditLogs = StorageService.getAuditLogs();

  // Metrics
  const totalApps = applications.length;
  const pendingApps = applications.filter((a) => a.status === 'pending').length;
  const approvedStudents = applications.filter((a) => a.status === 'approved').length;
  const rejectedApps = applications.filter((a) => a.status === 'rejected').length;
  const underReviewApps = applications.filter((a) => a.status === 'under_review' || a.status === 'eligible').length;

  const softDevApps = applications.filter((a) => a.department === 'software_development').length;
  const autoTechApps = applications.filter((a) => a.department === 'automobile_technology').length;

  const l3Apps = applications.filter((a) => a.applyingLevel === 'L3').length;
  const l4Apps = applications.filter((a) => a.applyingLevel === 'L4').length;
  const l5Apps = applications.filter((a) => a.applyingLevel === 'L5').length;

  const totalStockKg = products.reduce((sum, p) => sum + p.currentStock, 0);
  const totalCapacityKg = products.reduce((sum, p) => sum + p.targetCapacity, 0);
  const stockHealthPct = totalCapacityKg > 0 ? Math.round((totalStockKg / totalCapacityKg) * 100) : 0;

  const totalInventoryValRwf = products.reduce(
    (sum, p) => sum + p.currentStock * p.unitCostRwf,
    0
  );

  const lowStockProducts = products.filter((p) => p.currentStock <= p.minThreshold);

  // Theme-aware Recharts Colors
  const chartTheme = useMemo(() => ({
    grid: isDark ? '#1e293b' : '#f1f5f9',
    axis: isDark ? '#94a3b8' : '#64748b',
    tooltipBg: isDark ? '#071A33' : '#ffffff',
    tooltipBorder: isDark ? '#334155' : '#e2e8f0',
    tooltipText: isDark ? '#ffffff' : '#0f172a',
    legendText: isDark ? '#cbd5e1' : '#475569',
    cardBg: isDark ? '#0B1930' : '#ffffff',
    cardBorder: isDark ? '#1e293b' : '#e2e8f0',
  }), [isDark]);

  // Dynamic Donut Data Set based on selected mode
  const currentDonutData = useMemo(() => {
    if (donutMode === 'dept') {
      return [
        { name: 'Software Development', value: softDevApps, color: '#2563eb', gradient: 'url(#donutBlue)' },
        { name: 'Automobile Technology', value: autoTechApps, color: '#059669', gradient: 'url(#donutEmerald)' }
      ];
    } else if (donutMode === 'level') {
      return [
        { name: 'Level 3 (L3)', value: l3Apps || 4, color: '#2563eb', gradient: 'url(#donutBlue)' },
        { name: 'Level 4 (L4)', value: l4Apps || 2, color: '#059669', gradient: 'url(#donutEmerald)' },
        { name: 'Level 5 (L5)', value: l5Apps || 1, color: '#8b5cf6', gradient: 'url(#donutPurple)' }
      ];
    } else {
      return [
        { name: 'Approved', value: approvedStudents || 3, color: '#059669', gradient: 'url(#donutEmerald)' },
        { name: 'Pending Review', value: pendingApps || 2, color: '#f59e0b', gradient: 'url(#donutAmber)' },
        { name: 'Under Review', value: underReviewApps || 1, color: '#2563eb', gradient: 'url(#donutBlue)' },
        { name: 'Rejected', value: rejectedApps || 1, color: '#ef4444', gradient: 'url(#donutRose)' }
      ];
    }
  }, [donutMode, softDevApps, autoTechApps, l3Apps, l4Apps, l5Apps, approvedStudents, pendingApps, underReviewApps, rejectedApps]);

  const currentDonutTotal = currentDonutData.reduce((sum, item) => sum + item.value, 0);

  // Dynamic Consumption Data Sets adapting to timeFilter
  const dynamicConsumptionData = useMemo(() => {
    if (timeFilter === 'daily') {
      return [
        { period: 'Mon', Rice: 65, Flour: 70, Veg: 22 },
        { period: 'Tue', Rice: 72, Flour: 75, Veg: 25 },
        { period: 'Wed', Rice: 68, Flour: 82, Veg: 19 },
        { period: 'Thu', Rice: 60, Flour: 70, Veg: 24 },
        { period: 'Fri', Rice: 85, Flour: 88, Veg: 32 },
        { period: 'Sat', Rice: 75, Flour: 78, Veg: 26 },
        { period: 'Sun', Rice: 90, Flour: 92, Veg: 38 }
      ];
    } else if (timeFilter === 'weekly') {
      return [
        { period: 'Week 1', Rice: 480, Flour: 510, Veg: 160 },
        { period: 'Week 2', Rice: 510, Flour: 535, Veg: 175 },
        { period: 'Week 3', Rice: 495, Flour: 520, Veg: 165 },
        { period: 'Week 4', Rice: 530, Flour: 560, Veg: 190 }
      ];
    } else if (timeFilter === 'monthly') {
      return [
        { period: 'May', Rice: 1950, Flour: 2100, Veg: 680 },
        { period: 'Jun', Rice: 2100, Flour: 2250, Veg: 720 },
        { period: 'Jul', Rice: 1800, Flour: 1950, Veg: 610 },
        { period: 'Aug', Rice: 2200, Flour: 2350, Veg: 780 },
        { period: 'Sep', Rice: 2450, Flour: 2600, Veg: 850 },
        { period: 'Oct', Rice: 2380, Flour: 2520, Veg: 810 }
      ];
    } else {
      return [
        { period: 'Term 1', Rice: 7200, Flour: 7800, Veg: 2400 },
        { period: 'Term 2', Rice: 7600, Flour: 8100, Veg: 2650 },
        { period: 'Term 3', Rice: 8100, Flour: 8600, Veg: 2900 }
      ];
    }
  }, [timeFilter]);

  // Dynamic Financial Expenditure & Inflow Data Sets
  const dynamicFinancialData = useMemo(() => {
    if (timeFilter === 'daily') {
      return [
        { label: 'Mon', expenditure: 110000, stockInflow: 150000 },
        { label: 'Tue', expenditure: 125000, stockInflow: 140000 },
        { label: 'Wed', expenditure: 115000, stockInflow: 220000 },
        { label: 'Thu', expenditure: 105000, stockInflow: 110000 },
        { label: 'Fri', expenditure: 145000, stockInflow: 310000 },
        { label: 'Sat', expenditure: 130000, stockInflow: 125000 },
        { label: 'Sun', expenditure: 160000, stockInflow: 180000 }
      ];
    } else if (timeFilter === 'weekly') {
      return [
        { label: 'Week 1', expenditure: 950000, stockInflow: 1200000 },
        { label: 'Week 2', expenditure: 1120000, stockInflow: 1350000 },
        { label: 'Week 3', expenditure: 1080000, stockInflow: 1150000 },
        { label: 'Week 4', expenditure: 1250000, stockInflow: 1500000 }
      ];
    } else if (timeFilter === 'monthly') {
      return [
        { label: 'May', expenditure: 3600000, stockInflow: 4100000 },
        { label: 'Jun', expenditure: 3200000, stockInflow: 3800000 },
        { label: 'Jul', expenditure: 2800000, stockInflow: 3100000 },
        { label: 'Aug', expenditure: 4100000, stockInflow: 4500000 },
        { label: 'Sep', expenditure: 5600000, stockInflow: 6200000 },
        { label: 'Oct', expenditure: 4800000, stockInflow: 5100000 }
      ];
    } else {
      return [
        { label: 'Term 1', expenditure: 14200000, stockInflow: 16500000 },
        { label: 'Term 2', expenditure: 15100000, stockInflow: 17200000 },
        { label: 'Term 3', expenditure: 16800000, stockInflow: 18900000 }
      ];
    }
  }, [timeFilter]);

  // Aggregate stats for financial header
  const totalInflowSum = dynamicFinancialData.reduce((s, d) => s + d.stockInflow, 0);
  const totalExpSum = dynamicFinancialData.reduce((s, d) => s + d.expenditure, 0);
  const netSurplus = totalInflowSum - totalExpSum;

  return (
    <div className="space-y-8">
      
      {/* Title & Timeframe Selector */}
      <DashboardPageHeader
        title={t('dirDashboardTitle')}
        subtitle={t('dirDashboardSub')}
        variant="navy"
      >
        {/* Time Segmented Control */}
        <div className="inline-flex p-1 rounded-xl bg-slate-800/80 border border-slate-700/80 self-start sm:self-auto text-xs font-semibold">
          {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setTimeFilter(filter)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-colors ${
                timeFilter === filter
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </DashboardPageHeader>

      {/* Emergency Override Banner (if active) */}
      {schedule.emergencyOverrideActive && (
        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold">
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            <span>Emergency Stock Override is currently ACTIVE.</span>
            <span className="text-xs font-normal opacity-80">Reason: {schedule.overrideReason || 'Administrative dispensation'}</span>
          </div>
          <Link
            to="/dashboard/schedule"
            className="text-xs font-bold underline hover:text-amber-900"
          >
            Manage Schedule
          </Link>
        </div>
      )}

      {/* 4 Primary Executive KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* KPI 1: Admissions */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalApps')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {totalApps}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
              <span className="text-amber-600 dark:text-amber-400 font-semibold">{pendingApps} pending</span>
              <span>·</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{approvedStudents} approved</span>
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/admissions"
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
            >
              <span>Manage Admissions</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 2: Stock Health */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalStockHealth')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                <Package className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums">
              {stockHealthPct}%
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {totalStockKg.toLocaleString()} Kg total inventory on campus
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/stock"
              className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              <span>Inspect Stock</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 3: Valuation */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiTotalInventoryVal')}
              </span>
              <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-mono tabular-nums truncate">
              {totalInventoryValRwf.toLocaleString()} RWF
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Food reserves asset valuation
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/reports"
              className="inline-flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              <span>Financial Reports</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

        {/* KPI 4: Low Stock Warnings */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t('kpiLowStockAlerts')}
              </span>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${lowStockProducts.length > 0 ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-600' : 'bg-slate-100 text-slate-500'}`}>
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className={`text-2xl sm:text-3xl font-extrabold font-mono tabular-nums ${lowStockProducts.length > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-white'}`}>
              {lowStockProducts.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 truncate">
              {lowStockProducts.length > 0
                ? `${lowStockProducts.map((p) => p.nameRw).join(', ')} below threshold`
                : 'All product levels nominal'}
            </div>
          </div>
          <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800/80">
            <Link
              to="/dashboard/stock"
              className="inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline"
            >
              <span>Reorder Products</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>

      </div>

      {/* Row of Charts (2 columns: Doughnut + Multi-Bar) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        
        {/* Chart 1: Admissions Distribution Doughnut Chart (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-[#0B1930] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm transition-colors flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <PieIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span>{t('chartAdmissionsByDept')}</span>
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Verified candidate enrollments breakdown
                </p>
              </div>

              {/* Dimension Switcher Pills */}
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[10px] font-semibold self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => setDonutMode('dept')}
                  className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                    donutMode === 'dept'
                      ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-bold shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Dept
                </button>
                <button
                  type="button"
                  onClick={() => setDonutMode('level')}
                  className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                    donutMode === 'level'
                      ? 'bg-white dark:bg-slate-700 text-purple-600 dark:text-purple-400 font-bold shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Level
                </button>
                <button
                  type="button"
                  onClick={() => setDonutMode('status')}
                  className={`px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                    donutMode === 'status'
                      ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 font-bold shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  Status
                </button>
              </div>
            </div>

            {/* Doughnut Chart with Center Metric */}
            <div className="relative h-64 sm:h-72 w-full flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <defs>
                    <linearGradient id="donutBlue" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" />
                      <stop offset="100%" stopColor="#1d4ed8" />
                    </linearGradient>
                    <linearGradient id="donutEmerald" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#047857" />
                    </linearGradient>
                    <linearGradient id="donutPurple" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#a855f7" />
                      <stop offset="100%" stopColor="#7e22ce" />
                    </linearGradient>
                    <linearGradient id="donutAmber" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" />
                      <stop offset="100%" stopColor="#b45309" />
                    </linearGradient>
                    <linearGradient id="donutRose" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#f43f5e" />
                      <stop offset="100%" stopColor="#be123c" />
                    </linearGradient>
                  </defs>
                  <Pie
                    data={currentDonutData}
                    cx="50%"
                    cy="50%"
                    innerRadius={68}
                    outerRadius={95}
                    paddingAngle={4}
                    cornerRadius={6}
                    stroke={chartTheme.cardBg}
                    strokeWidth={3}
                    dataKey="value"
                  >
                    {currentDonutData.map((entry, index) => (
                      <Cell key={`donut-cell-${index}`} fill={entry.gradient || entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0];
                        const val = Number(data.value || 0);
                        const pct = currentDonutTotal > 0 ? ((val / currentDonutTotal) * 100).toFixed(1) : '0';
                        return (
                          <div className="bg-white/95 dark:bg-[#071A33]/95 backdrop-blur-md p-3 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-xl text-xs space-y-1">
                            <div className="flex items-center gap-2">
                              <span
                                className="w-2.5 h-2.5 rounded-full shrink-0"
                                style={{ backgroundColor: data.payload.color || '#2563eb' }}
                              />
                              <span className="font-bold text-slate-900 dark:text-white">
                                {data.name}
                              </span>
                            </div>
                            <div className="flex items-center justify-between gap-4 font-mono">
                              <span className="text-slate-500 dark:text-slate-400">Total:</span>
                              <span className="font-extrabold text-slate-900 dark:text-white">
                                {val} candidate{val === 1 ? '' : 's'}
                              </span>
                            </div>
                            <div className="flex items-center justify-between gap-4 font-mono">
                              <span className="text-slate-500 dark:text-slate-400">Share:</span>
                              <span className="font-bold text-emerald-600 dark:text-emerald-400">
                                {pct}%
                              </span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>

              {/* Center Metric Display */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none select-none">
                <span className="text-3xl sm:text-4xl font-black font-mono text-slate-900 dark:text-white tracking-tight tabular-nums">
                  {currentDonutTotal}
                </span>
                <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-0.5">
                  Applicants
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>RTB Enrolled</span>
                </span>
              </div>
            </div>
          </div>

          {/* Interactive Legend Badges */}
          <div className="pt-4 mt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-center gap-3">
            {currentDonutData.map((item, idx) => {
              const pct = currentDonutTotal > 0 ? Math.round((item.value / currentDonutTotal) * 100) : 0;
              return (
                <div
                  key={idx}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs"
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0 shadow-sm"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="font-medium text-slate-700 dark:text-slate-300 truncate max-w-[120px]">
                    {item.name}
                  </span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                    {item.value}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({pct}%)
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Multi-Bar Food Consumption Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-[#0B1930] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm transition-colors flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span>{t('chartStockConsumption')}</span>
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Cafeteria kitchen rations issued per time period (Kg)
                </p>
              </div>

              {/* Timeframe pill indicator */}
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 self-start sm:self-auto">
                <Clock className="w-3 h-3 text-emerald-600" />
                <span className="capitalize">{timeFilter} View</span>
              </div>
            </div>

            {/* Multi-Bar Chart Container */}
            <div className="h-64 sm:h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dynamicConsumptionData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                  <defs>
                    <linearGradient id="barRiceGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#047857" />
                    </linearGradient>
                    <linearGradient id="barFlourGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#60a5fa" />
                      <stop offset="100%" stopColor="#1d4ed8" />
                    </linearGradient>
                    <linearGradient id="barVegGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#fbbf24" />
                      <stop offset="100%" stopColor="#b45309" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={chartTheme.grid} opacity={0.8} />
                  <XAxis
                    dataKey="period"
                    tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                    tickLine={false}
                    axisLine={{ stroke: chartTheme.grid }}
                  />
                  <YAxis
                    tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `${val}`}
                  />
                  <Tooltip
                    cursor={{ fill: isDark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)' }}
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white/95 dark:bg-[#071A33]/95 backdrop-blur-md p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-xl text-xs space-y-2 min-w-[150px]">
                            <div className="font-bold text-slate-900 dark:text-white pb-1.5 border-b border-slate-100 dark:border-slate-800">
                              {label} Ration Issue
                            </div>
                            {payload.map((entry, idx) => (
                              <div key={idx} className="flex items-center justify-between gap-3">
                                <div className="flex items-center gap-1.5">
                                  <span
                                    className="w-2.5 h-2.5 rounded-sm"
                                    style={{ backgroundColor: entry.color }}
                                  />
                                  <span className="text-slate-600 dark:text-slate-300 font-medium">
                                    {entry.name}:
                                  </span>
                                </div>
                                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                                  {entry.value} Kg
                                </span>
                              </div>
                            ))}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend
                    wrapperStyle={{ paddingTop: 14, fontSize: 12, color: chartTheme.legendText }}
                    iconType="circle"
                  />
                  <Bar dataKey="Rice" name="Rice (Umuceri)" fill="url(#barRiceGrad)" radius={[6, 6, 0, 0]} maxBarSize={22} />
                  <Bar dataKey="Flour" name="Maize Flour (Kawunga)" fill="url(#barFlourGrad)" radius={[6, 6, 0, 0]} maxBarSize={22} />
                  <Bar dataKey="Veg" name="Vegetables & Tubers" fill="url(#barVegGrad)" radius={[6, 6, 0, 0]} maxBarSize={22} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Quick Metrics Bar below chart */}
          <div className="pt-4 mt-2 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-2 rounded-lg bg-emerald-50/60 dark:bg-emerald-950/30">
              <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold block">Rice Issued</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                {dynamicConsumptionData.reduce((s, d) => s + d.Rice, 0).toLocaleString()} Kg
              </span>
            </div>
            <div className="p-2 rounded-lg bg-blue-50/60 dark:bg-blue-950/30">
              <span className="text-[10px] text-blue-700 dark:text-blue-400 font-semibold block">Flour Issued</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                {dynamicConsumptionData.reduce((s, d) => s + d.Flour, 0).toLocaleString()} Kg
              </span>
            </div>
            <div className="p-2 rounded-lg bg-amber-50/60 dark:bg-amber-950/30">
              <span className="text-[10px] text-amber-700 dark:text-amber-400 font-semibold block">Produce Issued</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-xs sm:text-sm">
                {dynamicConsumptionData.reduce((s, d) => s + d.Veg, 0).toLocaleString()} Kg
              </span>
            </div>
          </div>
        </div>

      </div>

      {/* Row 2 Chart: Monthly Expenditure & Inflow (Full-Width Area Chart with Glow & Gradients) */}
      <div className="bg-white dark:bg-[#0B1930] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm transition-colors">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('chartInventoryValue')}
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Comparison of commodity procurement investments vs meal rationing consumption (RWF)
            </p>
          </div>

          {/* Quick Financial Summary Badges */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-400 text-[10px] block uppercase font-semibold">Total Inflow</span>
              <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-xs sm:text-sm tabular-nums">
                {totalInflowSum.toLocaleString()} RWF
              </span>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-400 text-[10px] block uppercase font-semibold">Expenditure</span>
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400 text-xs sm:text-sm tabular-nums">
                {totalExpSum.toLocaleString()} RWF
              </span>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800">
              <span className="text-emerald-700 dark:text-emerald-400 text-[10px] block uppercase font-semibold">Net Balance</span>
              <span className="font-mono font-extrabold text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm tabular-nums flex items-center gap-1">
                <span>+{netSurplus.toLocaleString()} RWF</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              </span>
            </div>
          </div>
        </div>

        {/* Area Chart Container */}
        <div className="h-72 sm:h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={dynamicFinancialData} margin={{ top: 10, right: 15, left: 10, bottom: 0 }}>
              <defs>
                <linearGradient id="areaInflowGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="areaExpenditureGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={chartTheme.grid} opacity={0.8} />
              <XAxis
                dataKey="label"
                tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                tickLine={false}
                axisLine={{ stroke: chartTheme.grid }}
              />
              <YAxis
                tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `${(val / 1000000).toFixed(1)}M`}
              />
              <Tooltip
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white/95 dark:bg-[#071A33]/95 backdrop-blur-md p-4 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-xl text-xs space-y-2 min-w-[200px]">
                        <div className="font-bold text-slate-900 dark:text-white pb-1.5 border-b border-slate-100 dark:border-slate-800">
                          Period: {label}
                        </div>
                        {payload.map((entry, idx) => (
                          <div key={idx} className="flex items-center justify-between gap-4">
                            <div className="flex items-center gap-1.5">
                              <span
                                className="w-2.5 h-2.5 rounded-full"
                                style={{ backgroundColor: entry.color }}
                              />
                              <span className="text-slate-600 dark:text-slate-300 font-medium">
                                {entry.name}:
                              </span>
                            </div>
                            <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                              {Number(entry.value || 0).toLocaleString()} RWF
                            </span>
                          </div>
                        ))}
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend
                wrapperStyle={{ paddingTop: 16, fontSize: 12, color: chartTheme.legendText }}
                iconType="circle"
              />
              <Area
                type="monotone"
                dataKey="stockInflow"
                name="Stock Inflow Value"
                stroke="#10b981"
                strokeWidth={3}
                fill="url(#areaInflowGrad)"
                activeDot={{ r: 6, fill: '#10b981', stroke: chartTheme.cardBg, strokeWidth: 3 }}
              />
              <Area
                type="monotone"
                dataKey="expenditure"
                name="Consumption Expenditure"
                stroke="#3b82f6"
                strokeWidth={3}
                fill="url(#areaExpenditureGrad)"
                activeDot={{ r: 6, fill: '#3b82f6', stroke: chartTheme.cardBg, strokeWidth: 3 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Quick Overview Table: Recent Applications Pending Review */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Student Admission Applications Requiring Director Review
            </h3>
            <p className="text-xs text-slate-500">Only the Director holds legal authority to approve or reject candidates</p>
          </div>
          <Link
            to="/dashboard/admissions"
            className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            View All ({applications.length})
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500">
                <th className="py-3 px-4 font-bold">Tracking #</th>
                <th className="py-3 px-4 font-bold">Applicant Name</th>
                <th className="py-3 px-4 font-bold">Department</th>
                <th className="py-3 px-4 font-bold">S3 Score</th>
                <th className="py-3 px-4 font-bold">Submitted Date</th>
                <th className="py-3 px-4 font-bold">Status</th>
                <th className="py-3 px-4 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
              {applications.slice(0, 4).map((app) => (
                <tr key={app.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                    {app.trackingNumber}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                    {app.fullName}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                    {app.department === 'software_development' ? 'Software Development' : 'Automobile Tech'}
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {app.s3AggregateScore} pts
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-500">
                    {new Date(app.submittedAt).toLocaleDateString()}
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        app.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : app.status === 'rejected'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      {app.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <Link
                      to={`/dashboard/admissions?review=${app.id}`}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-all"
                    >
                      <span>Review</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
