/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { StockSchedule, User } from '../../types/index.ts';
import {
  Clock,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Users,
  Settings,
  Globe,
  Save,
  Power
} from 'lucide-react';

export const SettingsScheduleManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  const [schedule, setSchedule] = useState<StockSchedule>(() => StorageService.getSchedule());
  const [usersList, setUsersList] = useState<User[]>(() => StorageService.getUsers());

  // Schedule form state
  const [morningStart, setMorningStart] = useState(schedule.morningStart);
  const [morningEnd, setMorningEnd] = useState(schedule.morningEnd);
  const [eveningStart, setEveningStart] = useState(schedule.eveningStart);
  const [eveningEnd, setEveningEnd] = useState(schedule.eveningEnd);
  const [enforceHours, setEnforceHours] = useState(schedule.enforceHours);

  // Override form state
  const [overrideReason, setOverrideReason] = useState(schedule.overrideReason || '');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedback({ type, text });
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (user?.role !== 'director') {
      showFeedback('error', 'Only the School Director can modify stock working hours.');
      return;
    }

    const updated: StockSchedule = {
      ...schedule,
      morningStart,
      morningEnd,
      eveningStart,
      eveningEnd,
      enforceHours,
      updatedAt: new Date().toISOString()
    };

    StorageService.saveSchedule(updated);
    setSchedule(updated);

    StorageService.addAuditLog({
      action: 'STOCK_SCHEDULE_UPDATED',
      category: 'stock_schedule',
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      details: `Director updated working hours: Morning (${morningStart}-${morningEnd}), Evening (${eveningStart}-${eveningEnd}), Enforced: ${enforceHours}`,
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: 'Stock Working Hours Updated',
      titleRw: 'Amasaha y’Ububiko Yahinduwe',
      message: `Director configured storage schedule: ${morningStart}-${morningEnd} & ${eveningStart}-${eveningEnd}.`,
      messageRw: `Umuyobozi yahinduye amasaha yo gusohora ibiribwa: ${morningStart}-${morningEnd} na ${eveningStart}-${eveningEnd}.`,
      type: 'info',
      category: 'override',
      targetRoles: ['director', 'accountant', 'animator']
    });

    showFeedback('success', 'Stock operational schedule updated successfully.');
  };

  const handleToggleEmergencyOverride = (enable: boolean) => {
    if (user?.role !== 'director') {
      showFeedback('error', 'Only the School Director can authorize emergency overrides.');
      return;
    }

    if (enable && !overrideReason.trim()) {
      showFeedback('error', 'A formal emergency justification reason is mandatory.');
      return;
    }

    const updated: StockSchedule = {
      ...schedule,
      emergencyOverrideActive: enable,
      overrideReason: enable ? overrideReason.trim() : undefined,
      overrideSetBy: enable ? user.fullName : undefined,
      updatedAt: new Date().toISOString()
    };

    StorageService.saveSchedule(updated);
    setSchedule(updated);

    StorageService.addAuditLog({
      action: enable ? 'EMERGENCY_OVERRIDE_ENABLED' : 'EMERGENCY_OVERRIDE_DISABLED',
      category: 'stock_schedule',
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      details: enable
        ? `Director ACTIVATED Emergency Stock Override. Justification: ${overrideReason.trim()}`
        : 'Director DEACTIVATED Emergency Stock Override. Normal schedule restored.',
      ipAddress: '197.243.34.82'
    });

    addNotification({
      title: enable ? 'EMERGENCY STOCK OVERRIDE ACTIVE' : 'Emergency Override Deactivated',
      titleRw: enable ? 'ICYEMEZO CYIHUTIRWA CY’UBUBIKO CYAFUNGUWE' : 'Icyemezo Cyihutirwa Cyahagaritswe',
      message: enable
        ? `Director authorized temporary bypass: "${overrideReason.trim()}". Animator can issue stock immediately.`
        : 'Normal schedule restrictions restored by School Director.',
      messageRw: enable
        ? `Umuyobozi yemeje ko ububiko bufungurwa mu buryo bwihutirwa: "${overrideReason.trim()}".`
        : 'Amasaha asanzwe y’ububiko yongeye gukurikizwa.',
      type: enable ? 'warning' : 'info',
      category: 'override',
      targetRoles: ['director', 'accountant', 'animator']
    });

    showFeedback(
      'success',
      enable
        ? 'Emergency override ACTIVATED. Animator can issue stock immediately.'
        : 'Emergency override deactivated. Schedule restored.'
    );
  };

  const handleToggleUserStatus = (userId: string) => {
    if (user?.role !== 'director') return;
    const target = usersList.find((u) => u.id === userId);
    if (!target) return;
    if (target.id === user.id) {
      alert('You cannot deactivate your own Director super admin account.');
      return;
    }

    const updatedStatus = target.status === 'active' ? 'inactive' : 'active';
    const updatedUsers = usersList.map((u) =>
      u.id === userId ? { ...u, status: updatedStatus as any } : u
    );

    StorageService.saveUsers(updatedUsers);
    setUsersList(updatedUsers);

    StorageService.addAuditLog({
      action: 'USER_STATUS_MODIFIED',
      category: 'system',
      userId: user.id,
      userName: user.fullName,
      userRole: user.role,
      details: `Director modified account status for ${target.fullName} (${target.role}) to ${updatedStatus.toUpperCase()}`,
      ipAddress: '197.243.34.82'
    });

    showFeedback('success', `Account for ${target.fullName} marked as ${updatedStatus}.`);
  };

  return (
    <div className="space-y-8">
      
      {/* Title */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          {t('scheduleTitle')}
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          {t('scheduleSub')}
        </p>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center gap-2 border ${
            feedback.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* Two-Column Grid: Stock Hours & Emergency Override */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Left: Schedule Configuration */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
            <Clock className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Authorized Stock Window Configuration
            </h3>
          </div>

          <form onSubmit={handleSaveSchedule} className="space-y-5 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900 dark:text-white block">
                  Timezone Standard
                </span>
                <span className="text-slate-500">Rwanda Standard Time (CAT / UTC+2)</span>
              </div>
              <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                Africa/Kigali
              </span>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                {t('morningWindow')} (Breakfast rations)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-slate-400 block mb-1">Opens</span>
                  <input
                    type="time"
                    required
                    value={morningStart}
                    onChange={(e) => setMorningStart(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block mb-1">Closes</span>
                  <input
                    type="time"
                    required
                    value={morningEnd}
                    onChange={(e) => setMorningEnd(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-2">
                {t('eveningWindow')} (Dinner rations)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-slate-400 block mb-1">Opens</span>
                  <input
                    type="time"
                    required
                    value={eveningStart}
                    onChange={(e) => setEveningStart(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block mb-1">Closes</span>
                  <input
                    type="time"
                    required
                    value={eveningEnd}
                    onChange={(e) => setEveningEnd(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">
                    {t('enforceScheduleToggle')}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Restricts Animator from issuing stock outside configured windows
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={enforceHours}
                  onChange={(e) => setEnforceHours(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
              </label>
            </div>

            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20"
            >
              <Save className="w-4 h-4" />
              <span>Save Schedule Settings</span>
            </button>
          </form>
        </div>

        {/* Right: Emergency Override Control */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
              <ShieldAlert className="w-5 h-5 text-amber-500" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('emergencyOverrideTitle')}
              </h3>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
              {t('emergencyOverrideDesc')}
            </p>

            <div className={`p-4 rounded-xl border mb-6 text-xs ${
              schedule.emergencyOverrideActive
                ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
            }`}>
              <div className="font-bold mb-1 flex items-center gap-1.5">
                <Power className="w-4 h-4 text-rose-600" />
                <span>
                  Current Status:{' '}
                  {schedule.emergencyOverrideActive ? 'ACTIVE (BYPASS ENGAGED)' : 'INACTIVE (NORMAL WINDOWS)'}
                </span>
              </div>
              {schedule.emergencyOverrideActive && (
                <div className="mt-2 text-[11px] leading-relaxed">
                  Authorized by: <strong>{schedule.overrideSetBy || 'Director'}</strong><br />
                  Justification: &ldquo;{schedule.overrideReason}&rdquo;
                </div>
              )}
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                {t('overrideReasonLabel')} *
              </label>
              <textarea
                rows={3}
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="e.g. Early morning regional sports tournament delegation breakfast or emergency delivery arrival..."
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 mt-6 flex justify-end gap-3">
            {schedule.emergencyOverrideActive ? (
              <button
                type="button"
                onClick={() => handleToggleEmergencyOverride(false)}
                className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-slate-800 hover:bg-slate-700 shadow-md"
              >
                {t('deactivateOverrideBtn')}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleToggleEmergencyOverride(true)}
                className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-rose-600 hover:bg-rose-500 shadow-md shadow-rose-600/20"
              >
                {t('activateOverrideBtn')}
              </button>
            )}
          </div>
        </div>

      </div>

      {/* Staff Accounts Management (Director) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-purple-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Authorized Staff Accounts & Roles
              </h3>
              <p className="text-xs text-slate-500">
                Director super administrator governance of school user permissions
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                <th className="py-2.5 px-3 font-bold">Staff Member</th>
                <th className="py-2.5 px-3 font-bold">Role & Authority</th>
                <th className="py-2.5 px-3 font-bold">Phone Contact</th>
                <th className="py-2.5 px-3 font-bold">2FA Security</th>
                <th className="py-2.5 px-3 font-bold">Status</th>
                <th className="py-2.5 px-3 font-bold text-right">Account Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {usersList.map((u) => (
                <tr key={u.id}>
                  <td className="py-3.5 px-3">
                    <div className="font-bold text-slate-900 dark:text-white">
                      {u.fullName}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {u.email} · username: {u.username}
                    </div>
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="uppercase font-bold text-[10px] px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 font-mono text-slate-600 dark:text-slate-400">
                    {u.phone}
                  </td>
                  <td className="py-3.5 px-3">
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Mandatory 2FA Active
                    </span>
                  </td>
                  <td className="py-3.5 px-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        u.status === 'active'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                      }`}
                    >
                      {u.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-right">
                    {u.id !== user?.id && (
                      <button
                        onClick={() => handleToggleUserStatus(u.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                          u.status === 'active'
                            ? 'text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30'
                            : 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30'
                        }`}
                      >
                        {u.status === 'active' ? 'Deactivate' : 'Reactivate'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
