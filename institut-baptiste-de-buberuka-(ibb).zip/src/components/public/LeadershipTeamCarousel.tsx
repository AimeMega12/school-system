/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { StorageService } from '../../services/storage.ts';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { User } from '../../types/index.ts';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface LeadershipProfileSlot {
  id: string;
  role: 'director' | 'accountant' | 'animator' | 'animatrice';
  positionKey: 'dirPosition' | 'accPosition' | 'aniPosition' | 'anitricePosition';
  defaultPosition: string;
  defaultInitials: string;
}

const PERMANENT_SLOTS: LeadershipProfileSlot[] = [
  {
    id: 'slot_director',
    role: 'director',
    positionKey: 'dirPosition',
    defaultPosition: 'School Director / Head of Institution',
    defaultInitials: 'DIR'
  },
  {
    id: 'slot_accountant',
    role: 'accountant',
    positionKey: 'accPosition',
    defaultPosition: 'School Accountant',
    defaultInitials: 'ACC'
  },
  {
    id: 'slot_animator',
    role: 'animator',
    positionKey: 'aniPosition',
    defaultPosition: 'School Animator',
    defaultInitials: 'ANI'
  },
  {
    id: 'slot_animatrice',
    role: 'animatrice',
    positionKey: 'anitricePosition',
    defaultPosition: 'School Animatrice',
    defaultInitials: 'SA'
  }
];

export const LeadershipTeamCarousel: React.FC = () => {
  const { t } = useLanguage();
  const [users, setUsers] = useState<User[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load existing staff records on mount
  useEffect(() => {
    try {
      const loadedUsers = StorageService.getUsers();
      setUsers(loadedUsers);
    } catch (e) {
      console.error('Failed to load staff profiles for carousel:', e);
    }
  }, []);

  // Map users to the 4 permanent positions in exact order
  const profiles = PERMANENT_SLOTS.map((slot) => {
    let matchedUser: User | undefined;

    if (slot.role === 'animatrice') {
      matchedUser = users.find(
        (u) =>
          (u as any).role === 'animatrice' ||
          u.username.toLowerCase().includes('animatrice') ||
          u.email.toLowerCase().includes('animatrice')
      );
    } else {
      matchedUser = users.find((u) => u.role === slot.role);
    }

    const name = matchedUser?.fullName || '';
    const photo = matchedUser?.avatarUrl || '';
    const position = t(slot.positionKey) || slot.defaultPosition;

    // Calculate initials
    let initials = slot.defaultInitials;
    if (name) {
      const parts = name.trim().split(/\s+/);
      if (parts.length >= 2) {
        initials = `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
      } else if (parts[0]) {
        initials = parts[0].substring(0, 2).toUpperCase();
      }
    }

    return {
      slotId: slot.id,
      role: slot.role,
      position,
      name, // If empty (e.g. Animatrice), only position is displayed
      photo,
      initials
    };
  });

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % PERMANENT_SLOTS.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + PERMANENT_SLOTS.length) % PERMANENT_SLOTS.length);
  }, []);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  // Reset & restart the 5-second (5,000ms) timer
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      return;
    }

    if (isHovered) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      nextSlide();
    }, 5000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIndex, isHovered, nextSlide]);

  return (
    <div
      aria-label="Karenge Adventist Leadership & Administration Team"
      className="relative w-full max-w-4xl mx-auto select-none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Compact Header Label */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-300">
            {t('leadershipTitle')}
          </span>
        </div>
        <span className="text-[11px] text-slate-300/80 font-medium">
          {profiles[currentIndex].position}
        </span>
      </div>

      {/* 3D Layered Carousel Viewport (Compact Floating Cards over Campus Image) */}
      <div className="relative w-full min-h-[290px] sm:min-h-[330px] md:min-h-[350px] flex items-center justify-center">
        {/* Previous Arrow */}
        <button
          type="button"
          onClick={prevSlide}
          aria-label="Previous leadership profile"
          className="absolute left-0 sm:left-2 md:left-4 z-40 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-slate-950/75 hover:bg-emerald-600 text-white border border-white/20 hover:border-emerald-400 flex items-center justify-center transition-all shadow-xl cursor-pointer backdrop-blur-md active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
        >
          <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Next Arrow */}
        <button
          type="button"
          onClick={nextSlide}
          aria-label="Next leadership profile"
          className="absolute right-0 sm:right-2 md:right-4 z-40 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-slate-950/75 hover:bg-emerald-600 text-white border border-white/20 hover:border-emerald-400 flex items-center justify-center transition-all shadow-xl cursor-pointer backdrop-blur-md active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
        >
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>

        {/* Floating Cards Deck */}
        <div className="relative w-full h-[270px] sm:h-[310px] md:h-[330px] flex items-center justify-center">
          {profiles.map((profile, idx) => {
            const offset = (idx - currentIndex + PERMANENT_SLOTS.length) % PERMANENT_SLOTS.length;
            const isCenter = offset === 0;
            const isRight = offset === 1;
            const isLeft = offset === 3;

            const hasValidPhoto = profile.photo && !imgErrors[profile.slotId];

            let cardPositionClass = '';
            let pointerClass = '';

            if (isCenter) {
              cardPositionClass =
                'z-30 opacity-100 scale-100 translate-x-0 shadow-2xl ring-1 ring-white/30';
              pointerClass = 'pointer-events-auto';
            } else if (isRight) {
              cardPositionClass =
                'z-10 opacity-40 sm:opacity-50 scale-[0.80] sm:scale-[0.83] translate-x-[52%] sm:translate-x-[64%] md:translate-x-[72%] shadow-xl hover:opacity-75 hover:scale-[0.86]';
              pointerClass = 'pointer-events-auto cursor-pointer';
            } else if (isLeft) {
              cardPositionClass =
                'z-10 opacity-40 sm:opacity-50 scale-[0.80] sm:scale-[0.83] -translate-x-[52%] sm:-translate-x-[64%] md:-translate-x-[72%] shadow-xl hover:opacity-75 hover:scale-[0.86]';
              pointerClass = 'pointer-events-auto cursor-pointer';
            } else {
              cardPositionClass =
                'z-0 opacity-0 scale-[0.70] translate-x-0 pointer-events-none';
              pointerClass = 'pointer-events-none';
            }

            return (
              <div
                key={profile.slotId}
                onClick={() => {
                  if (isLeft || isRight) {
                    goToSlide(idx);
                  }
                }}
                className={`absolute w-[200px] sm:w-[240px] md:w-[260px] h-[260px] sm:h-[300px] md:h-[320px] rounded-2xl overflow-hidden bg-slate-900/90 border border-white/20 transition-all duration-700 ease-out select-none backdrop-blur-xs ${cardPositionClass} ${pointerClass}`}
              >
                {/* Staff Photograph (Fills Card as Main Visual Element) */}
                {hasValidPhoto ? (
                  <img
                    src={profile.photo}
                    alt={profile.name || profile.position}
                    onError={() => {
                      setImgErrors((prev) => ({
                        ...prev,
                        [profile.slotId]: true
                      }));
                    }}
                    className="w-full h-full object-cover object-center"
                  />
                ) : (
                  /* Professional Initials-Based Placeholder */
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950 text-emerald-400">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full border-2 border-emerald-400/40 bg-slate-900/80 flex items-center justify-center shadow-inner mb-2">
                      <span className="text-xl sm:text-2xl font-extrabold tracking-wider font-mono">
                        {profile.initials}
                      </span>
                    </div>
                    <span className="text-[10px] font-semibold tracking-widest uppercase text-slate-400">
                      {profile.role.toUpperCase()}
                    </span>
                  </div>
                )}

                {/* Dark Gradient Overlay with ONLY Name & Official Position */}
                <div className="absolute inset-x-0 bottom-0 pt-16 pb-3.5 px-3.5 sm:px-4 bg-gradient-to-t from-slate-950/95 via-slate-950/70 to-transparent flex flex-col justify-end text-left pointer-events-none">
                  {profile.name ? (
                    <>
                      <h3 className="text-xs sm:text-sm font-bold text-white tracking-tight leading-snug drop-shadow-md truncate">
                        {profile.name}
                      </h3>
                      <p className="text-[10px] sm:text-[11px] font-semibold text-emerald-400 mt-0.5 drop-shadow-sm truncate">
                        {profile.position}
                      </p>
                    </>
                  ) : (
                    <h3 className="text-xs sm:text-sm font-bold text-white tracking-tight leading-snug drop-shadow-md truncate">
                      {profile.position}
                    </h3>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Four Indicator Dots & Progress */}
      <div className="mt-4 flex items-center justify-center gap-2">
        {profiles.map((p, idx) => (
          <button
            key={p.slotId}
            type="button"
            role="tab"
            aria-selected={currentIndex === idx}
            aria-label={`Go to ${p.position}${p.name ? `: ${p.name}` : ''}`}
            onClick={() => goToSlide(idx)}
            className={`transition-all duration-300 rounded-full cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 ${
              currentIndex === idx
                ? 'w-7 h-2 bg-emerald-400 shadow-sm shadow-emerald-400/50'
                : 'w-2 h-2 bg-white/40 hover:bg-white/70'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
