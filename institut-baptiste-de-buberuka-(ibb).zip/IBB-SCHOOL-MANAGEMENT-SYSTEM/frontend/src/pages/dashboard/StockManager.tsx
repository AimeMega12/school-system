/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { useNotifications } from '../../context/NotificationContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { Product, StockTransaction, Supplier } from '../../types/index.ts';
import {
  Package,
  Plus,
  ArrowDownRight,
  ArrowUpRight,
  AlertTriangle,
  History,
  TrendingDown,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  FileSpreadsheet,
  RotateCcw,
  ShieldAlert
} from 'lucide-react';

export const StockManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { addNotification } = useNotifications();

  // Database states
  const [products, setProducts] = useState<Product[]>(() => StorageService.getProducts());
  const [transactions, setTransactions] = useState<StockTransaction[]>(() =>
    StorageService.getTransactions()
  );
  const [suppliers] = useState<Supplier[]>(() => StorageService.getSuppliers());
  const schedule = StorageService.getSchedule();

  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'corrections'>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isStockInModalOpen, setIsStockInModalOpen] = useState(false);
  const [isStockOutModalOpen, setIsStockOutModalOpen] = useState(false);
  const [isAddProductModalOpen, setIsAddProductModalOpen] = useState(false);
  const [isCorrectionModalOpen, setIsCorrectionModalOpen] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Stock In Form State
  const [inProductId, setInProductId] = useState(products[0]?.id || '');
  const [inQuantity, setInQuantity] = useState<number>(500);
  const [inSupplierId, setInSupplierId] = useState(suppliers[0]?.id || '');
  const [inUnitPrice, setInUnitPrice] = useState<number>(1200);
  const [inDeliveryDate, setInDeliveryDate] = useState(new Date().toISOString().split('T')[0]);
  const [inExpirationDate, setInExpirationDate] = useState('2027-10-31');
  const [inNotes, setInNotes] = useState('');

  // Stock Out Form State
  const [outProductId, setOutProductId] = useState(products[0]?.id || '');
  const [outQuantity, setOutQuantity] = useState<number>(50);
  const [outMealCategory, setOutMealCategory] = useState<'breakfast' | 'lunch' | 'dinner' | 'special_event'>('lunch');
  const [outNotes, setOutNotes] = useState('');

  // Add Product Form State
  const [newCode, setNewCode] = useState('IBB-FD-08');
  const [newNameRw, setNewNameRw] = useState('');
  const [newNameEn, setNewNameEn] = useState('');
  const [newCategory, setNewCategory] = useState<any>('cereal');
  const [newUnit, setNewUnit] = useState<any>('Kg');
  const [newMinThreshold, setNewMinThreshold] = useState<number>(200);
  const [newTargetCap, setNewTargetCap] = useState<number>(1500);
  const [newCostRwf, setNewCostRwf] = useState<number>(1000);

  // Correction Form State
  const [corrTxId, setCorrTxId] = useState(transactions[0]?.id || '');
  const [corrQty, setCorrQty] = useState<number>(0);
  const [corrReason, setCorrReason] = useState('');

  const reloadData = () => {
    setProducts(StorageService.getProducts());
    setTransactions(StorageService.getTransactions());
  };

  const showFeedback = (type: 'success' | 'error', text: string) => {
    setFeedbackMsg({ type, text });
    setTimeout(() => setFeedbackMsg(null), 4500);
  };

  // Check Animator Working Hours
  const workingHoursCheck = StorageService.isStockWindowOpen(schedule);

  // Check if Animator has delegated Stock In permission
  const delegations = StorageService.getDelegations();
  const activeDelegation = delegations.find(
    (d) =>
      d.grantedToUserId === user?.id &&
      d.status === 'active' &&
      new Date(d.expiresAt) > new Date()
  );

  const canPerformStockIn = user?.role === 'accountant' || user?.role === 'director' || !!activeDelegation;

  // Handle Main Stock In
  const handleStockInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canPerformStockIn) {
      showFeedback('error', 'You do not have authorization to perform Main Stock In.');
      return;
    }

    const prod = products.find((p) => p.id === inProductId);
    if (!prod) return;

    const supplier = suppliers.find((s) => s.id === inSupplierId);

    const newTx: StockTransaction = {
      id: `tx_${Date.now()}`,
      transactionNumber: `TX-IN-${Date.now().toString().slice(-4)}`,
      productId: prod.id,
      productName: prod.name,
      type: 'stock_in',
      quantity: Number(inQuantity),
      unit: prod.unit,
      unitPriceRwf: Number(inUnitPrice),
      totalPriceRwf: Number(inQuantity) * Number(inUnitPrice),
      supplierId: supplier?.id,
      supplierName: supplier?.name || 'Local Direct Consignment',
      deliveryDate: inDeliveryDate,
      expirationDate: inExpirationDate,
      purposeNotes: inNotes.trim() || 'Main storage intake consignment',
      performedByUserId: user!.id,
      performedByUserName: user!.fullName,
      performedByRole: user!.role,
      isDelegatedStockIn: !!activeDelegation,
      createdAt: new Date().toISOString()
    };

    StorageService.addTransaction(newTx);

    // Audit log
    StorageService.addAuditLog({
      action: 'STOCK_IN_RECORDED',
      category: 'stock_in',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Stock In: +${inQuantity} ${prod.unit} of ${prod.name} received from ${newTx.supplierName}`,
      ipAddress: '197.243.34.82'
    });

    // Notify Director & Staff
    addNotification({
      title: `Stock In: +${inQuantity} ${prod.unit} ${prod.nameEn}`,
      titleRw: `Ibyinjiye mu Bubiko: +${inQuantity} ${prod.unit} bya ${prod.nameRw}`,
      message: `${user!.fullName} recorded consignment of ${inQuantity} ${prod.unit} from ${newTx.supplierName}.`,
      messageRw: `${user!.fullName} yakiriye kandi yandika ${inQuantity} ${prod.unit} bya ${prod.nameRw}.`,
      type: 'success',
      category: 'stock_in',
      targetRoles: ['director', 'accountant', 'animator'],
      relatedId: newTx.id
    });

    setIsStockInModalOpen(false);
    reloadData();
    showFeedback('success', `Recorded Stock In: +${inQuantity} ${prod.unit} of ${prod.name}`);
  };

  // Handle Daily Stock Out (Animator)
  const handleStockOutSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Enforce working hours
    if (!workingHoursCheck.isOpen && user?.role !== 'director') {
      showFeedback('error', `Action blocked! ${workingHoursCheck.reason}`);
      return;
    }

    const prod = products.find((p) => p.id === outProductId);
    if (!prod) return;

    if (Number(outQuantity) <= 0) {
      showFeedback('error', 'Quantity must be greater than zero.');
      return;
    }

    // Prevent reducing stock below zero!
    if (prod.currentStock < Number(outQuantity)) {
      showFeedback(
        'error',
        `Insufficient inventory! Only ${prod.currentStock} ${prod.unit} available. Cannot issue ${outQuantity} ${prod.unit}.`
      );
      return;
    }

    const newTx: StockTransaction = {
      id: `tx_${Date.now()}`,
      transactionNumber: `TX-OUT-${Date.now().toString().slice(-4)}`,
      productId: prod.id,
      productName: prod.name,
      type: 'stock_out',
      quantity: Number(outQuantity),
      unit: prod.unit,
      mealCategory: outMealCategory,
      purposeNotes: outNotes.trim() || `Daily ration for ${outMealCategory}`,
      performedByUserId: user!.id,
      performedByUserName: user!.fullName,
      performedByRole: user!.role,
      isEmergencyOverride: schedule.emergencyOverrideActive,
      createdAt: new Date().toISOString()
    };

    StorageService.addTransaction(newTx);

    // Audit log
    StorageService.addAuditLog({
      action: 'STOCK_OUT_RECORDED',
      category: 'stock_out',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Stock Out: -${outQuantity} ${prod.unit} of ${prod.name} for ${outMealCategory}`,
      ipAddress: '197.243.34.82'
    });

    // Notify Accountant & Director immediately
    addNotification({
      title: `Stock Out: -${outQuantity} ${prod.unit} ${prod.nameEn}`,
      titleRw: `Ibyasohotse: -${outQuantity} ${prod.unit} bya ${prod.nameRw}`,
      message: `${user!.fullName} issued ${outQuantity} ${prod.unit} ${prod.nameEn} for ${outMealCategory}.`,
      messageRw: `${user!.fullName} yasohoye ${outQuantity} ${prod.unit} bya ${prod.nameRw} byo guteka.`,
      type: 'info',
      category: 'stock_out',
      targetRoles: ['director', 'accountant'],
      relatedId: newTx.id
    });

    // Check if new stock is below threshold
    const remainingAfter = prod.currentStock - Number(outQuantity);
    if (remainingAfter <= prod.minThreshold) {
      addNotification({
        title: `Low Stock Warning: ${prod.nameEn}`,
        titleRw: `Integuza: ${prod.nameRw} Byenda Gushira`,
        message: `${prod.nameEn} remaining is ${remainingAfter} ${prod.unit} (Threshold: ${prod.minThreshold} ${prod.unit}).`,
        messageRw: `${prod.nameRw} bisigaye mu bubiko ni ${remainingAfter} ${prod.unit} (Urugero ntanga: ${prod.minThreshold} ${prod.unit}).`,
        type: 'warning',
        category: 'low_stock',
        targetRoles: ['director', 'accountant'],
        relatedId: prod.id
      });
    }

    setIsStockOutModalOpen(false);
    reloadData();
    showFeedback('success', `Issued ${outQuantity} ${prod.unit} of ${prod.name} for ${outMealCategory}`);
  };

  // Handle Add Product (Accountant / Director)
  const handleAddProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNameRw.trim() || !newNameEn.trim()) return;

    const newProduct: Product = {
      id: `prod_${Date.now()}`,
      code: newCode.trim(),
      name: `${newNameRw.trim()} (${newNameEn.trim()})`,
      nameRw: newNameRw.trim(),
      nameEn: newNameEn.trim(),
      category: newCategory,
      unit: newUnit,
      minThreshold: Number(newMinThreshold),
      targetCapacity: Number(newTargetCap),
      unitCostRwf: Number(newCostRwf),
      currentStock: 0,
      shelfLifeDays: 180
    };

    StorageService.addProduct(newProduct);

    StorageService.addAuditLog({
      action: 'PRODUCT_REGISTERED',
      category: 'stock_in',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `New food commodity registered: ${newProduct.name}`,
      ipAddress: '197.243.34.82'
    });

    setIsAddProductModalOpen(false);
    reloadData();
    showFeedback('success', `Registered new product: ${newProduct.name}`);
  };

  // Handle Correction Reversal
  const handleCorrectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!corrReason.trim()) {
      showFeedback('error', 'Mandatory audit reason must be provided for inventory corrections.');
      return;
    }

    const originalTx = transactions.find((t) => t.id === corrTxId);
    if (!originalTx) return;

    const corrTx: StockTransaction = {
      id: `tx_${Date.now()}`,
      transactionNumber: `TX-CORR-${Date.now().toString().slice(-4)}`,
      productId: originalTx.productId,
      productName: originalTx.productName,
      type: 'correction',
      quantity: Number(corrQty),
      unit: originalTx.unit,
      correctionOriginalTxId: originalTx.id,
      correctionReason: corrReason.trim(),
      performedByUserId: user!.id,
      performedByUserName: user!.fullName,
      performedByRole: user!.role,
      createdAt: new Date().toISOString()
    };

    StorageService.addTransaction(corrTx);

    StorageService.addAuditLog({
      action: 'INVENTORY_CORRECTION',
      category: 'stock_in',
      userId: user!.id,
      userName: user!.fullName,
      userRole: user!.role,
      details: `Inventory correction of ${corrQty > 0 ? '+' : ''}${corrQty} on ${originalTx.productName}. Reason: ${corrReason.trim()}`,
      ipAddress: '197.243.34.82'
    });

    setIsCorrectionModalOpen(false);
    reloadData();
    showFeedback('success', `Applied audited inventory correction of ${corrQty} ${originalTx.unit}`);
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nameRw.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Header & Quick Action Buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {t('stockTitle')}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {t('stockSubtitle')}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {canPerformStockIn && (
            <button
              onClick={() => setIsStockInModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-md shadow-blue-600/20 transition-all"
            >
              <ArrowDownRight className="w-4 h-4" />
              <span>{t('btnMainStockIn')}</span>
            </button>
          )}

          <button
            onClick={() => setIsStockOutModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20 transition-all"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>{t('btnCreateStockOut')}</span>
          </button>

          {(user?.role === 'accountant' || user?.role === 'director') && (
            <button
              onClick={() => setIsAddProductModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{t('btnAddProduct')}</span>
            </button>
          )}

          {(user?.role === 'accountant' || user?.role === 'director') && (
            <button
              onClick={() => setIsCorrectionModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Apply auditable correction"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Correction</span>
            </button>
          )}
        </div>
      </div>

      {/* Operational Working Hours Status Banner */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
        workingHoursCheck.isOpen
          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
          : 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
      }`}>
        <div className="flex items-center gap-2.5">
          <Clock className="w-4 h-4 shrink-0" />
          <div className="text-xs">
            <span className="font-extrabold uppercase mr-2 tracking-wider">
              {workingHoursCheck.isOpen ? t('windowStatusOpen') : t('windowStatusClosed')}
            </span>
            <span className="text-slate-600 dark:text-slate-400">
              {workingHoursCheck.reason}
            </span>
          </div>
        </div>

        {activeDelegation && (
          <div className="text-[11px] font-bold text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-950/60 px-2.5 py-1 rounded-md self-start sm:self-auto">
            Delegated Stock In Active (Expires: {new Date(activeDelegation.expiresAt).toLocaleTimeString()})
          </div>
        )}
      </div>

      {feedbackMsg && (
        <div
          className={`p-4 rounded-xl border text-xs flex items-center gap-2.5 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300'
              : 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
          }`}
        >
          {feedbackMsg.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          )}
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 text-xs font-semibold gap-6">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 transition-colors ${
            activeTab === 'overview'
              ? 'border-b-2 border-emerald-600 text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {t('tabStockOverview')} ({products.length})
        </button>
        <button
          onClick={() => setActiveTab('transactions')}
          className={`pb-3 transition-colors ${
            activeTab === 'transactions'
              ? 'border-b-2 border-emerald-600 text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          {t('tabTransactions')} ({transactions.length})
        </button>
      </div>

      {/* Tab 1: Inventory Table & Depletion Predictions */}
      {activeTab === 'overview' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter products by code, Kinyarwanda or English name..."
              className="w-full max-w-sm px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <div className="text-xs text-slate-400 hidden sm:block">
              {filteredProducts.length} commodities listed
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                  <th className="py-3 px-4 font-bold">Code</th>
                  <th className="py-3 px-4 font-bold">{t('productNameCol')}</th>
                  <th className="py-3 px-4 font-bold">{t('availableStockCol')}</th>
                  <th className="py-3 px-4 font-bold">{t('thresholdCol')}</th>
                  <th className="py-3 px-4 font-bold">{t('stockHealthCol')} (%)</th>
                  <th className="py-3 px-4 font-bold">{t('predictedDepletion')}</th>
                  <th className="py-3 px-4 font-bold text-right">Asset Value (RWF)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {filteredProducts.map((prod) => {
                  const isLow = prod.currentStock <= prod.minThreshold;
                  const pct = Math.min(100, Math.round((prod.currentStock / prod.targetCapacity) * 100));
                  const { dailyAverageKg, estDaysRemaining } = StorageService.calculateConsumptionRate(prod.id);
                  const totalValue = prod.currentStock * prod.unitCostRwf;

                  return (
                    <tr key={prod.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-500">
                        {prod.code}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          <span>{language === 'rw' ? prod.nameRw : prod.nameEn}</span>
                          {isLow && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300">
                              <AlertTriangle className="w-3 h-3" />
                              Low Stock
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 capitalize">
                          {language === 'rw' ? prod.nameEn : prod.nameRw} · {prod.category}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-extrabold text-slate-900 dark:text-white tabular-nums text-sm">
                        {prod.currentStock.toLocaleString()} {prod.unit}
                      </td>

                      <td className="py-3.5 px-4 font-mono text-slate-500 tabular-nums">
                        {prod.minThreshold} {prod.unit}
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-20 bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                isLow ? 'bg-rose-500' : pct < 50 ? 'bg-amber-500' : 'bg-emerald-500'
                              }`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold tabular-nums text-[11px]">
                            {pct}%
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-mono font-semibold text-slate-800 dark:text-slate-200 tabular-nums">
                          {estDaysRemaining > 0 ? `~${estDaysRemaining} ${t('estDaysRemaining')}` : 'Immediate Refill Needed'}
                        </div>
                        <span className="text-[10px] text-slate-400">
                          (burn rate ~{dailyAverageKg} {prod.unit}/day)
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white tabular-nums text-right">
                        {totalValue.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Transaction Ledger */}
      {activeTab === 'transactions' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase tracking-wider text-slate-500 bg-slate-50/50 dark:bg-slate-800/30">
                  <th className="py-3 px-4 font-bold">Tx #</th>
                  <th className="py-3 px-4 font-bold">Type</th>
                  <th className="py-3 px-4 font-bold">Product</th>
                  <th className="py-3 px-4 font-bold">Quantity</th>
                  <th className="py-3 px-4 font-bold">Staff Performer</th>
                  <th className="py-3 px-4 font-bold">Category / Supplier</th>
                  <th className="py-3 px-4 font-bold text-right">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 text-xs">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      {tx.transactionNumber}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          tx.type === 'stock_in'
                            ? 'bg-blue-100 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                            : tx.type === 'stock_out'
                            ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                        }`}
                      >
                        {tx.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                      {tx.productName}
                    </td>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                      {tx.type === 'stock_in' ? `+${tx.quantity}` : `-${tx.quantity}`} {tx.unit}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-400">
                      <div>{tx.performedByUserName}</div>
                      <span className="text-[10px] uppercase font-bold text-slate-400">{tx.performedByRole}</span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-500">
                      {tx.supplierName || tx.mealCategory || tx.purposeNotes || '—'}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-500 text-right">
                      {new Date(tx.createdAt).toLocaleDateString()} {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: Main Stock In */}
      {isStockInModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowDownRight className="w-5 h-5 text-blue-600" />
                <span>{t('recordStockInTitle')}</span>
              </h3>
              <button onClick={() => setIsStockInModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockInSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('selectProduct')} *
                </label>
                <select
                  value={inProductId}
                  onChange={(e) => setInProductId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('receivedQuantity')} *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={inQuantity}
                    onChange={(e) => setInQuantity(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('purchasePricePerUnit')}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={inUnitPrice}
                    onChange={(e) => setInUnitPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('supplierLabel')} *
                </label>
                <select
                  value={inSupplierId}
                  onChange={(e) => setInSupplierId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.address})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('deliveryDateLabel')}
                  </label>
                  <input
                    type="date"
                    value={inDeliveryDate}
                    onChange={(e) => setInDeliveryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('expirationDateLabel')}
                  </label>
                  <input
                    type="date"
                    value={inExpirationDate}
                    onChange={(e) => setInExpirationDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('stockInNotes')}
                </label>
                <input
                  type="text"
                  placeholder="Invoice number, batch number, transport receipt..."
                  value={inNotes}
                  onChange={(e) => setInNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsStockInModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-md shadow-blue-600/20"
                >
                  {t('submitStockInBtn')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Daily Stock Out (Animator) */}
      {isStockOutModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-emerald-600" />
                <span>{t('recordStockOutTitle')}</span>
              </h3>
              <button onClick={() => setIsStockOutModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockOutSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('selectProduct')} *
                </label>
                <select
                  value={outProductId}
                  onChange={(e) => setOutProductId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} — Current: {p.currentStock} {p.unit}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('issueQuantity')} *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={outQuantity}
                    onChange={(e) => setOutQuantity(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    {t('mealCategoryLabel')} *
                  </label>
                  <select
                    value={outMealCategory}
                    onChange={(e) => setOutMealCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="breakfast">{t('mealBreakfast')}</option>
                    <option value="lunch">{t('mealLunch')}</option>
                    <option value="dinner">{t('mealDinner')}</option>
                    <option value="special_event">{t('mealSpecial')}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('stockOutNotes')}
                </label>
                <input
                  type="text"
                  placeholder="Kitchen head cook recipient, head count..."
                  value={outNotes}
                  onChange={(e) => setOutNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsStockOutModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20"
                >
                  {t('submitStockOutBtn')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Register New Product */}
      {isAddProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t('btnAddProduct')}
              </h3>
              <button onClick={() => setIsAddProductModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddProductSubmit} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">Item Code</label>
                <input
                  type="text"
                  required
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Name in Kinyarwanda *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ibiharage"
                    value={newNameRw}
                    onChange={(e) => setNewNameRw(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold mb-1">Name in English *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dry Beans"
                    value={newNameEn}
                    onChange={(e) => setNewNameEn(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="cereal">Cereal</option>
                    <option value="flour">Flour</option>
                    <option value="oil">Oil</option>
                    <option value="vegetable">Vegetable</option>
                    <option value="tuber">Tuber</option>
                    <option value="sweetener">Sweetener</option>
                    <option value="spice">Spice</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Measurement Unit</label>
                  <select
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Kg">Kilograms (Kg)</option>
                    <option value="Litres">Litres</option>
                    <option value="Pieces">Pieces</option>
                    <option value="Bags">Bags</option>
                    <option value="Cartons">Cartons</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Min Threshold</label>
                  <input
                    type="number"
                    value={newMinThreshold}
                    onChange={(e) => setNewMinThreshold(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Target Capacity</label>
                  <input
                    type="number"
                    value={newTargetCap}
                    onChange={(e) => setNewTargetCap(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Unit Cost (RWF)</label>
                  <input
                    type="number"
                    value={newCostRwf}
                    onChange={(e) => setNewCostRwf(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddProductModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/20"
                >
                  Save Commodity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Audited Inventory Correction */}
      {isCorrectionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-lg w-full p-6 sm:p-8 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-amber-500" />
                <span>{t('correctionTitle')}</span>
              </h3>
              <button onClick={() => setIsCorrectionModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200">
              {t('correctionNotice')}
            </div>

            <form onSubmit={handleCorrectionSubmit} className="space-y-4">
              <div>
                <label className="block font-semibold mb-1">Target Transaction</label>
                <select
                  value={corrTxId}
                  onChange={(e) => setCorrTxId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {transactions.slice(0, 10).map((tx) => (
                    <option key={tx.id} value={tx.id}>
                      {tx.transactionNumber} — {tx.productName} ({tx.quantity} {tx.unit}) by {tx.performedByUserName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">
                  Quantity Adjustment (positive to add back, negative to reduce)
                </label>
                <input
                  type="number"
                  required
                  value={corrQty}
                  onChange={(e) => setCorrQty(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">
                  {t('correctionReasonLabel')} *
                </label>
                <textarea
                  required
                  rows={3}
                  value={corrReason}
                  onChange={(e) => setCorrReason(e.target.value)}
                  placeholder="e.g. Weighbridge calibration error in consignment entry..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCorrectionModalOpen(false)}
                  className="px-4 py-2 rounded-xl font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl font-bold text-white bg-amber-600 hover:bg-amber-500 shadow-md shadow-amber-600/20"
                >
                  {t('applyCorrectionBtn')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
