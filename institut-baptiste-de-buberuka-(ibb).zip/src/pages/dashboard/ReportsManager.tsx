/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useLanguage } from '../../context/LanguageContext.tsx';
import { useTheme } from '../../context/ThemeContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { StorageService } from '../../services/storage.ts';
import { DashboardPageHeader } from '../../components/dashboard/DashboardPageHeader.tsx';
import { StockTransaction, Product, StudentApplication, Supplier, AuditLog } from '../../types/index.ts';
import {
  FileBarChart,
  Printer,
  Download,
  Filter,
  Calendar,
  Layers,
  CheckCircle2,
  Table,
  FileSpreadsheet,
  BarChart3,
  PieChart as PieIcon,
  TrendingUp
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  PieChart,
  Pie
} from 'recharts';

export const ReportsManager: React.FC = () => {
  const { t, language } = useLanguage();
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const { user } = useAuth();

  const transactions = StorageService.getTransactions();
  const products = StorageService.getProducts();
  const applications = StorageService.getApplications();
  const suppliers = StorageService.getSuppliers();
  const auditLogs = StorageService.getAuditLogs();

  const [selectedReport, setSelectedReport] = useState<
    'stock_in' | 'stock_out' | 'inventory_valuation' | 'consumption' | 'admissions' | 'audit_trail'
  >('stock_out');

  const [dateRange, setDateRange] = useState<'all' | 'today' | '7days' | '30days'>('all');
  const [productFilter, setProductFilter] = useState<string>('all');
  const [showChart, setShowChart] = useState<boolean>(true);

  // Theme-aware Recharts styling
  const chartTheme = useMemo(() => ({
    grid: isDark ? '#1e293b' : '#f1f5f9',
    axis: isDark ? '#94a3b8' : '#64748b',
    tooltipBg: isDark ? '#071A33' : '#ffffff',
    tooltipBorder: isDark ? '#334155' : '#e2e8f0',
    tooltipText: isDark ? '#ffffff' : '#0f172a',
    cardBg: isDark ? '#0B1930' : '#ffffff',
  }), [isDark]);

  // Filter transactions
  const filteredTxs = transactions.filter((tx) => {
    if (selectedReport === 'stock_in' && tx.type !== 'stock_in') return false;
    if (selectedReport === 'stock_out' && tx.type !== 'stock_out') return false;
    if (productFilter !== 'all' && tx.productId !== productFilter) return false;

    if (dateRange === 'today') {
      const today = new Date().toISOString().split('T')[0];
      return tx.createdAt.startsWith(today);
    }
    if (dateRange === '7days') {
      const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      return new Date(tx.createdAt) >= cutoff;
    }
    if (dateRange === '30days') {
      const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      return new Date(tx.createdAt) >= cutoff;
    }
    return true;
  });

  // Aggregated Chart Data depending on selected report
  const reportChartData = useMemo(() => {
    if (selectedReport === 'stock_out' || selectedReport === 'stock_in') {
      const summaryByProd: Record<string, number> = {};
      filteredTxs.forEach((tx) => {
        summaryByProd[tx.productName] = (summaryByProd[tx.productName] || 0) + tx.quantity;
      });
      return Object.entries(summaryByProd).map(([name, quantity]) => ({
        name: name.split(' ')[0],
        fullName: name,
        value: quantity
      }));
    } else if (selectedReport === 'inventory_valuation') {
      return products.map((p) => ({
        name: p.nameRw.split(' ')[0],
        fullName: p.nameRw,
        value: p.currentStock * p.unitCostRwf,
        stock: p.currentStock
      }));
    } else if (selectedReport === 'admissions') {
      const byDept: Record<string, number> = {};
      applications.forEach((a) => {
        const key = a.department === 'software_development' ? 'Software Dev' : 'Automobile Tech';
        byDept[key] = (byDept[key] || 0) + 1;
      });
      return Object.entries(byDept).map(([name, count]) => ({
        name,
        fullName: name,
        value: count
      }));
    }
    return [];
  }, [selectedReport, filteredTxs, products, applications]);

  // Export CSV Helper
  const exportToCSV = () => {
    let csvContent = '\uFEFF'; // UTF-8 BOM
    let fileName = `KASS_Report_${selectedReport}_${new Date().toISOString().split('T')[0]}.csv`;

    if (selectedReport === 'stock_in' || selectedReport === 'stock_out') {
      csvContent += 'Transaction Number,Product Name,Type,Quantity,Unit,Category / Supplier,Staff Name,Role,Date\n';
      filteredTxs.forEach((t) => {
        csvContent += `"${t.transactionNumber}","${t.productName}","${t.type}",${t.quantity},"${t.unit}","${t.supplierName || t.mealCategory || ''}","${t.performedByUserName}","${t.performedByRole}","${t.createdAt}"\n`;
      });
    } else if (selectedReport === 'inventory_valuation') {
      csvContent += 'Item Code,Kinyarwanda Name,English Name,Current Stock,Unit,Min Threshold,Target Capacity,Unit Cost RWF,Total Value RWF\n';
      products.forEach((p) => {
        csvContent += `"${p.code}","${p.nameRw}","${p.nameEn}",${p.currentStock},"${p.unit}",${p.minThreshold},${p.targetCapacity},${p.unitCostRwf},${p.currentStock * p.unitCostRwf}\n`;
      });
    } else if (selectedReport === 'admissions') {
      csvContent += 'Tracking Number,Full Name,Department,Level,S3 Aggregate Score,Phone,District,Sector,Status,Submitted At\n';
      applications.forEach((a) => {
        csvContent += `"${a.trackingNumber}","${a.fullName}","${a.department}","${a.applyingLevel}",${a.s3AggregateScore},"${a.phone}","${a.district}","${a.sector}","${a.status}","${a.submittedAt}"\n`;
      });
    } else if (selectedReport === 'audit_trail') {
      csvContent += 'Log ID,Action,Category,Staff Name,Role,Details,IP Address,Timestamp\n';
      auditLogs.forEach((l) => {
        csvContent += `"${l.id}","${l.action}","${l.category}","${l.userName}","${l.userRole}","${l.details.replace(/"/g, '""')}","${l.ipAddress || ''}","${l.timestamp}"\n`;
      });
    }

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header & Export Controls */}
      <DashboardPageHeader
        title={t('reportsTitle')}
        subtitle={t('reportsSub')}
        variant="teal"
        className="no-print"
      >
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setShowChart(!showChart)}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold border transition-colors shadow-xs cursor-pointer ${
              showChart
                ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300'
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span className="hidden xs:inline">{showChart ? 'Hide Chart View' : 'Visual Chart'}</span>
          </button>

          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 transition-colors shadow-xs cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{t('exportPdf')}</span>
          </button>

          <button
            onClick={exportToCSV}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-xs shadow-emerald-600/20 transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>{t('exportCsv')}</span>
          </button>
        </div>
      </DashboardPageHeader>

      {/* Report Type Selector & Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm space-y-4 no-print">
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'stock_out', label: t('reportDailyStockOut') },
            { id: 'stock_in', label: t('reportDailyStockIn') },
            { id: 'inventory_valuation', label: t('reportRemainingStock') },
            { id: 'admissions', label: t('reportAdmissions') },
            { id: 'audit_trail', label: t('reportAuditTrail') }
          ].map((rep) => (
            <button
              key={rep.id}
              onClick={() => setSelectedReport(rep.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
                selectedReport === rep.id
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {rep.label}
            </button>
          ))}
        </div>

        {/* Sub-Filters */}
        {(selectedReport === 'stock_in' || selectedReport === 'stock_out') && (
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-semibold">{t('dateRangeLabel')}:</span>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              >
                <option value="all">All Dates</option>
                <option value="today">Today Only</option>
                <option value="7days">Last 7 Days</option>
                <option value="30days">Last 30 Days</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-slate-500 font-semibold">Commodity:</span>
              <select
                value={productFilter}
                onChange={(e) => setProductFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              >
                <option value="all">All Commodities</option>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Visual Analytics Card (Interactive Recharts representation of selected report) */}
      {showChart && reportChartData.length > 0 && (
        <div className="bg-white dark:bg-[#0B1930] rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm no-print transition-colors">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span className="capitalize">
                  {selectedReport.replace('_', ' ')} Visual Distribution
                </span>
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Aggregated metrics according to active date range and commodity filters
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-slate-500 dark:text-slate-400">
              {reportChartData.length} categories plotted
            </span>
          </div>

          <div className="h-64 sm:h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={reportChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="reportBarGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#1d4ed8" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={chartTheme.grid} opacity={0.8} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                  tickLine={false}
                  axisLine={{ stroke: chartTheme.grid }}
                />
                <YAxis
                  tick={{ fill: chartTheme.axis, fontSize: 11, fontWeight: 500 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => selectedReport === 'inventory_valuation' ? `${(val / 1000000).toFixed(1)}M` : `${val}`}
                />
                <Tooltip
                  cursor={{ fill: isDark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.03)' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      const formattedVal = selectedReport === 'inventory_valuation'
                        ? `${Number(data.value).toLocaleString()} RWF`
                        : `${Number(data.value).toLocaleString()} units / items`;
                      return (
                        <div className="bg-white/95 dark:bg-[#071A33]/95 backdrop-blur-md p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-xl text-xs space-y-1.5 min-w-[160px]">
                          <div className="font-bold text-slate-900 dark:text-white pb-1 border-b border-slate-100 dark:border-slate-800">
                            {data.fullName}
                          </div>
                          <div className="flex justify-between gap-3">
                            <span className="text-slate-500">Metric Value:</span>
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                              {formattedVal}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar
                  dataKey="value"
                  name="Value"
                  fill="url(#reportBarGrad)"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={32}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Printable Report Document Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm print:p-0 print:border-none print:shadow-none">
        
        {/* Institutional Report Letterhead */}
        <div className="pb-6 border-b-2 border-slate-900 dark:border-slate-100 mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-600 dark:text-emerald-400 block mb-1">
              REPUBLIC OF RWANDA · MINEDUC / RTB ACCREDITED
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              KARENGE ADVENTIST SECONDARY SCHOOL
            </h2>
            <p className="text-xs text-slate-500">
              Karenge, Rwanda · Official Administrative Ledger Report
            </p>
          </div>

          <div className="text-right text-xs">
            <div className="font-mono font-bold text-slate-900 dark:text-white">
              Generated: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
            <div className="text-slate-500">
              Signatory: {user?.fullName} ({user?.role.toUpperCase()})
            </div>
          </div>
        </div>

        {/* Report Content based on selection */}
        {selectedReport === 'stock_out' || selectedReport === 'stock_in' ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                {selectedReport === 'stock_out' ? 'Stock Out Daily Issuance Log' : 'Main Stock In Consignments Log'}
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                {filteredTxs.length} Records Listed
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
                    <th className="py-2.5 px-3">Tx Number</th>
                    <th className="py-2.5 px-3">Commodity</th>
                    <th className="py-2.5 px-3">Quantity</th>
                    <th className="py-2.5 px-3">Purpose / Meal / Vendor</th>
                    <th className="py-2.5 px-3">Authorized By</th>
                    <th className="py-2.5 px-3 text-right">Date & Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredTxs.map((t) => (
                    <tr key={t.id}>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                        {t.transactionNumber}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                        {t.productName}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold tabular-nums">
                        {t.type === 'stock_in' ? `+${t.quantity}` : `-${t.quantity}`} {t.unit}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400 capitalize">
                        {t.supplierName || t.mealCategory || t.purposeNotes || '—'}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {t.performedByUserName} ({t.performedByRole})
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-500 text-right">
                        {new Date(t.createdAt).toLocaleDateString()} {new Date(t.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : selectedReport === 'inventory_valuation' ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                Food Stock Inventory & Asset Valuation Report
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                {products.length} Products
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
                    <th className="py-2.5 px-3">Item Code</th>
                    <th className="py-2.5 px-3">Commodity Name</th>
                    <th className="py-2.5 px-3">Available Stock</th>
                    <th className="py-2.5 px-3">Safety Min</th>
                    <th className="py-2.5 px-3">Unit Cost (RWF)</th>
                    <th className="py-2.5 px-3 text-right">Total Asset Valuation (RWF)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {products.map((p) => {
                    const totalVal = p.currentStock * p.unitCostRwf;
                    return (
                      <tr key={p.id}>
                        <td className="py-3 px-3 font-mono font-bold text-slate-500">{p.code}</td>
                        <td className="py-3 px-3 font-semibold text-slate-900 dark:text-white">
                          {p.name}
                        </td>
                        <td className="py-3 px-3 font-mono font-bold tabular-nums">
                          {p.currentStock.toLocaleString()} {p.unit}
                        </td>
                        <td className="py-3 px-3 font-mono text-slate-500">
                          {p.minThreshold} {p.unit}
                        </td>
                        <td className="py-3 px-3 font-mono tabular-nums">
                          {p.unitCostRwf.toLocaleString()}
                        </td>
                        <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white text-right tabular-nums">
                          {totalVal.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                  <tr className="border-t-2 border-slate-900 dark:border-slate-100 font-bold text-xs bg-slate-50/70 dark:bg-slate-800/50">
                    <td colSpan={5} className="py-3 px-3 uppercase text-right">
                      Grand Total Inventory Valuation:
                    </td>
                    <td className="py-3 px-3 font-mono text-emerald-600 dark:text-emerald-400 text-right font-extrabold text-sm tabular-nums">
                      {products
                        .reduce((sum, p) => sum + p.currentStock * p.unitCostRwf, 0)
                        .toLocaleString()}{' '}
                      RWF
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : selectedReport === 'admissions' ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                Student Admissions & Intake Evaluation Report
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                {applications.length} Candidates
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
                    <th className="py-2.5 px-3">Tracking #</th>
                    <th className="py-2.5 px-3">Full Names</th>
                    <th className="py-2.5 px-3">Department</th>
                    <th className="py-2.5 px-3">S3 Points</th>
                    <th className="py-2.5 px-3">Guardian Contact</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Submission Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {applications.map((a) => (
                    <tr key={a.id}>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                        {a.trackingNumber}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                        {a.fullName}
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {a.department === 'software_development' ? 'Software Development' : 'Automobile Tech'}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold">{a.s3AggregateScore} pts</td>
                      <td className="py-3 px-3 font-mono text-slate-500">{a.phone}</td>
                      <td className="py-3 px-3">
                        <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
                          {a.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-500 text-right">
                        {new Date(a.submittedAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                Immutable System Security Audit Trail
              </h3>
              <span className="text-xs text-slate-500 font-mono">
                {auditLogs.length} Events Logged
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40 text-[11px] uppercase tracking-wider text-slate-500 font-bold">
                    <th className="py-2.5 px-3">Event Action</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">User & Role</th>
                    <th className="py-2.5 px-3">Audit Details</th>
                    <th className="py-2.5 px-3 text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {auditLogs.map((l) => (
                    <tr key={l.id}>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white">
                        {l.action}
                      </td>
                      <td className="py-3 px-3 uppercase text-[10px] text-slate-500 font-bold">
                        {l.category}
                      </td>
                      <td className="py-3 px-3 text-slate-800 dark:text-slate-200">
                        {l.userName} ({l.userRole})
                      </td>
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {l.details}
                      </td>
                      <td className="py-3 px-3 font-mono text-slate-500 text-right">
                        {new Date(l.timestamp).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Official Report Sign-off Stamp */}
        <div className="mt-16 pt-8 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-6 text-xs text-slate-500">
          <div className="text-center sm:text-left">
            <div className="font-bold text-slate-900 dark:text-white">Prepared By:</div>
            <div className="mt-6 border-b border-slate-400 w-48"></div>
            <div className="mt-1">{user?.fullName} · {user?.role.toUpperCase()}</div>
          </div>

          <div className="text-center sm:text-right">
            <div className="font-bold text-slate-900 dark:text-white">Director Approval & Stamp:</div>
            <div className="mt-6 border-b border-slate-400 w-48"></div>
            <div className="mt-1">Rev. Dr. Emmanuel Nshimyumuremyi</div>
          </div>
        </div>

      </div>

    </div>
  );
};
